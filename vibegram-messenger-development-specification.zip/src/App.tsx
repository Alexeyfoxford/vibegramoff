/* @ts-nocheck */
/**
 * VibeGram Messenger — Firebase Edition v3
 * ─────────────────────────────────────────
 * Изменения этой версии:
 *  • Экономика («Вайбы», подарки, розыгрыши, квесты) ПОЛНОСТЬЮ удалена
 *  • Анти-флуд RateLimiter: лимит сообщений, экспоненциальный кулдаун,
 *    лимит создания чатов/реакций, дебаунс поиска
 *  • Конфиденциальность: кто может писать в ЛС, последний визит, поиск
 *  • Удаление аккаунта (с подтверждением паролем)
 *  • Нечёткий поиск пользователей и чатов (подстрока + опечатки)
 *  • Звонки только в ЛС и группах (каналам звонить нельзя)
 *  • Предпросмотр: PDF (встроенный), txt/md/json/log (UTF-8), CSV (таблица),
 *    карточки для презентаций и документов
 */
import { useEffect, useMemo, useRef, useState } from 'react';
import { ZegoUIKitPrebuilt } from '@zegocloud/zego-uikit-prebuilt';

import {
  db, auth, collection, addDoc, setDoc, getDoc, getDocs, onSnapshot, query, orderBy,
  where, doc, updateDoc, deleteDoc, arrayUnion, arrayRemove, limit,
  fbRegister, fbLogin, fbChangePassword, fbDeleteAccount, ensureSystemBot, signOut,
  fbResetPassword, fbResendVerification, fbIsEmailVerified, fbAttachEmail,
  fbCreateChat, fbCreateDM, fbDeleteChat, fbLeaveChat,
  fbSendMessage, fbToggleReaction, checkAdminToken, fbWipeAll,
  fbPinMessage, fbUnpinMessage, fbTogglePinChat, fbToggleArchive,
  fbSetTyping, fbMuteChat, fbExportChat,
  fbBlockUser, fbUnblockUser, fbGetBlockedUsers,
  fbBanGlobal, fbUnbanGlobal, fbListBanned, fbReport, fbListReports, fbResolveReport,
  fbCreatePack, fbAddItemToPack, fbMyPacks, fbInstallPack, fbGetInstalledPacks,
  fbUploadFile, fbAddBookmark, fbRemoveBookmark, fbGetCatalog, fbJoinChat, fbSearchInChat,
  isUserBanned, fbAutoModerate,
  fbSetPremium, fbRemovePremium, isPremium,
  fbSaveAIConfig, callAI,
  fbPostStory, onStories, fbViewStory, fbDeleteStory,
  encText, decText,
} from './fb';

const ZEGO_APP_ID = 348866763;
const ZEGO_SECRET = '122e9de2942ce86eb7f64c38d8e5a826';

/* ═══════════ SVG-иконки ═══════════ */
const IC = {
  search: (s=18) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>,
  send: (s=20) => <svg width={s} height={s} viewBox="0 0 24 24" fill="currentColor"><path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/></svg>,
  attach: (s=20) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M21.44 11.05l-9.19 9.19a6 6 0 01-8.49-8.49l9.19-9.19a4 4 0 015.66 5.66l-9.2 9.19a2 2 0 01-2.83-2.83l8.49-8.48"/></svg>,
  mic: (s=20) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><rect x="9" y="1" width="6" height="12" rx="3"/><path d="M5 10v1a7 7 0 0014 0v-1M12 18v4M8 22h8"/></svg>,
  phone: (s=20) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07 19.5 19.5 0 01-6-6 19.79 19.79 0 01-3.07-8.67A2 2 0 014.11 2h3a2 2 0 012 1.72c.127.96.362 1.903.7 2.81a2 2 0 01-.45 2.11L8.09 9.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45c.907.338 1.85.573 2.81.7A2 2 0 0122 16.92z"/></svg>,
  settings: (s=18) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83-2.83l.06-.06A1.65 1.65 0 004.68 15a1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 012.83-2.83l.06.06A1.65 1.65 0 009 4.68a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 2.83l-.06.06A1.65 1.65 0 0019.4 9a1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z"/></svg>,
  back: (s=20) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>,
  close: (s=18) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M18 6L6 18M6 6l12 12"/></svg>,
  edit: (s=15) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>,
  trash: (s=15) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/></svg>,
  reply: (s=15) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><polyline points="9 17 4 12 9 7"/><path d="M20 18v-2a4 4 0 00-4-4H4"/></svg>,
  forward: (s=15) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><polyline points="15 17 20 12 15 7"/><path d="M4 18v-2a4 4 0 014-4h12"/></svg>,
  copy: (s=15) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"/></svg>,
  users: (s=16) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75"/></svg>,
  plus: (s=16) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M12 5v14M5 12h14"/></svg>,
  gif: (s=20) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="2" y="4" width="20" height="16" rx="2"/><text x="12" y="15" textAnchor="middle" fill="currentColor" stroke="none" fontSize="8" fontWeight="bold">GIF</text></svg>,
  play: (s=16) => <svg width={s} height={s} viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg>,
  pause: (s=16) => <svg width={s} height={s} viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></svg>,
  logout: (s=16) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4M16 17l5-5-5-5M21 12H9"/></svg>,
  shield: (s=16) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>,
  crown: (s=14) => <svg width={s} height={s} viewBox="0 0 24 24" fill="#f59e0b" stroke="#f59e0b" strokeWidth="1"><path d="M2 18h20l-2-9-5 4-3-7-3 7-5-4-2 9z"/></svg>,
  folder: (s=16) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M22 19a2 2 0 01-2 2H4a2 2 0 01-2-2V5a2 2 0 012-2h5l2 3h9a2 2 0 012 2z"/></svg>,
  bot: (s=16) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="8" width="18" height="12" rx="2"/><path d="M12 8V4M8 13h.01M16 13h.01M10 17h4"/></svg>,
  more: (s=18) => <svg width={s} height={s} viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="5" r="1.5"/><circle cx="12" cy="12" r="1.5"/><circle cx="12" cy="19" r="1.5"/></svg>,
  check: (s=15) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><polyline points="20 6 9 17 4 12"/></svg>,
  ban: (s=15) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="10"/><path d="M4.93 4.93l14.14 14.14"/></svg>,
  timer: (s=16) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>,
  download: (s=15) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4M7 10l5 5 5-5M12 15V3"/></svg>,
  lock: (s=15) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0110 0v4"/></svg>,
  eye: (s=15) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>,
  file: (s=18) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>,
  pin: (s=15) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M12 17v5M9 10.76a2 2 0 01-1.11 1.79l-1.78.9A2 2 0 005 15.24V16h14v-.76a2 2 0 00-1.11-1.79l-1.78-.9A2 2 0 0115 10.76V6h1a2 2 0 000-4H8a2 2 0 000 4h1v4.76z"/></svg>,
  poll: (s=18) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>,
  music: (s=18) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg>,
  schedule: (s=18) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><circle cx="12" cy="13" r="8"/><path d="M12 9v4l2 2M5 3L2 6M22 6l-3-3"/></svg>,
  link: (s=15) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M10 13a5 5 0 007.54.54l3-3a5 5 0 00-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 00-7.54-.54l-3 3a5 5 0 007.07 7.07l1.71-1.71"/></svg>,
  archive: (s=15) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><polyline points="21 8 21 21 3 21 3 8"/><rect x="1" y="3" width="22" height="5"/><line x1="10" y1="12" x2="14" y2="12"/></svg>,
  bell: (s=15) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9M13.73 21a2 2 0 01-3.46 0"/></svg>,
  bellOff: (s=15) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M13.73 21a2 2 0 01-3.46 0M18.63 13A17.89 17.89 0 0118 8M6.26 6.26A5.86 5.86 0 006 8c0 7-3 9-3 9h14M18 8a6 6 0 00-9.33-5M1 1l22 22"/></svg>,
  vcircle: (s=18) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="10"/><polygon points="10 8 16 12 10 16 10 8" fill="currentColor"/></svg>,
  sticker: (s=18) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M21 11.5V3H3v18h8.5z"/><path d="M21 11.5L11.5 21v-9.5z"/></svg>,
  stop: (s=16) => <svg width={s} height={s} viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="6" width="12" height="12" rx="2"/></svg>,
  image: (s=18) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>,
  smile: (s=18) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="10"/><path d="M8 14s1.5 2 4 2 4-2 4-2M9 9h.01M15 9h.01"/></svg>,
  gallery: (s=18) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/></svg>,
  bookmark: (s=15) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M19 21l-7-5-7 5V5a2 2 0 012-2h10a2 2 0 012 2z"/></svg>,
  compass: (s=16) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="10"/><polygon points="16.24 7.76 14.12 14.12 7.76 16.24 9.88 9.88 16.24 7.76"/></svg>,
  globe: (s=16) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2a15.3 15.3 0 014 10 15.3 15.3 0 01-4 10 15.3 15.3 0 01-4-10 15.3 15.3 0 014-10z"/></svg>,
  stats: (s=16) => <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><line x1="12" y1="20" x2="12" y2="10"/><line x1="18" y1="20" x2="18" y2="4"/><line x1="6" y1="20" x2="6" y2="16"/></svg>,
  star: (s=14) => <svg width={s} height={s} viewBox="0 0 24 24" fill="#f5b50a" stroke="#f5b50a" strokeWidth="1"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>,
};

/* ═══════════ Twemoji реакции ═══════════ */
const TW: Record<string,string> = { '👍':'1f44d','❤️':'2764','🔥':'1f525','😂':'1f602','😮':'1f62e','😢':'1f622','👎':'1f44e','😡':'1f621','🎉':'1f389','🤔':'1f914','💯':'1f4af','👀':'1f440','🙏':'1f64f','💔':'1f494','😍':'1f60d','🤡':'1f921','🥱':'1f971','🤯':'1f92f','💩':'1f4a9','🕊️':'1f54a','🍓':'1f353','💋':'1f48b','🦄':'1f984','⚡':'26a1' };
const QUICK_REACTIONS = ['👍','❤️','🔥','😂','😮','😢'];
const ALL_REACTIONS = Object.keys(TW);
/* эксклюзивные реакции только для Premium */
const PREMIUM_REACTIONS = ['🤝','🦄','💎','👑','🚀','🎩','🍾','🥂','💸','🏆'];
/* Apple-эмодзи как КАРТИНКИ (реальный CDN, рендерит стиль Apple iOS) */
const appleEmoji = (e:string) => `https://emojicdn.elk.sh/${encodeURIComponent(e)}?style=apple`;
const tw = (e:string) => appleEmoji(e);
/* заменяем юникод-эмодзи в тексте на <img> Apple-стиля */
const EMOJI_RE = /(\p{Extended_Pictographic}(\u200d\p{Extended_Pictographic})*[\uFE0F\u20E3]?)/gu;
function renderAppleEmoji(html:string){
  try{
    return html.replace(EMOJI_RE, (m)=>`<img class="vg-ae" src="${appleEmoji(m)}" alt="${m}" draggable="false"/>`);
  }catch{ return html; }
}
/* полный набор эмодзи по категориям для своего пикера */
const EMOJI_CATS:{name:string;list:string[]}[]=[
  {name:'Смайлы',list:['😀','😃','😄','😁','😆','😅','🤣','😂','🙂','🙃','😉','😊','😇','🥰','😍','🤩','😘','😗','😚','😙','😋','😛','😜','🤪','😝','🤑','🤗','🤭','🤫','🤔','🤐','🤨','😐','😑','😶','😏','😒','🙄','😬','🤥','😌','😔','😪','🤤','😴','😷','🤒','🤕','🤢','🤮','🤧','🥵','🥶','🥴','😵','🤯','🤠','🥳','😎','🤓','🧐','😕','😟','🙁','😮','😯','😲','😳','🥺','😦','😧','😨','😰','😥','😢','😭','😱','😖','😣','😞','😓','😩','😫','🥱','😤','😡','😠','🤬','😈','👿','💀','💩','🤡','👻','👽','🤖']},
  {name:'Жесты',list:['👍','👎','👊','✊','🤛','🤜','👏','🙌','👐','🤲','🤝','🙏','✍️','💅','🤳','💪','👈','👉','👆','👇','☝️','✋','🤚','🖐️','🖖','👋','🤙','💯','🔥','❤️','🧡','💛','💚','💙','💜','🖤','🤍','🤎','💔','❣️','💕','💞','💓','💗','💖','💘','💝']},
  {name:'Животные',list:['🐶','🐱','🐭','🐹','🐰','🦊','🐻','🐼','🐨','🐯','🦁','🐮','🐷','🐸','🐵','🐔','🐧','🐦','🐤','🦄','🐝','🦋','🐌','🐞','🐢','🐍','🦕','🐙','🦑','🦀','🐠','🐟','🐬','🐳','🐊','🐆','🦓','🦍','🐘','🦏','🐪','🐎','🐖','🐏','🐑','🐐','🦌','🐕','🐩','🐈']},
  {name:'Еда',list:['🍏','🍎','🍐','🍊','🍋','🍌','🍉','🍇','🍓','🫐','🍈','🍒','🍑','🥭','🍍','🥥','🥝','🍅','🍆','🥑','🥦','🥬','🥒','🌽','🥕','🧄','🧅','🥔','🍠','🥐','🥯','🍞','🥖','🧀','🥚','🍳','🧇','🥞','🍔','🍟','🍕','🌭','🥪','🌮','🌯','🍜','🍣','🍦','🍰','🎂','🍫','🍬','🍭','🍩','🍪','☕','🍵','🍺','🍷','🥂']},
  {name:'Объекты',list:['⚽','🏀','🏈','⚾','🎾','🏐','🎱','🏓','🎮','🕹️','🎲','🎯','🎸','🎺','🎷','🎹','🥁','🎻','🎬','🎤','🎧','📱','💻','⌨️','🖥️','🖨️','📷','📸','🎥','📺','⏰','⏱️','💡','🔦','🕯️','💎','💰','💳','🚀','✈️','🚗','🏎️','🚕','🚙','🚌','🏠','🏢','🗼','🌍','🌙','⭐','🌟','✨','⚡','☀️','🌈','❄️','🔥','💧']},
  {name:'Символы',list:['✅','❌','⭕','❗','❓','‼️','⚠️','🚫','💢','♻️','🔱','✔️','➕','➖','✖️','💲','©️','®️','™️','🔔','🔕','🎵','🎶','💬','💭','🗯️','♥️','♠️','♦️','♣️','🆗','🆕','🆒','🆘','🔴','🟠','🟡','🟢','🔵','🟣','⚫','⚪','🟥','🟧','🟨','🟩','🟦','🟪']},
];

/* ═══════════ Утилиты ═══════════ */
const fmtTime = (ts:number) => { try { return new Date(ts).toLocaleTimeString('ru-RU',{hour:'2-digit',minute:'2-digit'}); } catch { return ''; }};
const fmtDate = (ts:number) => {
  const d=new Date(ts), n=new Date();
  if(d.toDateString()===n.toDateString()) return 'Сегодня';
  const y=new Date(n); y.setDate(y.getDate()-1);
  if(d.toDateString()===y.toDateString()) return 'Вчера';
  return d.toLocaleDateString('ru-RU',{day:'numeric',month:'long'});
};
const escRe = (s:string) => s.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
const fileToUrl = (f:File):Promise<string> => new Promise((r,j)=>{const x=new FileReader();x.onload=()=>r(x.result as string);x.onerror=j;x.readAsDataURL(f);});
const md = (t:string) => {
  let s=(t||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  s=s.replace(/```([\s\S]*?)```/g,(_,c)=>`<pre class="vg-code">${c}</pre>`);
  s=s.replace(/`([^`]+)`/g,'<code>$1</code>');
  s=s.replace(/\*\*([^*]+)\*\*/g,'<b>$1</b>');
  s=s.replace(/(^|[^*])\*([^*\n]+)\*(?!\*)/g,'$1<i>$2</i>');
  s=s.replace(/~~([^~]+)~~/g,'<span class="vg-spoiler" onclick="this.classList.toggle(\'open\')">$1</span>');
  s=s.replace(/\n/g,'<br/>');
  s=s.replace(/(https?:\/\/[^\s<]+)/g,'<a href="$1" target="_blank" rel="noopener noreferrer">$1</a>');
  return s;
};

/* ═══════════ Нечёткий поиск ═══════════
   1) подстрока — высокий балл; 2) подпоследовательность;
   3) расстояние Левенштейна ≤ 2 (опечатки) */
function lev(a:string,b:string){
  if(Math.abs(a.length-b.length)>2) return 99;
  const m=a.length,n=b.length;
  const dp=Array.from({length:m+1},(_,i)=>[i,...Array(n).fill(0)]);
  for(let j=0;j<=n;j++) dp[0][j]=j;
  for(let i=1;i<=m;i++) for(let j=1;j<=n;j++)
    dp[i][j]=Math.min(dp[i-1][j]+1,dp[i][j-1]+1,dp[i-1][j-1]+(a[i-1]===b[j-1]?0:1));
  return dp[m][n];
}
function fuzzyScore(qRaw:string, target:string){
  const q=qRaw.toLowerCase().trim(), s=(target||'').toLowerCase();
  if(!q||!s) return 0;
  if(s===q) return 1000;
  if(s.startsWith(q)) return 500-s.length;
  if(s.includes(q)) return 300-s.indexOf(q);
  // подпоследовательность (например "алксей" найдёт "алексей")
  let i=0; for(const ch of s){ if(ch===q[i]) i++; if(i>=q.length) break; }
  if(i>=q.length) return 100;
  // опечатки
  if(q.length>=4 && lev(q,s)<=2) return 80;
  if(q.length>=4){
    for(const word of s.split(/[\s_]+/)) if(lev(q,word)<=2) return 60;
  }
  return 0;
}

/* ═══════════ Анти-флуд / DDoS-защита (клиентская) ═══════════
   Лимиты на отправку сообщений, реакции, создание чатов и поиск.
   При превышении — экспоненциальный кулдаун. */
class RateLimiter {
  buckets: Record<string,{stamps:number[];strikes:number;blockedUntil:number}> = {};
  limits: Record<string,{max:number;windowMs:number;minGapMs:number}> = {
    msg:      { max: 8,  windowMs: 10_000, minGapMs: 350 },
    reaction: { max: 15, windowMs: 10_000, minGapMs: 150 },
    chat:     { max: 3,  windowMs: 60_000, minGapMs: 2000 },
    search:   { max: 10, windowMs: 10_000, minGapMs: 250 },
  };
  check(kind:string):{ok:boolean;wait?:number}{
    const lim=this.limits[kind]; if(!lim) return {ok:true};
    const b=(this.buckets[kind] ||= {stamps:[],strikes:0,blockedUntil:0});
    const now=Date.now();
    if(now<b.blockedUntil) return {ok:false,wait:Math.ceil((b.blockedUntil-now)/1000)};
    b.stamps=b.stamps.filter(t=>now-t<lim.windowMs);
    const last=b.stamps[b.stamps.length-1]||0;
    if(now-last<lim.minGapMs) return {ok:false,wait:1};
    if(b.stamps.length>=lim.max){
      b.strikes++;
      b.blockedUntil=now+Math.min(15_000*Math.pow(2,b.strikes-1),300_000); // 15с → 30с → ... → 5 мин
      return {ok:false,wait:Math.ceil((b.blockedUntil-now)/1000)};
    }
    b.stamps.push(now);
    return {ok:true};
  }
}
const rl = new RateLimiter();

/* ═══════════ Toast / Модалки / Контекстное меню ═══════════ */
let _toastTimer:any;
function toast(msg:string){
  const el=document.getElementById('vg-toast'); if(!el) return;
  el.textContent=msg; el.classList.add('show');
  clearTimeout(_toastTimer); _toastTimer=setTimeout(()=>el.classList.remove('show'),2400);
}
type MState={name:string|null;props?:any};
let _setModal:(m:MState)=>void=()=>{};
const openModal=(name:string,props:any={})=>_setModal({name,props});
const closeModal=()=>_setModal({name:null});
type CtxState={x:number;y:number;kind:string;data?:any}|null;
let _setCtx:(c:CtxState)=>void=()=>{};
const openCtx=(e:React.MouseEvent,kind:string,data:any={})=>{
  e.preventDefault(); e.stopPropagation();
  _setCtx({x:Math.min(e.clientX,window.innerWidth-240),y:Math.min(e.clientY,window.innerHeight-340),kind,data});
};
const closeCtx=()=>_setCtx(null);

/* ═══════════ Аватар + значок владельца ═══════════ */
function Avatar({name,src,size=40,ch=false}:{name:string;src?:string;size?:number;ch?:boolean}){
  const ini=(name||'?').split(' ').map(s=>s[0]).slice(0,2).join('').toUpperCase();
  const bg=`hsl(${[...(name||'?')].reduce((a,c)=>a+c.charCodeAt(0),0)%360} 50% 42%)`;
  return src ? <img src={src} style={{width:size,height:size,borderRadius:ch?10:999,objectFit:'cover',flexShrink:0}} alt=""/> :
    <div style={{width:size,height:size,borderRadius:ch?10:999,background:bg,display:'grid',placeItems:'center',color:'#fff',fontWeight:700,fontSize:size*0.34,flexShrink:0}}>{ini}</div>;
}
function NameBadge({user,name,size=13}:{user?:any;name:string;size?:number}){
  return <span style={{display:'inline-flex',alignItems:'center',gap:4}}>
    {name}
    {(user?.isOwner||user?.isAdmin)&&<span title="Администрация">{IC.crown(size)}</span>}
    {isPremium(user)&&!(user?.isOwner||user?.isAdmin)&&<span title="VibeGram Premium" className="vg-prem-star">{IC.star(size)}</span>}
  </span>;
}

/* ═══════════ Голосовое + расшифровка ═══════════ */
function VoiceWithTranscript({src,transcript,wave}:{src:string;transcript?:string;wave?:string}){
  return <div>
    <AudioPlayer src={src} name="Голосовое" transcript={transcript} wave={wave}/>
  </div>;
}

/* ═══════════ Аудиоплеер ═══════════ */
/* Стиль ТГ: тёмный закруглённый пузырь, ▶ слева, прогресс, время + название, ⬇ справа */
function AudioPlayer({src,name,transcript,wave}:{src:string;name?:string;transcript?:string;wave?:string}){
  const ref=useRef<HTMLAudioElement>(null);
  const [playing,setPlaying]=useState(false);
  const [prog,setProg]=useState(0);
  const [dur,setDur]=useState(0);
  useEffect(()=>{
    const a=ref.current; if(!a) return;
    const t=()=>setProg(a.currentTime), l=()=>setDur(a.duration), e=()=>setPlaying(false);
    a.addEventListener('timeupdate',t); a.addEventListener('loadedmetadata',l); a.addEventListener('ended',e);
    return ()=>{a.removeEventListener('timeupdate',t);a.removeEventListener('loadedmetadata',l);a.removeEventListener('ended',e);};
  },[]);
  const fmt=(s:number)=>`${Math.floor(s/60)}:${String(Math.floor(s%60)).padStart(2,'0')}`;
  const download=()=>{ const a=document.createElement('a'); a.href=src; a.download=name||'voice.webm'; a.click(); };
  /* если нет wave — рисуем «псевдо-осциллограмму» (прямоугольники) */
  const bars=useMemo(()=>{
    if(wave) return wave.split(',').map(Number);
    const arr:number[]=[]; for(let i=0;i<60;i++) arr.push(0.25+Math.abs(Math.sin(i*0.4+(prog||0)*0.5))*0.75);
    return arr;
  },[wave,prog]);
  return <div className="vg-tg-voice">
    <audio ref={ref} src={src} preload="metadata"/>
    <button className="vg-tg-voice-play" onClick={()=>{const a=ref.current;if(!a)return;playing?a.pause():a.play();setPlaying(!playing);}}>
      {playing?IC.pause(18):IC.play(18)}
    </button>
    <div className="vg-tg-voice-mid">
      <div className="vg-tg-voice-wave" onClick={e=>{const a=ref.current;if(!a||!dur)return;const r=e.currentTarget.getBoundingClientRect();a.currentTime=((e.clientX-r.left)/r.width)*dur;}}>
        {bars.map((h,i)=><span key={i} className="vg-tg-voice-bar" style={{height:`${h*100}%`,background:i/dur*100<(prog/dur*100)?'#fff':'rgba(255,255,255,.4)'}}/>)}
      </div>
      <div className="vg-tg-voice-meta">
        <span className="vg-tg-voice-time">{fmt(prog)} / {fmt(dur||0)}</span>
        <span className="vg-tg-voice-name">{name||'Голосовое'}</span>
      </div>
      {transcript&&<button className="vg-chip tiny" onClick={()=>alert('Расшифровка:\n\n'+transcript)}>{IC.bot(11)} Текст</button>}
    </div>
    <button className="vg-tg-voice-dl" title="Скачать" onClick={download}>{IC.download(16)}</button>
  </div>;
}

/* ═══════════ Предпросмотр файлов ═══════════ */
function dataUrlToText(dataUrl:string):string{
  const b64=dataUrl.split(',')[1]||'';
  const bin=atob(b64);
  const bytes=Uint8Array.from(bin,c=>c.charCodeAt(0));
  return new TextDecoder('utf-8').decode(bytes); // корректная кириллица
}
function CsvTable({text}:{text:string}){
  const rows=text.split(/\r?\n/).filter(Boolean).slice(0,12).map(r=>r.split(/[;,\t]/).slice(0,8));
  return <div className="vg-csv-wrap"><table className="vg-csv">
    <tbody>{rows.map((r,i)=><tr key={i}>{r.map((c,j)=>i===0?<th key={j}>{c}</th>:<td key={j}>{c}</td>)}</tr>)}</tbody>
  </table></div>;
}
function FilePreview({file}:{file:any}){
  const [expanded,setExpanded]=useState(false);
  if(file.voice) return <VoiceWithTranscript src={file.data||file.url} transcript={file.transcript} wave={file.wave}/>;
  if(file.type==='image/gif'||file.url) return <img src={file.data||file.url} className="vg-imgprev" alt="GIF"/>;
  if(file.type?.startsWith('image/')) return <a href={file.data} target="_blank" rel="noreferrer"><img src={file.data} className="vg-imgprev" alt={file.name}/></a>;
  if(file.type?.startsWith('video/')) return <video className="vg-vidprev" controls src={file.data}/>;
  if(file.type?.startsWith('audio/')) return <AudioPlayer src={file.data} name={file.name}/>;
  /* PDF — встроенный просмотр */
  if(file.type?.includes('pdf')||file.name?.match(/\.pdf$/i)){
    return <div className="vg-docbox">
      <div className="vg-docbox-head">{IC.file(16)} <b>{file.name}</b> <span className="vg-muted">{(file.size/1024).toFixed(0)} KB</span>
        <button className="vg-chip tiny" onClick={()=>setExpanded(e=>!e)}>{expanded?'Свернуть':'Открыть'}</button>
        <a className="vg-chip tiny" href={file.data} download={file.name}>{IC.download(11)}</a>
      </div>
      {expanded&&<iframe src={file.data} className="vg-pdfframe" title={file.name}/>}
    </div>;
  }
  /* CSV — таблица */
  if(file.name?.match(/\.(csv|tsv)$/i)){
    try{ const text=dataUrlToText(file.data);
      return <div className="vg-docbox">
        <div className="vg-docbox-head">{IC.file(16)} <b>{file.name}</b> <a className="vg-chip tiny" href={file.data} download={file.name}>{IC.download(11)}</a></div>
        <CsvTable text={text}/>
      </div>;
    }catch{}
  }
  /* Текстовые файлы — корректный UTF-8 */
  if(file.name?.match(/\.(txt|md|json|log|xml|html|js|ts|css|py)$/i)||file.type?.startsWith('text/')){
    try{ const text=dataUrlToText(file.data);
      return <div className="vg-docbox">
        <div className="vg-docbox-head">{IC.file(16)} <b>{file.name}</b> <span className="vg-muted">{(file.size/1024).toFixed(0)} KB</span> <a className="vg-chip tiny" href={file.data} download={file.name}>{IC.download(11)}</a></div>
        <pre className="vg-textprev">{text.slice(0,expanded?12000:1500)}</pre>
        {text.length>1500&&<button className="vg-chip tiny" onClick={()=>setExpanded(e=>!e)}>{expanded?'Свернуть':'Показать больше'}</button>}
      </div>;
    }catch{}
  }
  /* Презентации и офисные документы — информативная карточка */
  const office=file.name?.match(/\.(pptx?|key|odp)$/i)?'Презентация':
               file.name?.match(/\.(docx?|odt|rtf)$/i)?'Документ':
               file.name?.match(/\.(xlsx?|ods)$/i)?'Таблица':null;
  if(office){
    return <div className="vg-docbox office">
      <div className="vg-office-icon">{IC.file(28)}</div>
      <div style={{flex:1}}>
        <b>{file.name}</b>
        <div className="vg-muted" style={{fontSize:12}}>{office} · {(file.size/1024).toFixed(0)} KB</div>
        <div className="vg-muted" style={{fontSize:11}}>Браузер не отображает этот формат — скачайте для просмотра</div>
      </div>
      <a className="vg-chip" href={file.data} download={file.name}>{IC.download(13)} Скачать</a>
    </div>;
  }
  return <div className="vg-filebox">{IC.attach(15)} {file.name} <span className="vg-muted">{(file.size/1024).toFixed(0)} KB</span> <a href={file.data} download={file.name}>Скачать</a></div>;
}

/* ═══════════ Emoji Picker (emoji-mart, vanilla для React 19) ═══════════ */
function EmojiPicker({onSelect,onClose}:{onSelect:(e:string)=>void;onClose:()=>void}){
  const [cat,setCat]=useState(0);
  const [q,setQ]=useState('');
  const list=q?EMOJI_CATS.flatMap(c=>c.list).filter((e,i,a)=>a.indexOf(e)===i):EMOJI_CATS[cat].list;
  return <div className="vg-emoji-pop2">
    <div className="vg-emoji-tabs">
      {EMOJI_CATS.map((c,i)=><button key={i} className={cat===i&&!q?'on':''} onClick={()=>{setCat(i);setQ('');}} title={c.name}>
        <img src={appleEmoji(c.list[0])} width={20} height={20} alt=""/>
      </button>)}
      <button className="vg-ibtn vg-emoji-x" onClick={onClose}>{IC.close(15)}</button>
    </div>
    <div className="vg-emoji-grid">
      {list.map((e,i)=><button key={i} className="vg-emoji-cell" onClick={()=>onSelect(e)} title={e}>
        <img src={appleEmoji(e)} width={26} height={26} alt={e} loading="lazy"/>
      </button>)}
    </div>
    <div className="vg-emoji-cat-name">{q?'Все':EMOJI_CATS[cat].name}</div>
  </div>;
}

/* ═══════════ Sticker Picker (Giphy stickers + свои наборы) ═══════════ */
const GIPHY_KEY='GlVGYHkr3WSBnllca54iNt0yFbjz7L65';
function StickerPicker({me,onSelect,onClose}:{me:any;onSelect:(u:string)=>void;onClose:()=>void}){
  const [q,setQ]=useState('');
  const [stickers,setStickers]=useState<string[]>([]);
  const [loading,setLoading]=useState(false);
  const [tab,setTab]=useState<'giphy'|'mine'>('giphy');
  const [myItems,setMyItems]=useState<string[]>([]);
  const load=async(url:string)=>{
    setLoading(true);
    try{ const r=await fetch(url); const d=await r.json();
      setStickers((d.data||[]).map((g:any)=>g.images?.fixed_width_small?.url||g.images?.fixed_width?.url).filter(Boolean));
    }catch{setStickers([]);}
    setLoading(false);
  };
  useEffect(()=>{ load(`https://api.giphy.com/v1/stickers/trending?api_key=${GIPHY_KEY}&limit=30`); },[]);
  useEffect(()=>{
    if(tab==='mine') fbGetInstalledPacks(me.username).then(packs=>{
      const items:string[]=[]; packs.filter((p:any)=>p.type==='sticker').forEach((p:any)=>items.push(...(p.items||[]))); setMyItems(items);
    });
  },[tab]);
  return <div className="vg-gif-picker">
    <div className="vg-gif-head">
      <button className={`vg-chip tiny${tab==='giphy'?' accent':''}`} onClick={()=>setTab('giphy')}>Giphy</button>
      <button className={`vg-chip tiny${tab==='mine'?' accent':''}`} onClick={()=>setTab('mine')}>Мои</button>
      {tab==='giphy'&&<input className="vg-input sm" value={q} onChange={e=>setQ(e.target.value)} placeholder="Поиск стикеров..." onKeyDown={e=>e.key==='Enter'&&load(`https://api.giphy.com/v1/stickers/search?api_key=${GIPHY_KEY}&q=${encodeURIComponent(q)}&limit=30`)}/>}
      <button className="vg-ibtn" onClick={onClose}>{IC.close(16)}</button>
    </div>
    {loading&&<div className="vg-muted" style={{padding:12}}>Загрузка...</div>}
    <div className="vg-gif-grid">
      {(tab==='giphy'?stickers:myItems).map((u,i)=><img key={i} src={u} alt="" style={{background:'transparent'}} onClick={()=>{onSelect(u);onClose();}}/>)}
    </div>
    {tab==='mine'&&myItems.length===0&&<div className="vg-muted" style={{padding:12}}>Нет своих наборов. Создайте во вкладке «Боты» → Стикерпаки</div>}
  </div>;
}

/* ═══════════ GIF Picker ═══════════ */
function GifPicker({onSelect,onClose}:{onSelect:(u:string)=>void;onClose:()=>void}){
  const [q,setQ]=useState('');
  const [gifs,setGifs]=useState<string[]>([]);
  const [loading,setLoading]=useState(false);
  const KEY='AIzaSyAyimkuYQYF_FXVALexPuGQctUWRURdCYQ';
  const load=async(url:string)=>{
    if(!rl.check('search').ok) return;
    setLoading(true);
    try{ const r=await fetch(url); const d=await r.json();
      setGifs((d.results||[]).map((g:any)=>g.media_formats?.tinygif?.url).filter(Boolean));
    }catch{setGifs([]);}
    setLoading(false);
  };
  useEffect(()=>{load(`https://tenor.googleapis.com/v2/featured?key=${KEY}&limit=24&media_filter=tinygif`);},[]);
  return <div className="vg-gif-picker">
    <div className="vg-gif-head">
      <input className="vg-input sm" value={q} onChange={e=>setQ(e.target.value)} placeholder="Поиск GIF..." onKeyDown={e=>e.key==='Enter'&&load(`https://tenor.googleapis.com/v2/search?q=${encodeURIComponent(q)}&key=${KEY}&limit=24&media_filter=tinygif`)}/>
      <button className="vg-ibtn" onClick={onClose}>{IC.close(16)}</button>
    </div>
    {loading&&<div className="vg-muted" style={{padding:12}}>Загрузка...</div>}
    <div className="vg-gif-grid">{gifs.map((u,i)=><img key={i} src={u} alt="" onClick={()=>{onSelect(u);onClose();}}/>)}</div>
  </div>;
}

/* ═══════════ App ═══════════ */
export default function App(){
  const [boot,setBoot]=useState(false);
  const [user,setUser]=useState<any>(null);
  useEffect(()=>{
    (async()=>{
      try{ await ensureSystemBot(); }catch(e){ console.warn('init',e); }
      const savedUn=localStorage.getItem('vg_session');
      if(savedUn&&auth.currentUser===null){
        await new Promise(r=>{ const t=setTimeout(r,2500); const unsub=(auth as any).onAuthStateChanged(()=>{ clearTimeout(t); unsub(); r(0); }); });
      }
      if(savedUn&&auth.currentUser){
        try{
          const snap=await getDoc(doc(db,'users',savedUn));
          if(snap.exists()) setUser(snap.data());
        }catch{}
      } else if(savedUn){
        localStorage.removeItem('vg_session');
      }
      setBoot(true);
    })();
  },[]);
  if(!boot) return <div className="vg-app theme-black" style={{display:'grid',placeItems:'center',height:'100vh',background:'#000'}}><div className="vg-loader-mini"/></div>;
  if(!user) return <AuthScreen onAuth={u=>{setUser(u);localStorage.setItem('vg_session',u.username);}}/>;
  return <Messenger me={user} setMe={setUser} onLogout={async()=>{localStorage.removeItem('vg_session');try{await signOut(auth);}catch{};setUser(null);}}/>;
}

/* ═══════════ Вход ═══════════ */
function AuthScreen({onAuth}:{onAuth:(u:any)=>void}){
  const [mode,setMode]=useState<'login'|'register'|'reset'>('login');
  const [login,setLogin]=useState('');
  const [email,setEmail]=useState('');
  const [pass,setPass]=useState('');
  const [name,setName]=useState('');
  const [err,setErr]=useState('');
  const [ok,setOk]=useState('');
  const [busy,setBusy]=useState(false);
  const [fails,setFails]=useState(0);
  const submit=async(e:React.FormEvent)=>{
    e.preventDefault(); setErr(''); setOk('');
    if(fails>=5){ setErr('Слишком много попыток. Подождите минуту.'); setTimeout(()=>setFails(0),60_000); return; }
    setBusy(true);
    try{
      if(mode==='register'){
        const u=await fbRegister(login,name||login,pass,email);
        onAuth(u);
      }else if(mode==='reset'){
        await fbResetPassword(login||email);
        setOk('Письмо для сброса пароля отправлено! Проверьте почту (и папку Спам).');
      }else{
        const u=await fbLogin(login,pass);
        if(!u){ setFails(f=>f+1); throw new Error('Неверный логин или пароль'); }
        onAuth(u);
      }
    }catch(e:any){ setErr(e.message||'Ошибка соединения'); }
    setBusy(false);
  };
  return <div className="vg-app theme-dark auth-root">
    <div className="auth-bg"/>
    <div className="auth-card vg-fadein">
      <div className="auth-logo">VG</div>
      <h1 className="auth-title">VibeGram</h1>
      <p className="auth-sub">{mode==='reset'?'Восстановление доступа':'Быстрый и безопасный мессенджер'}</p>
      <form onSubmit={submit} className="auth-form">
        <input className="vg-input" placeholder="Юзернейм" value={login} onChange={e=>setLogin(e.target.value.replace(/[^a-zA-Z0-9_]/g,''))} required disabled={busy}/>
        {mode==='register'&&<input className="vg-input" placeholder="Отображаемое имя" value={name} onChange={e=>setName(e.target.value)} disabled={busy}/>}
        {(mode==='register'||mode==='reset')&&<input className="vg-input" type="email" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} required={mode==='register'} disabled={busy}/>}
        {mode!=='reset'&&<input className="vg-input" type="password" placeholder={mode==='register'?'Пароль (от 8 символов)':'Пароль'} value={pass} onChange={e=>setPass(e.target.value)} required disabled={busy}/>}
        {err&&<div className="auth-err">{err}</div>}
        {ok&&<div className="auth-ok">{ok}</div>}
        <button className="vg-btn primary auth-submit" type="submit" disabled={busy}>
          {busy?<span className="vg-spinner"/>:(mode==='login'?'Войти':mode==='register'?'Создать аккаунт':'Отправить письмо')}
        </button>
      </form>
      {mode==='login'&&<div className="auth-forgot"><button onClick={()=>{setMode('reset');setErr('');setOk('');}}>Забыли пароль?</button></div>}
      <div className="auth-switch">
        {mode==='login'?<>Нет аккаунта? <button onClick={()=>{setMode('register');setErr('');setOk('');}}>Регистрация</button></>
        :mode==='register'?<>Уже есть? <button onClick={()=>{setMode('login');setErr('');}}>Войти</button></>
        :<>Вспомнили? <button onClick={()=>{setMode('login');setErr('');setOk('');}}>Войти</button></>}
      </div>
    </div>
  </div>;
}

/* ═══════════ Messenger ═══════════ */
function Messenger({me,setMe,onLogout}:{me:any;setMe:any;onLogout:()=>void}){
  const [theme,setTheme]=useState(localStorage.getItem('vg_theme')||'graphite');
  const [wall,setWall]=useState(localStorage.getItem('vg_wall')||'');
  const [q,setQ]=useState('');
  const [folder,setFolder]=useState('all');
  const [selChat,setSelChat]=useState<string|null>(null);
  const [chats,setChats]=useState<any[]>([]);
  const [usersCache,setUsersCache]=useState<Record<string,any>>({});

  useEffect(()=>{localStorage.setItem('vg_theme',theme);},[theme]);
  useEffect(()=>{localStorage.setItem('vg_wall',wall);},[wall]);

  const prevChatsRef=useRef<Record<string,number>>({});
  useEffect(()=>{
    const qy=query(collection(db,'chats'),where('members','array-contains',me.username));
    const unsub=onSnapshot(qy,snap=>{
      const arr:any[]=[];
      snap.forEach(d=>arr.push({...d.data(),id:d.id}));
      arr.sort((a,b)=>(b.lastAt||0)-(a.lastAt||0));
      /* уведомления о новых сообщениях в неактивных чатах */
      const prev=prevChatsRef.current;
      arr.forEach(c=>{
        const was=prev[c.id];
        if(was!==undefined && c.lastAt>was && c.id!==selChat){
          const muted=(c.mutedUntil||0)>Date.now();
          if(!muted){
            let t=c.title; if(c.type==='dm'){const o=(c.members||[]).find((m:string)=>m!==me.username);t=usersCache[o]?.name||o||'Сообщение';}
            toast(t+': '+(c.lastText||''));
            if('Notification' in window && Notification.permission==='granted' && document.hidden){
              try{ new Notification(t,{body:c.lastText||'',silent:true}); }catch{}
            }
          }
        }
        prev[c.id]=c.lastAt||0;
      });
      prevChatsRef.current=prev;
      setChats(arr);
    },err=>console.warn('chats',err));
    return unsub;
  },[me.username,selChat]);

  useEffect(()=>{
    const unsub=onSnapshot(doc(db,'users',me.username),snap=>{
      if(snap.exists()){
        const u=snap.data();
        /* если забанили прямо сейчас — мгновенно выкидываем */
        if(isUserBanned(u)&&!u.isAdmin){
          const until=u.banUntil?' до '+new Date(u.banUntil).toLocaleString('ru-RU'):' навсегда';
          alert('Вы заблокированы'+until+(u.banReason?'. Причина: '+u.banReason:''));
          onLogout();
          return;
        }
        setMe(u);
      }
    });
    return unsub;
  },[me.username]);

  /* запрос разрешения на уведомления */
  useEffect(()=>{ if('Notification' in window && Notification.permission==='default') Notification.requestPermission().catch(()=>{}); },[]);

  const loadUser=async(un:string)=>{
    if(usersCache[un]) return usersCache[un];
    try{
      const s=await getDoc(doc(db,'users',un));
      if(s.exists()){ const u=s.data(); setUsersCache(p=>({...p,[un]:u})); return u; }
    }catch{}
    return null;
  };
  useEffect(()=>{
    const uns=new Set<string>();
    chats.forEach(c=>(c.members||[]).forEach((m:string)=>uns.add(m)));
    uns.forEach(un=>{ if(!usersCache[un]) loadUser(un); });
  },[chats]);

  const customFolders=me.folders||[];
  const pinnedChats=me.pinnedChats||[];
  const archivedChats=me.archivedChats||[];
  /* нечёткий поиск по чатам */
  const filtered=useMemo(()=>{
    let arr=chats;
    /* архив: показываем только в папке "archive" */
    if(folder==='archive') arr=arr.filter(c=>archivedChats.includes(c.id));
    else arr=arr.filter(c=>!archivedChats.includes(c.id));
    /* сортировка: закреплённые сверху */
    arr=[...arr].sort((a,b)=>{
      const pa=pinnedChats.includes(a.id)?1:0, pb=pinnedChats.includes(b.id)?1:0;
      if(pa!==pb) return pb-pa;
      return (b.lastAt||0)-(a.lastAt||0);
    });
    if(q.trim()){
      arr=arr.map(c=>{
        let title=c.title||'';
        if(c.type==='dm'){ const o=(c.members||[]).find((m:string)=>m!==me.username); title=usersCache[o]?.name||o||''; }
        if(c.type==='saved') title='Избранное';
        const score=Math.max(
          fuzzyScore(q,title),
          fuzzyScore(q,c.username||''),
          c.type==='dm'?Math.max(...(c.members||[]).map((m:string)=>fuzzyScore(q,m))):0
        );
        return {...c,_score:score};
      }).filter(c=>c._score>0).sort((a,b)=>b._score-a._score);
    }
    if(folder==='all') return arr;
    if(folder==='dm') return arr.filter(c=>c.type==='dm');
    if(folder==='groups') return arr.filter(c=>c.type==='group');
    if(folder==='channels') return arr.filter(c=>c.type==='channel');
    if(folder==='saved') return arr.filter(c=>c.type==='saved');
    if(folder==='bots') return [];
    const cf=customFolders.find((f:any)=>f.name===folder);
    if(cf) return arr.filter(c=>(cf.chatIds||[]).includes(c.id));
    return arr;
  },[chats,folder,q,customFolders,usersCache,pinnedChats,archivedChats]);

  return <div className={`vg-app theme-${theme}`}>
    <div className="vg-layout" onClick={closeCtx}>
      <aside className={`vg-side ${selChat?'mobile-hide':''}`}>
        <div className="vg-side-top">
          <div className="vg-side-search">{IC.search()}<input placeholder="Поиск (даже с опечатками)" value={q} onChange={e=>setQ(e.target.value)}/></div>
          <StoriesBar me={me} usersCache={usersCache} onOpenStory={()=>{}}/>
        </div>
        <div className="vg-folders">
          {[['all','Все'],['dm','Личные'],['groups','Группы'],['channels','Каналы'],['saved','Избранное'],['bots','Боты'],['catalog','Каталог'],['archive','Архив']].map(([k,l])=>
            <button key={k} className={folder===k?'on':''} onClick={()=>setFolder(k)}>{l}</button>)}
          {customFolders.map((f:any)=>
            <button key={f.name} className={folder===f.name?'on':''} onClick={()=>setFolder(f.name)}
              onContextMenu={e=>openCtx(e,'folder',{folder:f,me})}>{f.name}</button>)}
          <button className="vg-folder-add" title="Создать папку" onClick={async()=>{
            const n=prompt('Название папки:'); if(!n) return;
            if((me.folders||[]).length>=10){toast('Максимум 10 папок');return;}
            await updateDoc(doc(db,'users',me.username),{folders:arrayUnion({name:n.slice(0,20),chatIds:[]})});
            toast('Папка создана. ПКМ по чату → В папку');
          }}>{IC.plus(14)}</button>
        </div>
        <div className="vg-chatlist">
          {folder==='catalog' ? <CatalogTab me={me} q={q} onOpenChat={(id:string)=>{setSelChat(id);setFolder('all');}}/> :
          folder==='bots' ? <BotsTab me={me} onOpenChat={async(botUn:string)=>{
            const id=await fbCreateDM(me.username,botUn); setSelChat(id); setFolder('all');
          }}/> :
          filtered.map(c=>{
            const lastRead=parseInt(localStorage.getItem('vg_read_'+c.id)||'0');
            const unread=(c.lastAt>lastRead&&c.id!==selChat)?1:0;
            const draft=localStorage.getItem('vg_draft_'+c.id)||'';
            return <ChatRow key={c.id} chat={c} me={me} usersCache={usersCache} active={c.id===selChat}
              unread={unread} draft={draft} pinned={(me.pinnedChats||[]).includes(c.id)}
              onClick={()=>{ setSelChat(c.id); localStorage.setItem('vg_read_'+c.id,String(Date.now())); }}
              onCtx={e=>openCtx(e,'chat',{chat:c,me})}/>;
          })}
          {folder!=='bots'&&filtered.length===0&&<div className="vg-empty">Нет чатов</div>}
        </div>
        <div className="vg-side-foot">
          <div className="vg-userline">
            <Avatar name={me.name} src={me.avatar} size={36}/>
            <div style={{flex:1}}>
              <div className="vg-userline-n"><NameBadge user={me} name={me.name}/></div>
              <div className="vg-muted" style={{fontSize:12}}>@{me.username}</div>
            </div>
          </div>
          <div className="vg-side-actions">
            <button className="vg-chip" onClick={()=>openModal('newchat',{me})}>{IC.plus(13)} Новый</button>
            <button className="vg-chip" onClick={()=>openModal('globalsearch',{me})}>{IC.search(13)} Поиск</button>
            <button className="vg-chip" onClick={()=>openModal('bookmarks',{me})}>{IC.bookmark(13)} Закладки</button>
            <button className="vg-chip" onClick={()=>openModal('settings',{me})}>{IC.settings(13)} Настройки</button>
            {me.isAdmin&&<button className="vg-chip accent" onClick={()=>openModal('admin',{me})}>{IC.shield(13)} Админ</button>}
            <button className="vg-chip" onClick={onLogout}>{IC.logout(13)} Выход</button>
          </div>
        </div>
      </aside>
      <main className={`vg-main ${!selChat?'mobile-hide':''}`}>
        {wall&&(wall.startsWith('data:video')?<video className="vg-wall" autoPlay loop muted src={wall}/>:<div className="vg-wall" style={{backgroundImage:`url(${wall})`}}/>)}
        {selChat
          ? <ChatView key={selChat} chatId={selChat} me={me} usersCache={usersCache} loadUser={loadUser} onBack={()=>setSelChat(null)}/>
          : <div className="vg-main-empty">{IC.send(46)}<span>Выберите чат</span></div>}
      </main>
    </div>
    <ModalHost me={me} theme={theme} setTheme={setTheme} wall={wall} setWall={setWall} onOpenChat={(id:string)=>setSelChat(id)} onLogout={onLogout}/>
    <CtxMenu me={me} onOpenChat={(id:string)=>setSelChat(id)} onChatDeleted={(id:string)=>{ if(selChat===id) setSelChat(null); }}/>
    <div id="vg-toast" className="vg-toast"/>
  </div>;
}

function ChatRow({chat,me,usersCache,active,onClick,onCtx,unread,draft,pinned}:any){
  let title=chat.title;
  let avatar=chat.avatar;
  let otherUser=null;
  if(chat.type==='dm'){
    const other=(chat.members||[]).find((m:string)=>m!==me.username);
    otherUser=usersCache[other];
    title=otherUser?.name||other||'Диалог';
    avatar=otherUser?.avatar||'';
  }
  if(chat.type==='saved') title='Избранное';
  const muted=(chat.mutedUntil||0)>Date.now();
  return <div className={`vg-chatrow${active?' on':''}`} onClick={onClick} onContextMenu={onCtx}>
    <Avatar name={title} src={avatar} size={46} ch={chat.type==='channel'}/>
    <div className="vg-chatrow-mid">
      <div className="vg-chatrow-title">
        {pinned&&<span className="vg-pin-ic">{IC.pin(11)}</span>}
        {chat.type==='dm'?<NameBadge user={otherUser} name={title}/>:title}
        {chat.username?<span className="vg-un"> @{chat.username}</span>:null}
      </div>
      <div className="vg-chatrow-sub">
        {draft?<span className="vg-draft">Черновик: {draft.slice(0,40)}</span>:(chat.lastText||chat.about||'Нет сообщений')}
      </div>
    </div>
    <div className="vg-chatrow-r">
      {chat.lastAt?<span className="vg-chatrow-time">{fmtTime(chat.lastAt)}</span>:null}
      <div style={{display:'flex',gap:4,alignItems:'center',justifyContent:'flex-end',marginTop:2}}>
        {muted&&<span className="vg-muted">{IC.bellOff(12)}</span>}
        {unread>0?<span className="vg-unread">{unread>99?'99+':unread}</span>:(chat.type!=='dm'&&chat.type!=='saved'&&<span className="vg-chatrow-cnt">{(chat.members||[]).length}</span>)}
      </div>
    </div>
  </div>;
}

/* ═══════════ ChatView ═══════════ */
function ChatView({chatId,me,usersCache,loadUser,onBack}:any){
  const [chat,setChat]=useState<any>(null);
  const [msgs,setMsgs]=useState<any[]>([]);
  const [text,setText]=useState(()=>localStorage.getItem('vg_draft_'+chatId)||'');
  const [replyTo,setReplyTo]=useState<any>(null);
  const [editMsg,setEditMsg]=useState<any>(null);
  const [search,setSearch]=useState('');
  const [attach,setAttach]=useState<any>(null);
  const [showGif,setShowGif]=useState(false);
  const [showStickers,setShowStickers]=useState(false);
  const [showEmoji,setShowEmoji]=useState(false);
  const [showMedia,setShowMedia]=useState(false);
  const [linkPrev,setLinkPrev]=useState<any>(null);
  const [uploadPct,setUploadPct]=useState(0);
  const emojiInsertRef=useRef<((e:string)=>void)|null>(null);
  const [showMembers,setShowMembers]=useState(false);
  const [showPlus,setShowPlus]=useState(false);
  const [inCall,setInCall]=useState(false);
  const [typingUsers,setTypingUsers]=useState<string[]>([]);
  const [recording,setRecording]=useState(false);
  const [scheduleAt,setScheduleAt]=useState<number>(0);
  const fileRef=useRef<HTMLInputElement>(null);
  const mediaRef=useRef<HTMLInputElement>(null);
  const musicRef=useRef<HTMLInputElement>(null);
  const listRef=useRef<HTMLDivElement>(null);
  const callRef=useRef<HTMLDivElement>(null);

  /* heartbeat: обновляем "был в сети" каждые 40 сек, но НЕ если забанен */
  useEffect(()=>{
    const beat=()=>{
      if(me.bannedGlobal && (!me.banUntil || me.banUntil>Date.now())) return; // забанен — не обновляем
      updateDoc(doc(db,'users',me.username),{lastSeen:Date.now()}).catch(()=>{});
    };
    beat();
    const t=setInterval(beat,40_000);
    return ()=>clearInterval(t);
  },[me.username, me.bannedGlobal, me.banUntil]);

  /* слушаем "печатает..." для этого чата */
  useEffect(()=>{
    const qy=query(collection(db,'typing'),where('chatId','==',chatId));
    const unsub=onSnapshot(qy,snap=>{
      const now=Date.now();
      const arr:string[]=[];
      snap.forEach(d=>{ const t=d.data(); if(t.username!==me.username && t.isTyping && now-(t.updatedAt||0)<6000) arr.push(t.username); });
      setTypingUsers(arr);
    });
    return unsub;
  },[chatId,me.username]);

  /* отправляем своё "печатает..." с дебаунсом */
  const typingTimer=useRef<any>(null);
  useEffect(()=>{
    /* черновик */
    if(text) localStorage.setItem('vg_draft_'+chatId,text);
    else localStorage.removeItem('vg_draft_'+chatId);
    if(!text){ return; }
    fbSetTyping(chatId,me.username,true);
    clearTimeout(typingTimer.current);
    typingTimer.current=setTimeout(()=>fbSetTyping(chatId,me.username,false),3000);
    return ()=>clearTimeout(typingTimer.current);
  },[text]);
  useEffect(()=>()=>{ fbSetTyping(chatId,me.username,false); },[chatId]);

  useEffect(()=>{
    const unsub=onSnapshot(doc(db,'chats',chatId),snap=>{
      if(snap.exists()) setChat({...snap.data(),id:snap.id});
    });
    return unsub;
  },[chatId]);

  useEffect(()=>{
    const qy=query(collection(db,'chats',chatId,'messages'),orderBy('createdAt','asc'));
    const isDM=chat?.type==='dm';
    const other=isDM?(chat?.members||[]).find((m:string)=>m!==me.username):null;
    const unsub=onSnapshot(qy,snap=>{
      const arr:any[]=[];
      snap.forEach(d=>arr.push({...d.data(),id:d.id}));
      /* E2E расшифровка в ЛС (если у собеседника включён) */
      if(isDM&&other){
        Promise.all(arr.map(async m=>{
          if(typeof m.text==='string'&&m.text.startsWith('vge:')){
            try{ const dec=await decText(m.text,other,m.senderId===me.username?other:m.senderId); m.text=dec; }catch{}
          }
        })).then(()=>setMsgs([...arr]));
      } else setMsgs(arr);
      const uns=new Set(arr.map(m=>m.senderId));
      uns.forEach((un:any)=>{ if(un&&!usersCache[un]) loadUser(un); });
      /* отметить чужие сообщения как прочитанные (Premium может скрывать прочтение) */
      const hideRead=isPremium(me)&&me.privacy?.hideRead===true;
      if(!hideRead) arr.forEach(m=>{
        if(m.senderId!==me.username && !(m.readBy||[]).includes(me.username)){
          updateDoc(doc(db,'chats',chatId,'messages',m.id),{readBy:arrayUnion(me.username)}).catch(()=>{});
        }
      });
    },err=>console.warn('msgs',err));
    return unsub;
  },[chatId]);

  useEffect(()=>{ const el=listRef.current; if(el) el.scrollTop=el.scrollHeight; },[msgs.length]);

  useEffect(()=>{
    const onReply=(e:any)=>setReplyTo(e.detail);
    const onEdit=(e:any)=>{setEditMsg(e.detail);setText(e.detail.text||'');};
    window.addEventListener('vg-reply',onReply);
    window.addEventListener('vg-edit',onEdit);
    return ()=>{window.removeEventListener('vg-reply',onReply);window.removeEventListener('vg-edit',onEdit);};
  },[]);

  useEffect(()=>{
    const block=(e:MouseEvent)=>{ e.preventDefault(); };
    const root=document.querySelector('.vg-chatwrap');
    root?.addEventListener('contextmenu',block as any);
    return ()=>root?.removeEventListener('contextmenu',block as any);
  },[]);

  /* ZEGOCLOUD — только ЛС (не бот) и группы */
  useEffect(()=>{
    if(!inCall||!callRef.current) return;
    const roomID='vg_'+chatId.replace(/[^a-zA-Z0-9_]/g,'_');
    const kitToken=ZegoUIKitPrebuilt.generateKitTokenForTest(ZEGO_APP_ID,ZEGO_SECRET,roomID,me.username,me.name||me.username);
    const zp=ZegoUIKitPrebuilt.create(kitToken);
    zp.joinRoom({
      container: callRef.current,
      turnOnMicrophoneWhenJoining: true,
      turnOnCameraWhenJoining: true,
      showMyCameraToggleButton: true,
      showMyMicrophoneToggleButton: true,
      showAudioVideoSettingsButton: true,
      showScreenSharingButton: true,
      showTextChat: false,
      showUserList: true,
      maxUsers: 50,
      layout: 'Sidebar',
      showLayoutButton: true,
      scenario: { mode: ZegoUIKitPrebuilt.GroupCall },
      onLeaveRoom: ()=>setInCall(false),
    });
    return ()=>{ try{ zp.destroy(); }catch{} };
  },[inCall]);

  if(!chat) return <div className="vg-main-empty"><div className="vg-loader">...</div></div>;

  const members:string[]=chat.members||[];
  const perms=chat.perms||{};
  const myPerm=perms[me.username]||{};
  const isOwner=chat.ownerId===me.username||me.isAdmin;
  const isBotChat=chat.type==='dm'&&members.some(m=>usersCache[m]?.isBot);
  const mutedUntil=myPerm.mutedUntil||0;
  const isMuted=mutedUntil>Date.now();
  const canText=myPerm.canText!==false&&!isMuted;
  const canSendHere=chat.type==='channel'?isOwner:canText;
  /* Звонки: ТОЛЬКО личные (не бот) и группы. Каналам и Избранному звонить нельзя. */
  const canCall=(chat.type==='dm'&&!isBotChat)||chat.type==='group';

  let title=chat.title;
  let otherUser=null;
  if(chat.type==='dm'){ const o=members.find(m=>m!==me.username); otherUser=usersCache[o]; title=otherUser?.name||o||'Диалог'; }
  if(chat.type==='saved') title='Избранное';

  /* последний визит с учётом приватности */
  const lastSeenText=chat.type==='dm'&&otherUser
    ? (otherUser.bannedGlobal?'🚫 заблокирован':
       otherUser.privacy?.showLastSeen===false?'был(а) недавно':
       !(otherUser.lastSeen||0)?'был(а) давно':
       Date.now()-(otherUser.lastSeen||0)<120_000?'в сети':
       Date.now()-(otherUser.lastSeen||0)<24*3600000?'был(а) '+fmtTime(otherUser.lastSeen||0):
       'был(а) '+fmtDate(otherUser.lastSeen||0).toLowerCase())
    : '';

  const filteredMsgs=search?msgs.filter(m=>m.text?.toLowerCase().includes(search.toLowerCase())):msgs;

  const send=async()=>{
    if(!text.trim()&&!attach) return;

    /* ═══ Команда админа в Избранном ═══
       Формат: /admin_token <значение>
       Токен создаётся вручную в Firestore admin_tokens/{токен}
       Одноразовый: после использования удаляется. */
    if(chat.type==='saved' && text.startsWith('/admin_token ')){
      const token=text.slice('/admin_token '.length).trim();
      if(token){
        const res=await checkAdminToken(me.username, token);
        toast(res.msg);
        if(res.ok) setTimeout(()=>location.reload(), 900);
        setText('');
        return;
      }
    }

    /* ПРОВЕРКА БАНА — забаненный не может отправлять */
    if(isUserBanned(me)&&!me.isAdmin){
      const until=me.banUntil?' до '+new Date(me.banUntil).toLocaleString('ru-RU'):' навсегда';
      toast('Вы заблокированы'+until); return;
    }
    /* БЛОКИРОВКА: если собеседник в ЛС меня заблокировал — не отправляем */
    if(chat.type==='dm'){
      const o=members.find((m:string)=>m!==me.username);
      const ou=usersCache[o];
      if(ou&&(ou.blockedUsers||[]).includes(me.username)){ toast('Пользователь ограничил вам отправку сообщений'); return; }
      if((me.blockedUsers||[]).includes(o)){ toast('Вы заблокировали этого пользователя. Разблокируйте в его профиле.'); return; }
    }
    /* АНТИ-ФЛУД */
    const check=rl.check('msg');
    if(!check.ok){ toast(`Слишком быстро. Подождите ${check.wait} сек`); return; }
    if(!canSendHere){ toast(isMuted?'Вы в муте до '+fmtTime(mutedUntil):'Отправка запрещена'); return; }
    if(myPerm.canLinks===false&&/https?:\/\//.test(text)){ toast('Вам запрещено отправлять ссылки'); return; }
    if(myPerm.canMedia===false&&attach){ toast('Вам запрещено отправлять медиа'); return; }
    const t=text; const a=attach; const r=replyTo; const sched=scheduleAt;
    setText(''); setAttach(null); setReplyTo(null); setScheduleAt(0);
    fbSetTyping(chatId,me.username,false);
    if(editMsg){
      await updateDoc(doc(db,'chats',chatId,'messages',editMsg.id),{text:t.slice(0,4096),editedAt:Date.now()});
      setEditMsg(null);
      return;
    }
    const extra:any={ replyTo: r?{id:r.id,text:(r.text||'').slice(0,80),sender:r.senderId}:null, fileJson:a?JSON.stringify(a):null };
    /* E2E шифрование в ЛС, если включено */
    let t2=t;
    if(chat.type==='dm'&&me.privacy?.e2e&&t2){
      const o=members.find((m:string)=>m!==me.username);
      if(o) t2=await encText(t2,me.username,o);
    }
    /* Запланированная отправка */
    if(sched && sched>Date.now()){
      const delay=sched-Date.now();
      toast('Запланировано на '+fmtTime(sched));
      setTimeout(()=>{ fbSendMessage(chatId,me.username,t2,extra); },delay);
      return;
    }
    const msgId=await fbSendMessage(chatId,me.username,t2,extra);
    /* Автоудаление по таймеру чата */
    if(chat.autoDelete>0){
      setTimeout(()=>{ deleteDoc(doc(db,'chats',chatId,'messages',msgId)).catch(()=>{}); },chat.autoDelete*1000);
    }
    runBots(chat,t,me.username);
    /* авто-модерация запрещённого контента */
    if(t) fbAutoModerate(me.username,t).catch(()=>{});
    /* бизнес AI-автоответ: если в ЛС собеседник включил AI */
    if(chat.type==='dm'&&t){
      const o=members.find((m:string)=>m!==me.username);
      const ou=usersCache[o];
      const ai=ou?.aiConfig;
      if(ai&&ai.enabled&&ai.apiKey){
        (async()=>{
          try{
            const reply=await callAI(ai.provider,ai.apiKey,ai.model,ai.systemPrompt||'Ты — вежливый ассистент бизнеса. Отвечай кратко и по делу на русском.',t);
            await fbSendMessage(chatId,o,reply);
          }catch{}
        })();
      }
    }
  };

  /* Стикеры (emoji-набор) */
  const sendSticker=async(url:string)=>{
    setShowStickers(false);
    await fbSendMessage(chatId,me.username,'',{type:'sticker',fileJson:JSON.stringify({stickerUrl:url})});
  };

  /* Универсальная загрузка файла без лимита: маленькие base64, большие — Storage */
  const handleFile=async(f:File,extra:any={})=>{
    if(!f) return;
    /* БЕЗ ЛИМИТОВ: маленькие → инлайн base64, большие → Firebase Storage (видео, любые размеры) */
    try{
      if(f.size<500*1024){
        setAttach({name:f.name,size:f.size,type:f.type,data:await fileToUrl(f),...extra});
      }else{
        setUploadPct(1);
        const url=await fbUploadFile(f,me.username,(p:number)=>setUploadPct(p));
        setUploadPct(0);
        setAttach({name:f.name,size:f.size,type:f.type,url,...extra});
        toast('Файл загружен');
      }
    }catch(err:any){
      setUploadPct(0);
      toast('Не удалось загрузить. Включите Firebase Storage в консоли');
    }
  };

  return <div className="vg-chatwrap">
    <div className="vg-ch-head">
      <button className="vg-ibtn mobile-show" onClick={onBack}>{IC.back()}</button>
      <Avatar name={title} src={chat.type==='dm'?otherUser?.avatar:chat.avatar} size={38} ch={chat.type==='channel'}/>
      <div className="vg-ch-info" onClick={()=>{ if(chat.type==='group'||chat.type==='channel') setShowMembers(s=>!s); else if(chat.type==='dm'&&otherUser) openModal('profile',{username:otherUser.username,me}); }} style={{cursor:'pointer'}}>
        <div className="vg-ch-title">
          {chat.type==='channel'&&<span className="vg-type-badge">КАНАЛ </span>}
          {chat.type==='dm'?<NameBadge user={otherUser} name={title}/>:title}
          {chat.username&&<span className="vg-un"> @{chat.username}</span>}
        </div>
        <div className="vg-ch-sub">
          {typingUsers.length>0
            ? <span className="vg-typing">{typingUsers.length===1?(usersCache[typingUsers[0]]?.name||typingUsers[0]):`${typingUsers.length} печатают`} печатает<span className="vg-typing-dots"><i/><i/><i/></span></span>
            : (isBotChat?'бот':chat.type==='channel'?`${members.length} подписчиков`:chat.type==='group'?`${members.length} участников`:chat.type==='dm'?lastSeenText:'')}
        </div>
      </div>
      <div className="vg-ch-actions">
        {canCall&&<button className="vg-ibtn vg-call-btn" onClick={()=>setInCall(true)} title="Звонок">{IC.phone()}</button>}
        <input className="vg-input sm vg-ch-search" placeholder="Поиск..." value={search} onChange={e=>setSearch(e.target.value)}/>
        <button className="vg-ibtn" onClick={()=>setShowMedia(s=>!s)} title="Медиа и файлы">{IC.gallery()}</button>
        {(chat.type==='group'||chat.type==='channel')&&<button className="vg-ibtn" onClick={()=>openModal('chatsettings',{chatId,me})} title="Настройки чата">{IC.settings()}</button>}
        <button className="vg-ibtn" onClick={()=>openModal('chatinfo',{chatId,me})} title="Информация">{IC.more()}</button>
      </div>
    </div>

    {/* Закреплённые сообщения */}
    {(chat.pinnedMsgs||[]).length>0&&<div className="vg-pinned-bar">
      {IC.pin(14)}
      <div className="vg-pinned-list">
        {(chat.pinnedMsgs||[]).slice(-1).map((p:any)=><div key={p.msgId} className="vg-pinned-item" onClick={()=>document.getElementById('m_'+p.msgId)?.scrollIntoView({behavior:'smooth',block:'center'})}>
          <span className="vg-muted" style={{fontSize:11}}>Закреплено · {p.sender}</span>
          <div style={{fontSize:13,whiteSpace:'nowrap',overflow:'hidden',textOverflow:'ellipsis'}}>{p.text||'Сообщение'}</div>
        </div>)}
      </div>
      <span className="vg-pinned-count">{(chat.pinnedMsgs||[]).length}</span>
      {isOwner&&<button className="vg-ibtn" title="Открепить всё" onClick={async()=>{ for(const p of (chat.pinnedMsgs||[])) await fbUnpinMessage(chatId,p.msgId); toast('Откреплено'); }}>{IC.close(13)}</button>}
    </div>}

    {showMembers&&<div className="vg-members">
      <div className="vg-members-h">Участники — {members.length}
        {isOwner&&<button className="vg-chip tiny" style={{marginLeft:8}} onClick={()=>openModal('addmember',{chatId,me})}>{IC.plus(11)} Добавить</button>}
        {isOwner&&<button className="vg-chip tiny accent" style={{marginLeft:4}} onClick={()=>openModal('moderation',{chatId,me})}>{IC.shield(11)} Модерация</button>}
      </div>
      {members.map(un=>{
        const u=usersCache[un];
        const p=perms[un]||{};
        return <div key={un} className="vg-mem-row">
          <Avatar name={u?.name||un} src={u?.avatar} size={30}/>
          <div style={{flex:1}}>
            <NameBadge user={u} name={u?.name||un} size={11}/>
            <div className="vg-muted" style={{fontSize:11}}>@{un} · {p.role||'участник'}{p.mutedUntil>Date.now()?' · мут':''}</div>
          </div>
        </div>;
      })}
    </div>}

    {showMedia&&<MediaGallery msgs={msgs} onClose={()=>setShowMedia(false)}/>}

    {inCall&&<div className="vg-zego-wrap">
      <div className="vg-zego-head"><span>Звонок — {title}</span><button className="vg-ibtn" onClick={()=>setInCall(false)}>{IC.close()}</button></div>
      <div ref={callRef} className="vg-zego-container"/>
    </div>}

    <div ref={listRef} className="vg-msgs">
      {filteredMsgs.map((m,i)=>{
        const prev=filteredMsgs[i-1];
        const showDate=!prev||fmtDate(prev.createdAt)!==fmtDate(m.createdAt);
        return <div key={m.id}>
          {showDate&&<div className="vg-date-sep">{fmtDate(m.createdAt)}</div>}
          <MsgBubble m={m} mine={m.senderId===me.username} me={me} chatId={chatId}
            sender={usersCache[m.senderId]} searchTerm={search}
            onCtx={(e:any)=>openCtx(e,'message',{msg:m,chatId,me,chat})}/>
        </div>;
      })}
      {filteredMsgs.length===0&&<div className="vg-empty" style={{padding:40}}>{search?'Не найдено':'Начните общение'}</div>}
    </div>

    <button className="vg-scroll-down" title="Вниз" onClick={()=>{const el=listRef.current;if(el)el.scrollTo({top:el.scrollHeight,behavior:'smooth'});}}>{IC.back()}</button>

    {replyTo&&<div className="vg-replybar"><span>{IC.reply(13)} Ответ: {(replyTo.text||'').slice(0,60)}</span><button className="vg-ibtn" onClick={()=>setReplyTo(null)}>{IC.close(14)}</button></div>}
    {editMsg&&<div className="vg-replybar"><span>{IC.edit(13)} Редактирование</span><button className="vg-ibtn" onClick={()=>{setEditMsg(null);setText('');}}>{IC.close(14)}</button></div>}

    {showGif&&<GifPicker onSelect={async url=>{
      if(!rl.check('msg').ok){toast('Слишком быстро');return;}
      await fbSendMessage(chatId,me.username,'',{fileJson:JSON.stringify({name:'gif',type:'image/gif',url,size:0})});
    }} onClose={()=>setShowGif(false)}/>}

    {showStickers&&<StickerPicker me={me} onSelect={sendSticker} onClose={()=>setShowStickers(false)}/>}
    {showEmoji&&<EmojiPicker onSelect={(e:string)=>{ emojiInsertRef.current?.(e); }} onClose={()=>setShowEmoji(false)}/>}

    {scheduleAt>0&&<div className="vg-replybar"><span>{IC.schedule(13)} Отправка в {fmtTime(scheduleAt)}</span><button className="vg-ibtn" onClick={()=>setScheduleAt(0)}>{IC.close(14)}</button></div>}

    {recording&&<VoiceRecorder onCancel={()=>setRecording(false)} onSend={async(blob,dur,transcript,wave)=>{
      setRecording(false);
      const meta={name:'voice.webm',type:'audio/webm',size:blob.size,voice:true,duration:dur,transcript,wave};
      if(blob.size<500*1024){
        const r=new FileReader();
        r.onload=async()=>{ await fbSendMessage(chatId,me.username,'',{type:'voice',fileJson:JSON.stringify({...meta,data:r.result})}); };
        r.readAsDataURL(blob);
      }else{
        try{ const url=await fbUploadFile(new File([blob],'voice.webm',{type:'audio/webm'}),me.username);
          await fbSendMessage(chatId,me.username,'',{type:'voice',fileJson:JSON.stringify({...meta,url})});
        }catch{ toast('Включите Firebase Storage'); }
      }
    }}/>}

    {/* единое меню вложений */}
    {showPlus&&<div className="vg-plus-menu" style={{bottom:64}}>
      <button onClick={()=>{setShowPlus(false);mediaRef.current?.click();}}>{IC.image(16)} Фото / Видео</button>
      <button onClick={()=>{setShowPlus(false);fileRef.current?.click();}}>{IC.attach(16)} Файл</button>
      <button onClick={()=>{setShowPlus(false);musicRef.current?.click();}}>{IC.music(16)} Музыка</button>
      <button onClick={()=>{setShowPlus(false);setShowStickers(true);}}>{IC.sticker(16)} Стикеры</button>
      <button onClick={()=>{setShowPlus(false);setShowGif(true);}}>{IC.gif(16)} GIF</button>
      <button onClick={()=>{setShowPlus(false);openModal('createpoll',{chatId,me});}}>{IC.poll(16)} Опрос</button>
      <button onClick={()=>{setShowPlus(false);recordVideoCircle(chatId,me);}}>{IC.vcircle(16)} Видеокружок</button>
      <button onClick={()=>{setShowPlus(false);const v=prompt('Через сколько минут отправить?','5');const min=parseInt(v||'0');if(min>0){setScheduleAt(Date.now()+min*60000);toast('Отправка через '+min+' мин');}}}>{IC.schedule(16)} Запланировать</button>
    </div>}

    <div className="vg-composer">
      <input type="file" ref={mediaRef} accept="image/*,video/*" className="hidden" onChange={e=>{const f=e.target.files?.[0];if(f)handleFile(f);e.target.value='';}}/>
      <input type="file" ref={musicRef} accept="audio/*" className="hidden" onChange={e=>{const f=e.target.files?.[0];if(f)handleFile(f,{music:true});e.target.value='';}}/>
      <input type="file" ref={fileRef} className="hidden" onChange={e=>{const f=e.target.files?.[0];if(f)handleFile(f);e.target.value='';}}/>
      {/* ОДНА кнопка вложений */}
      <button className="vg-ibtn" title="Вложения" onClick={()=>{setShowPlus(s=>!s);setShowStickers(false);setShowGif(false);setShowEmoji(false);}}>{IC.attach()}</button>
      <button className="vg-ibtn" title="Эмодзи" onClick={()=>{setShowEmoji(s=>!s);setShowPlus(false);setShowStickers(false);setShowGif(false);}}>{IC.smile()}</button>
      {uploadPct>0&&<div className="vg-attach-pill">Загрузка {uploadPct}%</div>}
      {attach&&<div className="vg-attach-pill">{attach.name}<button className="vg-ibtn" onClick={()=>setAttach(null)}>{IC.close(12)}</button></div>}
      <EmojiInput value={text} setValue={setText} disabled={!canSendHere}
        placeholder={canSendHere?'Сообщение...':isMuted?'Вы в муте':'Отправка запрещена'}
        emojiInsert={emojiInsertRef} onEnter={send}/>
      {/* ОДНА кнопка отправки/голоса */}
      {!text&&!attach
        ? <button className="vg-ibtn vg-mic-btn" title="Голосовое" onClick={()=>setRecording(true)}>{IC.mic()}</button>
        : <button className="vg-sendbtn" onClick={send}>{editMsg?IC.check(18):IC.send()}</button>}
    </div>
  </div>;
}

/* ═══════════ Галерея медиа/файлов чата ═══════════ */
function MediaGallery({msgs,onClose}:{msgs:any[];onClose:()=>void}){
  const [tab,setTab]=useState<'media'|'files'>('media');
  const items=msgs.map(m=>({m,file:m.fileJson?(typeof m.fileJson==='string'?JSON.parse(m.fileJson):m.fileJson):null})).filter(x=>x.file&&!x.file.voice&&!x.file.vcircle&&!x.file.sticker);
  const media=items.filter(x=>x.file.type?.startsWith('image/')||x.file.type?.startsWith('video/')||x.file.url);
  const files=items.filter(x=>!(x.file.type?.startsWith('image/')||x.file.type?.startsWith('video/'))&&!x.file.url);
  return <div className="vg-media-pane">
    <div className="vg-media-head">
      <button className={`vg-chip tiny${tab==='media'?' accent':''}`} onClick={()=>setTab('media')}>Медиа ({media.length})</button>
      <button className={`vg-chip tiny${tab==='files'?' accent':''}`} onClick={()=>setTab('files')}>Файлы ({files.length})</button>
      <div style={{flex:1}}/>
      <button className="vg-ibtn" onClick={onClose}>{IC.close(16)}</button>
    </div>
    {tab==='media'?<div className="vg-media-grid">
      {media.map((x,i)=>{const u=x.file.data||x.file.url;return x.file.type?.startsWith('video/')
        ? <video key={i} src={u} className="vg-media-thumb" onClick={()=>window.open(u)}/>
        : <img key={i} src={u} className="vg-media-thumb" onClick={()=>window.open(u)} alt=""/>;})}
      {media.length===0&&<div className="vg-muted" style={{padding:16}}>Нет медиа</div>}
    </div>:<div className="vg-media-files">
      {files.map((x,i)=><div key={i} className="vg-media-file">
        {IC.file(16)}<div style={{flex:1}}><div style={{fontSize:13}}>{x.file.name}</div><div className="vg-muted" style={{fontSize:11}}>{(x.file.size/1024).toFixed(0)} KB</div></div>
        <a className="vg-chip tiny" href={x.file.data||x.file.url} download={x.file.name}>{IC.download(11)}</a>
      </div>)}
      {files.length===0&&<div className="vg-muted" style={{padding:16}}>Нет файлов</div>}
    </div>}
  </div>;
}

/* ═══════════ Поле ввода с Apple-эмодзи (contentEditable) ═══════════ */
function EmojiInput({value,setValue,disabled,placeholder,emojiInsert,onEnter}:{value:string;setValue:(v:string)=>void;disabled:boolean;placeholder:string;emojiInsert:any;onEnter:()=>void}){
  const ref=useRef<HTMLDivElement>(null);
  /* читаем plain-text из contentEditable (img → alt-эмодзи) */
  const readText=()=>{
    const el=ref.current; if(!el) return '';
    let out='';
    el.childNodes.forEach(n=>{
      if(n.nodeType===3) out+=n.textContent;
      else if((n as HTMLElement).tagName==='IMG') out+=(n as HTMLElement).getAttribute('alt')||'';
      else if((n as HTMLElement).tagName==='BR') out+='\n';
      else out+=(n as HTMLElement).textContent||'';
    });
    return out;
  };
  /* синхронизация извне: если value очистили (после отправки) — чистим div */
  useEffect(()=>{ if(value===''&&ref.current&&ref.current.innerHTML!=='') ref.current.innerHTML=''; },[value]);
  /* регистрируем функцию вставки эмодзи-картинки */
  useEffect(()=>{
    emojiInsert.current=(e:string)=>{
      const el=ref.current; if(!el) return;
      el.focus();
      const img=document.createElement('img');
      img.className='vg-ae-in'; img.src=appleEmoji(e); img.alt=e; img.draggable=false;
      const sel=window.getSelection();
      if(sel&&sel.rangeCount&&el.contains(sel.anchorNode)){
        const r=sel.getRangeAt(0); r.deleteContents(); r.insertNode(img);
        r.setStartAfter(img); r.collapse(true); sel.removeAllRanges(); sel.addRange(r);
      } else { el.appendChild(img); }
      setValue(readText());
    };
    return ()=>{ emojiInsert.current=null; };
  },[]);
  return <div className="vg-composer-in-wrap">
    <div ref={ref} className="vg-composer-in" contentEditable={!disabled} suppressContentEditableWarning
      data-ph={placeholder}
      onInput={()=>setValue(readText())}
      onKeyDown={e=>{ if(e.key==='Enter'&&!e.shiftKey){ e.preventDefault(); onEnter(); } }}
      onPaste={e=>{ e.preventDefault(); const t=e.clipboardData.getData('text/plain'); document.execCommand('insertText',false,t); }}
    />
  </div>;
}

/* ═══════════ Запись голосового — нормальный UI ═══════════ */
function VoiceRecorder({onSend,onCancel}:{onSend:(b:Blob,dur:number,transcript:string,wave:string)=>void;onCancel:()=>void}){
  const [secs,setSecs]=useState(0);
  const recRef=useRef<MediaRecorder|null>(null);
  const chunksRef=useRef<BlobPart[]>([]);
  const streamRef=useRef<MediaStream|null>(null);
  const startRef=useRef(0);
  const sendModeRef=useRef(false);
  const transcriptRef=useRef('');
  const srRef=useRef<any>(null);
  useEffect(()=>{
    let timer:any;
    /* распознавание речи параллельно с записью (расшифровка ГС) */
    const SR=(window as any).SpeechRecognition||(window as any).webkitSpeechRecognition;
    if(SR){
      try{
        const sr=new SR(); sr.lang='ru-RU'; sr.continuous=true; sr.interimResults=false;
        sr.onresult=(ev:any)=>{ for(let i=ev.resultIndex;i<ev.results.length;i++){ if(ev.results[i].isFinal) transcriptRef.current+=ev.results[i][0].transcript+' '; } };
        sr.start(); srRef.current=sr;
      }catch{}
    }
    (async()=>{
      try{
        const stream=await navigator.mediaDevices.getUserMedia({audio:true});
        streamRef.current=stream;
        const rec=new MediaRecorder(stream);
        recRef.current=rec;
        rec.ondataavailable=e=>{ if(e.data.size>0) chunksRef.current.push(e.data); };
        rec.onstop=()=>{
          stream.getTracks().forEach(t=>t.stop());
          try{ srRef.current?.stop(); }catch{}
          const blob=new Blob(chunksRef.current,{type:rec.mimeType||'audio/webm'});
          if(sendModeRef.current){
            /* генерируем реалистичную «волну» — громкость по времени, используется в превью */
            const durSec=Math.round((Date.now()-startRef.current)/1000);
            const wave=Array.from({length:60},(_,i)=>{
              const t=i/60;
              const env=Math.sin(t*Math.PI); // огибающая
              return +(0.2+env*0.3+Math.abs(Math.sin(i*0.7))*0.5).toFixed(2);
            }).join(',');
            onSend(blob,durSec,transcriptRef.current.trim(),wave);
          }
        };
        rec.start();
        startRef.current=Date.now();
        timer=setInterval(()=>{
          const s=Math.round((Date.now()-startRef.current)/1000);
          setSecs(s);
          if(s>=50){ sendModeRef.current=true; rec.state==='recording'&&rec.stop(); clearInterval(timer); }
        },200);
      }catch{ toast('Нет доступа к микрофону'); onCancel(); }
    })();
    return ()=>{ clearInterval(timer); try{ streamRef.current?.getTracks().forEach(t=>t.stop()); }catch{} };
  },[]);
  const fmt=(s:number)=>`${Math.floor(s/60)}:${String(s%60).padStart(2,'0')}`;
  return <div className="vg-voicerec">
    <button className="vg-ibtn danger" title="Отмена" onClick={()=>{ sendModeRef.current=false; recRef.current?.state==='recording'&&recRef.current.stop(); onCancel(); }}>{IC.trash(16)}</button>
    <div className="vg-voicerec-mid"><span className="vg-rec-dot"/> Запись · {fmt(secs)}</div>
    <button className="vg-sendbtn" title="Отправить" onClick={()=>{ sendModeRef.current=true; recRef.current?.state==='recording'&&recRef.current.stop(); }}>{IC.send(18)}</button>
  </div>;
}

/* ═══════════ Видеокружок (короткое видео) ═══════════ */
async function recordVideoCircle(chatId:string,me:any){
  try{
    const stream=await navigator.mediaDevices.getUserMedia({video:{width:240,height:240,facingMode:'user'},audio:true});
    const rec=new MediaRecorder(stream,{mimeType:MediaRecorder.isTypeSupported('video/webm;codecs=vp8')?'video/webm;codecs=vp8':'video/webm'});
    const chunks:BlobPart[]=[];
    rec.ondataavailable=e=>{ if(e.data.size>0) chunks.push(e.data); };
    rec.onstop=async()=>{
      stream.getTracks().forEach(t=>t.stop());
      const blob=new Blob(chunks,{type:'video/webm'});
      if(blob.size<500*1024){
        const r=new FileReader();
        r.onload=async()=>{ await fbSendMessage(chatId,me.username,'',{type:'vcircle',fileJson:JSON.stringify({name:'circle.webm',type:'video/webm',size:blob.size,data:r.result,vcircle:true})}); };
        r.readAsDataURL(blob);
      }else{
        try{ const url=await fbUploadFile(new File([blob],'circle.webm',{type:'video/webm'}),me.username);
          await fbSendMessage(chatId,me.username,'',{type:'vcircle',fileJson:JSON.stringify({name:'circle.webm',type:'video/webm',size:blob.size,url,vcircle:true})});
        }catch{ toast('Включите Firebase Storage'); }
      }
    };
    rec.start();
    toast('Запись кружка 6 сек...');
    setTimeout(()=>{ if(rec.state==='recording') rec.stop(); },6000);
  }catch{ toast('Нет доступа к камере'); }
}

/* ═══════════ Бот-помощник VibeGram (FAQ по командам) ═══════════ */
const VG_HELP:Record<string,string>={
  '/start':'Привет! Я бот VibeGram. Команды:\n/help — список команд\n/about — о мессенджере\n/features — все возможности\n/security — безопасность\n/stickers — стикеры и GIF\n/calls — звонки\n/bots — про ботов',
  '/help':'Команды:\n/about — о VibeGram\n/features — функции\n/security — безопасность\n/stickers — стикеры/GIF\n/calls — звонки\n/bots — боты\n/shortcuts — горячие действия',
  '/about':'VibeGram — минималистичный мессенджер на Firebase. Облачная синхронизация в реальном времени, E2E-настройки приватности, звонки, боты, стикеры из Giphy.',
  '/features':'Возможности:\n• ЛС, группы, каналы\n• Реакции, ответы, пересылка, редактирование\n• Закреп сообщений и чатов, архив, папки\n• Опросы, видеокружки, голосовые\n• Стикеры и GIF из Giphy + свои наборы\n• Запланированные сообщения, автоудаление\n• Темы и кастомный дизайн',
  '/security':'Безопасность:\n• Пароли только в Firebase Auth\n• Глобальная и чат-модерация\n• Жалобы: ПКМ по профилю → Пожаловаться\n• Блокировка пользователей\n• Анти-флуд защита',
  '/stickers':'Стикеры и GIF берутся из Giphy. Можно создать свой набор: вкладка Боты → Стикерпаки → создать → получить ссылку и поделиться.',
  '/calls':'Звонки через ZEGOCLOUD: кнопка трубки в ЛС и группах. Видео, демонстрация экрана, до 50 участников.',
  '/bots':'Боты: создавайте своих с правилами «триггер → ответ» во вкладке Боты. Я (VibeGram) — помощник, отвечаю на команды.',
  '/shortcuts':'• ПКМ по чату — закрепить/архив/мьют/удалить\n• ПКМ по сообщению — реакции, ответить, закрепить\n• Двойной клик по сообщению — ❤️\n• Клик по чату вверху — профиль/участники',
};
async function runBots(chat:any,text:string,senderUn:string){
  if(!text) return;
  const botMembers=(chat.members||[]).filter((m:string)=>m!==senderUn);
  for(const un of botMembers){
    try{
      /* Официальный бот-помощник */
      if(un==='vibegram'){
        const cmd=text.trim().toLowerCase().split(/\s/)[0];
        if(VG_HELP[cmd]){ await fbSendMessage(chat.id,'vibegram',VG_HELP[cmd]); continue; }
        if(cmd.startsWith('/')){ await fbSendMessage(chat.id,'vibegram','Неизвестная команда. Напишите /help'); continue; }
        continue;
      }
      const botSnap=await getDoc(doc(db,'bots',un));
      if(!botSnap.exists()) continue;
      const rules=botSnap.data().rules||[];
      const lower=text.toLowerCase();
      for(const rule of rules){
        if(rule.trigger&&lower.includes(rule.trigger.toLowerCase())){
          await fbSendMessage(chat.id,un,(rule.reply||'...').slice(0,1000));
          break;
        }
      }
    }catch{}
  }
}

/* ═══════════ Сообщение ═══════════ */
function MsgBubble({m,mine,me,chatId,sender,searchTerm,onCtx,allowedReactions}:any){
  const file=m.fileJson?(typeof m.fileJson==='string'?JSON.parse(m.fileJson):m.fileJson):null;
  let body=m.text||'';
  if(searchTerm) body=body.replace(new RegExp(`(${escRe(searchTerm)})`,'gi'),'§§$1§§');
  let html=md(body).replace(/§§(.*?)§§/g,'<mark>$1</mark>');
  /* упоминания @username */
  html=html.replace(/@([a-z0-9_]{2,20})/gi,'<span class="vg-mention">@$1</span>');
  html=renderAppleEmoji(html); /* Apple-эмодзи картинками */
  const reactions=Object.entries(m.reactions||{}).filter(([_,arr]:any)=>arr&&arr.length>0);
  const readBy=(m.readBy||[]).filter((u:string)=>u!==me.username);
  if(m.type==='gift'||m.type==='giveaway'){
    return <div className={`vg-mwrap${mine?' mine':''}`} onContextMenu={onCtx}>
      <div className="vg-msg"><div className="vg-muted" style={{fontSize:13}}>Сообщение устаревшего формата</div></div>
    </div>;
  }
  /* Стикер — картинка из Giphy или свой набор */
  if(m.type==='sticker'&&(file?.stickerUrl||file?.sticker)){
    return <div id={'m_'+m.id} className={`vg-mwrap${mine?' mine':''}`} onContextMenu={onCtx}>
      <div className="vg-sticker-msg">
        {file.stickerUrl?<img src={file.stickerUrl} className="vg-sticker-img" alt="sticker"/>:<div className="vg-sticker-big">{file.sticker}</div>}
        <div className="vg-msg-meta" style={{textAlign:mine?'right':'left'}}>{fmtTime(m.createdAt)}</div>
      </div>
    </div>;
  }
  /* Видеокружок */
  if(m.type==='vcircle'&&file?.vcircle){
    return <div id={'m_'+m.id} className={`vg-mwrap${mine?' mine':''}`} onContextMenu={onCtx}>
      <div style={{textAlign:mine?'right':'left'}}>
        <video className="vg-vcircle" src={file.data} controls loop/>
        <div className="vg-msg-meta">{fmtTime(m.createdAt)}</div>
      </div>
    </div>;
  }
  /* Опрос */
  if(m.type==='poll'&&m.poll){
    return <div id={'m_'+m.id} className={`vg-mwrap${mine?' mine':''}`} onContextMenu={onCtx}>
      <PollView m={m} me={me} chatId={chatId} sender={sender} mine={mine}/>
    </div>;
  }
  return <div id={'m_'+m.id} className={`vg-mwrap${mine?' mine':''}`}>
    <div className="vg-msg" onContextMenu={onCtx} onDoubleClick={()=>{ if(rl.check('reaction').ok) fbToggleReaction(chatId,m.id,'❤️',me.username,m.reactions); }}>
      {!mine&&<div className="vg-msg-author"><NameBadge user={sender} name={sender?.name||m.senderId} size={11}/></div>}
      {m.replyTo&&<div className="vg-msg-reply">{IC.reply(12)} {m.replyTo.text}</div>}
      {file&&<FilePreview file={file}/>}
      {body&&<div className="vg-msg-text" dangerouslySetInnerHTML={{__html:html}}/>}
      <div className="vg-msg-meta">
        {fmtTime(m.createdAt)}{m.editedAt?' · ред.':''}
        {mine&&<span className="vg-checks" title={readBy.length?'Прочитано':'Отправлено'}>{readBy.length>0?IC.check(11):IC.check(11)}{readBy.length>0&&<span style={{marginLeft:-7}}>{IC.check(11)}</span>}</span>}
      </div>
      {reactions.length>0&&<div className="vg-reactions">
        {reactions.map(([emoji,arr]:any)=>
          <span key={emoji} className={`vg-rpill${arr.includes(me.username)?' mine':''}`}
            onClick={()=>{ if(rl.check('reaction').ok) fbToggleReaction(chatId,m.id,emoji,me.username,m.reactions); }}>
            <img src={tw(emoji)} width={14} height={14} alt={emoji}/> {arr.length}
          </span>)}
      </div>}
    </div>
  </div>;
}

/* ═══════════ Опрос ═══════════ */
function PollView({m,me,chatId,sender,mine}:any){
  const poll=m.poll;
  const votes=m.pollVotes||{}; // {option:[users]}
  const myVote=Object.entries(votes).find(([_,arr]:any)=>arr.includes(me.username))?.[0];
  const total=Object.values(votes).reduce((a:number,arr:any)=>a+arr.length,0);
  const vote=async(opt:string)=>{
    if(myVote===opt) return;
    const newVotes:any={};
    poll.options.forEach((o:string)=>{ newVotes[o]=(votes[o]||[]).filter((u:string)=>u!==me.username); });
    newVotes[opt]=[...(newVotes[opt]||[]),me.username];
    await updateDoc(doc(db,'chats',chatId,'messages',m.id),{pollVotes:newVotes});
  };
  return <div className="vg-msg vg-poll">
    {!mine&&<div className="vg-msg-author">{sender?.name||m.senderId}</div>}
    <div className="vg-poll-q">{IC.poll(15)} {poll.question}</div>
    {poll.options.map((opt:string)=>{
      const cnt=(votes[opt]||[]).length;
      const pct=total?Math.round(cnt/total*100):0;
      return <div key={opt} className={`vg-poll-opt${myVote===opt?' voted':''}`} onClick={()=>vote(opt)}>
        <div className="vg-poll-bar" style={{width:pct+'%'}}/>
        <span className="vg-poll-label">{myVote===opt?'● ':'○ '}{opt}</span>
        <span className="vg-poll-pct">{pct}%</span>
      </div>;
    })}
    <div className="vg-muted" style={{fontSize:11,marginTop:4}}>{total} голосов · {fmtTime(m.createdAt)}</div>
  </div>;
}

/* ═══════════ Вкладка Боты ═══════════ */
function BotsTab({me,onOpenChat}:any){
  const [myBots,setMyBots]=useState<any[]>([]);
  const [allBots,setAllBots]=useState<any[]>([]);
  useEffect(()=>{
    const unsub=onSnapshot(collection(db,'bots'),snap=>{
      const mine:any[]=[],all:any[]=[];
      snap.forEach(d=>{
        const b={...d.data(),username:d.id};
        all.push(b);
        if(b.ownerUn===me.username) mine.push(b);
      });
      setMyBots(mine); setAllBots(all);
    });
    return unsub;
  },[me.username]);
  return <div style={{padding:12}}>
    <div style={{fontWeight:700,marginBottom:8,display:'flex',alignItems:'center',gap:6}}>{IC.bot(16)} Мои боты</div>
    {myBots.map(b=><div key={b.username} className="vg-botrow">
      <Avatar name={b.name||b.username} size={36}/>
      <div style={{flex:1}}><b>{b.name||b.username}</b><div className="vg-muted" style={{fontSize:12}}>@{b.username} · {(b.rules||[]).length} правил</div></div>
      <button className="vg-chip tiny" onClick={()=>openModal('botedit',{bot:b,me})}>Правила</button>
      <button className="vg-chip tiny" onClick={()=>onOpenChat(b.username)}>Чат</button>
    </div>)}
    {myBots.length===0&&<div className="vg-muted" style={{fontSize:13,marginBottom:8}}>У вас пока нет ботов</div>}
    <button className="vg-chip" onClick={()=>openModal('botcreate',{me})}>{IC.plus(13)} Создать бота</button>
    <div style={{fontWeight:700,margin:'16px 0 8px'}}>Все боты</div>
    {allBots.map(b=><div key={b.username} className="vg-botrow" onClick={()=>onOpenChat(b.username)}>
      <Avatar name={b.name||b.username} size={32}/>
      <div style={{flex:1}}>{b.name||b.username}<div className="vg-muted" style={{fontSize:11}}>@{b.username}</div></div>
    </div>)}
    <div style={{fontWeight:700,margin:'16px 0 8px',display:'flex',alignItems:'center',gap:6}}>{IC.sticker(16)} Стикерпаки и GIF-наборы</div>
    <button className="vg-chip" onClick={()=>openModal('packmaker',{me})}>{IC.plus(13)} Создать набор</button>
  </div>;
}

/* ═══════════ Конструктор стикерпаков / GIF-наборов ═══════════ */
function PackMakerModal({me}:any){
  const [packs,setPacks]=useState<any[]>([]);
  const [name,setName]=useState('');
  const [type,setType]=useState<'sticker'|'gif'>('sticker');
  const refresh=()=>{ fbMyPacks(me.username).then(setPacks); };
  useEffect(()=>{ refresh(); },[]);
  return <div>
    <h2>{IC.sticker(18)} Наборы стикеров / GIF</h2>
    <div className="vg-muted" style={{fontSize:13,marginBottom:8}}>Создайте набор, добавьте картинки по URL (например из Giphy), получите ссылку и поделитесь.</div>
    <div style={{display:'flex',gap:6,marginBottom:6}}>
      <input className="vg-input" placeholder="Название набора" value={name} onChange={e=>setName(e.target.value)} style={{flex:1,marginBottom:0}}/>
      <select className="vg-input" value={type} onChange={e=>setType(e.target.value as any)} style={{marginBottom:0,width:110}}>
        <option value="sticker">Стикеры</option><option value="gif">GIF</option>
      </select>
    </div>
    <button className="vg-btn primary" onClick={async()=>{
      if(!name.trim()){toast('Название?');return;}
      const id=await fbCreatePack(me.username,name.trim(),type,[]);
      setName(''); refresh(); toast('Набор создан: '+id);
    }}>Создать набор</button>
    <div style={{marginTop:14}}>
      {packs.map(p=><div key={p.id} className="vg-mod-row">
        <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:6}}>
          <b style={{flex:1}}>{p.name}</b>
          <span className="vg-tag">{p.type==='gif'?'GIF':'стикеры'} · {(p.items||[]).length}</span>
        </div>
        <div style={{display:'flex',gap:4,flexWrap:'wrap',marginBottom:6}}>
          {(p.items||[]).slice(0,8).map((u:string,i:number)=><img key={i} src={u} style={{width:40,height:40,objectFit:'contain',borderRadius:6}} alt=""/>)}
        </div>
        <div style={{display:'flex',gap:6,flexWrap:'wrap'}}>
          <button className="vg-chip tiny" onClick={async()=>{
            const url=prompt('URL картинки (png/gif):'); if(!url)return;
            try{ await fbAddItemToPack(p.id,url); refresh(); toast('Добавлено'); }catch(e:any){ toast(e.message); }
          }}>{IC.plus(11)} Добавить URL</button>
          <button className="vg-chip tiny" onClick={()=>{
            const link=`${location.origin}/#pack_${p.id}`;
            navigator.clipboard?.writeText(link); toast('Ссылка скопирована: '+link);
          }}>{IC.link(11)} Ссылка</button>
          <button className="vg-chip tiny" onClick={async()=>{ await fbInstallPack(me.username,p.id); toast('Установлен — доступен в стикерах'); }}>Установить себе</button>
        </div>
      </div>)}
      {packs.length===0&&<div className="vg-muted">Нет наборов</div>}
    </div>
  </div>;
}

/* ═══════════ Контекстное меню ═══════════ */
function CtxMenu({me,onOpenChat,onChatDeleted}:any){
  const [ctx,setCtx]=useState<CtxState>(null);
  const [showAll,setShowAll]=useState(false);
  useEffect(()=>{ _setCtx=(c)=>{setCtx(c);setShowAll(false);}; return ()=>{_setCtx=()=>{};}; },[]);
  useEffect(()=>{
    const close=()=>setCtx(null);
    window.addEventListener('click',close);
    window.addEventListener('scroll',close,true);
    return ()=>{window.removeEventListener('click',close);window.removeEventListener('scroll',close,true);};
  },[]);
  if(!ctx) return null;
  const {kind,data}=ctx;
  return <div className="vg-ctx" style={{left:ctx.x,top:ctx.y}} onClick={e=>e.stopPropagation()} onContextMenu={e=>e.preventDefault()}>
    {kind==='chat'&&<>
      {(me.folders||[]).length>0&&<div className="vg-ctx-sub">
        {(me.folders||[]).map((f:any)=><button key={f.name} className="vg-ctx-item" onClick={async()=>{
          const folders=(me.folders||[]).map((x:any)=>x.name===f.name?{...x,chatIds:[...new Set([...(x.chatIds||[]),data.chat.id])]}:x);
          await updateDoc(doc(db,'users',me.username),{folders});
          toast(`Добавлено в «${f.name}»`); setCtx(null);
        }}>{IC.folder(14)} В папку «{f.name}»</button>)}
      </div>}
      <button className="vg-ctx-item" onClick={async()=>{
        const pinned=(me.pinnedChats||[]).includes(data.chat.id);
        await fbTogglePinChat(me.username,data.chat.id,!pinned);
        toast(pinned?'Откреплено':'Закреплено вверху'); setCtx(null);
      }}>{IC.pin(14)} {(me.pinnedChats||[]).includes(data.chat.id)?'Открепить':'Закрепить вверху'}</button>
      <button className="vg-ctx-item" onClick={async()=>{
        const arch=(me.archivedChats||[]).includes(data.chat.id);
        await fbToggleArchive(me.username,data.chat.id,!arch);
        toast(arch?'Из архива':'В архив'); setCtx(null);
      }}>{IC.archive(14)} {(me.archivedChats||[]).includes(data.chat.id)?'Из архива':'В архив'}</button>
      <button className="vg-ctx-item" onClick={async()=>{
        const muted=(data.chat.mutedUntil||0)>Date.now();
        await fbMuteChat(data.chat.id,muted?0:Date.now()+8*3600_000);
        toast(muted?'Со звуком':'Без звука 8ч'); setCtx(null);
      }}>{(data.chat.mutedUntil||0)>Date.now()?IC.bell(14):IC.bellOff(14)} {(data.chat.mutedUntil||0)>Date.now()?'Включить звук':'Без звука'}</button>
      <div className="vg-ctx-divider"/>
      <button className="vg-ctx-item danger" onClick={async()=>{
        setCtx(null);
        if(!confirm('Удалить чат? Сообщения будут стёрты из облака.')) return;
        if(data.chat.ownerId===me.username||me.isAdmin||data.chat.type==='dm'||data.chat.type==='saved'){
          await fbDeleteChat(data.chat.id);
        }else{
          await fbLeaveChat(data.chat.id,me.username);
        }
        onChatDeleted(data.chat.id);
        toast('Чат удалён');
      }}>{IC.trash(14)} Удалить чат</button>
    </>}
    {kind==='message'&&<>
      {(()=>{
        const rm=data.chat?.reactMode||'all';
        if(rm==='none') return null;
        const quick=rm==='custom'&&Array.isArray(data.chat?.allowedReactions)&&data.chat.allowedReactions.length?data.chat.allowedReactions:QUICK_REACTIONS;
        const all=rm==='custom'&&Array.isArray(data.chat?.allowedReactions)&&data.chat.allowedReactions.length?data.chat.allowedReactions:ALL_REACTIONS;
        return <>
          <div className="vg-ctx-reactions">
            {quick.slice(0,6).map((e:string)=><button key={e} className="vg-ctx-react" onClick={()=>{
              if(rl.check('reaction').ok) fbToggleReaction(data.chatId,data.msg.id,e,me.username,data.msg.reactions);
              setCtx(null);
            }}><img src={tw(e)} width={22} height={22} alt={e}/></button>)}
            {rm!=='custom'&&<button className="vg-ctx-react plus" onClick={()=>setShowAll(s=>!s)}>{IC.plus(15)}</button>}
          </div>
          {showAll&&rm!=='custom'&&<div className="vg-ctx-reactions-all">
            {all.map((e:string)=><button key={e} className="vg-ctx-react" onClick={()=>{
              if(rl.check('reaction').ok) fbToggleReaction(data.chatId,data.msg.id,e,me.username,data.msg.reactions);
              setCtx(null);
            }}><img src={tw(e)} width={20} height={20} alt={e}/></button>)}
            {/* эксклюзивные Premium-реакции */}
            <div className="vg-prem-react-row">{IC.star(11)} Premium</div>
            {PREMIUM_REACTIONS.map((e:string)=><button key={e} className={`vg-ctx-react${isPremium(me)?'':' locked'}`} onClick={()=>{
              if(!isPremium(me)){toast('Эксклюзивные реакции — только для Premium');return;}
              if(rl.check('reaction').ok) fbToggleReaction(data.chatId,data.msg.id,e,me.username,data.msg.reactions);
              setCtx(null);
            }}><img src={tw(e)} width={20} height={20} alt={e}/></button>)}
          </div>}
        </>;
      })()}
      <div className="vg-ctx-divider"/>
      <button className="vg-ctx-item" onClick={()=>{ window.dispatchEvent(new CustomEvent('vg-reply',{detail:data.msg})); setCtx(null); }}>{IC.reply(14)} Ответить</button>
      <button className="vg-ctx-item" onClick={()=>{ openModal('forward',{msg:data.msg,me}); setCtx(null); }}>{IC.forward(14)} Переслать</button>
      <button className="vg-ctx-item" onClick={()=>{ navigator.clipboard?.writeText(data.msg.text||''); toast('Скопировано'); setCtx(null); }}>{IC.copy(14)} Копировать</button>
      <button className="vg-ctx-item" onClick={async()=>{
        setCtx(null);
        const bms=me.bookmarks||[];
        const exists=bms.find((b:any)=>b.msgId===data.msg.id);
        const bm={msgId:data.msg.id,chatId:data.chatId,text:(data.msg.text||'Вложение').slice(0,100),ts:Date.now()};
        if(exists){ await fbRemoveBookmark(me.username,exists); toast('Убрано из закладок'); }
        else{ await fbAddBookmark(me.username,bm); toast('В закладках'); }
      }}>{IC.bookmark(14)} {(me.bookmarks||[]).find((b:any)=>b.msgId===data.msg.id)?'Убрать из закладок':'В закладки'}</button>
      {(data.chat?.ownerId===me.username||me.isAdmin||data.chat?.type==='dm'||data.chat?.type==='saved')&&<button className="vg-ctx-item" onClick={async()=>{
        setCtx(null);
        const already=(data.chat?.pinnedMsgs||[]).some((p:any)=>p.msgId===data.msg.id);
        if(already){ await fbUnpinMessage(data.chatId,data.msg.id); toast('Откреплено'); }
        else{ await fbPinMessage(data.chatId,data.msg.id,data.msg.text||'Сообщение',data.msg.senderId); toast('Закреплено'); }
      }}>{IC.pin(14)} {(data.chat?.pinnedMsgs||[]).some((p:any)=>p.msgId===data.msg.id)?'Открепить':'Закрепить'}</button>}
      {data.msg.senderId===me.username&&<button className="vg-ctx-item" onClick={()=>{ window.dispatchEvent(new CustomEvent('vg-edit',{detail:data.msg})); setCtx(null); }}>{IC.edit(14)} Редактировать</button>}
      {(data.msg.senderId===me.username||me.isAdmin||data.chat?.ownerId===me.username)&&<button className="vg-ctx-item danger" onClick={async()=>{
        setCtx(null);
        await deleteDoc(doc(db,'chats',data.chatId,'messages',data.msg.id));
        toast('Удалено');
      }}>{IC.trash(14)} Удалить</button>}
    </>}
    {kind==='folder'&&<button className="vg-ctx-item danger" onClick={async()=>{
      const folders=(me.folders||[]).filter((x:any)=>x.name!==data.folder.name);
      await updateDoc(doc(db,'users',me.username),{folders});
      toast('Папка удалена'); setCtx(null);
    }}>{IC.trash(14)} Удалить папку</button>}
  </div>;
}

/* ═══════════ Каталог публичных групп/каналов ═══════════ */
function CatalogTab({me,q,onOpenChat}:any){
  const [list,setList]=useState<any[]>([]);
  useEffect(()=>{ fbGetCatalog().then(setList); },[]);
  const filtered=q?list.map(c=>({...c,_s:Math.max(fuzzyScore(q,c.title||''),fuzzyScore(q,c.about||''))})).filter(c=>c._s>0).sort((a,b)=>b._s-a._s):list;
  return <div style={{padding:8}}>
    <div className="vg-muted" style={{fontSize:12,padding:'4px 6px 8px'}}>Публичные группы и каналы</div>
    {filtered.map(c=>{
      const joined=(c.members||[]).includes(me.username);
      return <div key={c.id} className="vg-cat-row">
        <Avatar name={c.title} src={c.avatar} size={44} ch={c.type==='channel'}/>
        <div style={{flex:1,minWidth:0}}>
          <div style={{fontWeight:600,fontSize:14}}>{c.title}{c.type==='channel'&&<span className="vg-type-badge" style={{marginLeft:6}}>КАНАЛ</span>}</div>
          <div className="vg-muted" style={{fontSize:12,whiteSpace:'nowrap',overflow:'hidden',textOverflow:'ellipsis'}}>{c.about||'—'} · {(c.members||[]).length} уч.</div>
        </div>
        {joined
          ? <button className="vg-chip tiny" onClick={()=>onOpenChat(c.id)}>Открыть</button>
          : <button className="vg-chip tiny accent" onClick={async()=>{ await fbJoinChat(c.id,me.username); toast(c.type==='channel'?'Вы подписались':'Вы вступили'); onOpenChat(c.id); }}>{c.type==='channel'?'Подписаться':'Вступить'}</button>}
      </div>;
    })}
    {filtered.length===0&&<div className="vg-empty">Каталог пуст</div>}
  </div>;
}

/* ═══════════ Глобальный поиск по сообщениям ═══════════ */
function GlobalSearchModal({me,onOpenChat}:any){
  const [q,setQ]=useState('');
  const [results,setResults]=useState<any[]>([]);
  const [loading,setLoading]=useState(false);
  const timer=useRef<any>(null);
  const run=(val:string)=>{
    setQ(val); clearTimeout(timer.current);
    if(val.length<2){setResults([]);return;}
    timer.current=setTimeout(async()=>{
      setLoading(true);
      const snap=await getDocs(query(collection(db,'chats'),where('members','array-contains',me.username)));
      const chats:any[]=[]; snap.forEach(d=>chats.push({...d.data(),id:d.id}));
      const all:any[]=[];
      for(const c of chats.slice(0,30)){
        try{ const hits=await fbSearchInChat(c.id,val); hits.forEach(h=>all.push({...h,chatTitle:c.title||c.type,chatId:c.id})); }catch{}
      }
      setResults(all.slice(0,40)); setLoading(false);
    },400);
  };
  return <div>
    <h2>{IC.search(18)} Поиск по сообщениям</h2>
    <input className="vg-input" autoFocus placeholder="Введите текст..." value={q} onChange={e=>run(e.target.value)}/>
    {loading&&<div className="vg-muted">Поиск...</div>}
    <div style={{maxHeight:380,overflow:'auto'}}>
      {results.map((r,i)=><div key={i} className="vg-botrow" onClick={()=>{closeModal();onOpenChat(r.chatId);setTimeout(()=>document.getElementById('m_'+r.id)?.scrollIntoView({behavior:'smooth',block:'center'}),600);}}>
        <div style={{flex:1}}>
          <div className="vg-muted" style={{fontSize:11}}>{r.chatTitle} · {fmtTime(r.createdAt)}</div>
          <div style={{fontSize:13}}>{r.text}</div>
        </div>
      </div>)}
      {q.length>=2&&!loading&&results.length===0&&<div className="vg-muted" style={{padding:8}}>Ничего не найдено. Firestore ищет по точному началу текста.</div>}
    </div>
  </div>;
}

/* ═══════════ Закладки ═══════════ */
function BookmarksModal({me,onOpenChat}:any){
  const bms=(me.bookmarks||[]).slice().sort((a:any,b:any)=>b.ts-a.ts);
  return <div>
    <h2>{IC.bookmark(18)} Закладки</h2>
    <div style={{maxHeight:400,overflow:'auto'}}>
      {bms.map((b:any,i:number)=><div key={i} className="vg-botrow" onClick={()=>{closeModal();onOpenChat(b.chatId);setTimeout(()=>document.getElementById('m_'+b.msgId)?.scrollIntoView({behavior:'smooth',block:'center'}),600);}}>
        <div style={{flex:1}}>
          <div style={{fontSize:13}}>{b.text}</div>
          <div className="vg-muted" style={{fontSize:11}}>{fmtDate(b.ts)} {fmtTime(b.ts)}</div>
        </div>
        <button className="vg-chip tiny" onClick={async(e)=>{e.stopPropagation();await fbRemoveBookmark(me.username,b);toast('Удалено');}}>{IC.trash(11)}</button>
      </div>)}
      {bms.length===0&&<div className="vg-muted" style={{padding:8}}>Нет закладок. ПКМ по сообщению → В закладки</div>}
    </div>
  </div>;
}

/* ═══════════ Статистика канала ═══════════ */
function StatsModal({chatId,me}:any){
  const [data,setData]=useState<any>(null);
  useEffect(()=>{
    (async()=>{
      const chatSnap=await getDoc(doc(db,'chats',chatId));
      const chat=chatSnap.data();
      const snap=await getDocs(query(collection(db,'chats',chatId,'messages'),orderBy('createdAt','asc')));
      const msgs:any[]=[]; snap.forEach(d=>msgs.push({...d.data(),id:d.id}));
      const bySender:Record<string,number>={};
      msgs.forEach(m=>{ bySender[m.senderId]=(bySender[m.senderId]||0)+1; });
      const topUsers=Object.entries(bySender).sort((a:any,b:any)=>b[1]-a[1]).slice(0,5);
      const topMsgs=msgs.map(m=>({...m,rc:Object.values(m.reactions||{}).reduce((a:number,arr:any)=>a+(arr?.length||0),0)})).sort((a,b)=>b.rc-a.rc).slice(0,3);
      setData({total:msgs.length,members:(chat?.members||[]).length,topUsers,topMsgs});
    })();
  },[chatId]);
  if(!data) return <div>Загрузка...</div>;
  return <div>
    <h2>{IC.stats(18)} Статистика</h2>
    <div style={{display:'flex',gap:12,marginBottom:14}}>
      <div className="vg-stat-card"><div className="vg-stat-num">{data.total}</div><div className="vg-muted">сообщений</div></div>
      <div className="vg-stat-card"><div className="vg-stat-num">{data.members}</div><div className="vg-muted">участников</div></div>
    </div>
    <h3>Топ-5 активных</h3>
    {data.topUsers.map(([un,cnt]:any,i:number)=><div key={un} className="vg-mod-row" style={{display:'flex',gap:8,alignItems:'center'}}>
      <b style={{width:20}}>{i+1}.</b><span style={{flex:1}}>@{un}</span><span className="vg-tag">{cnt}</span>
    </div>)}
    <h3 style={{marginTop:10}}>Топ-3 по реакциям</h3>
    {data.topMsgs.map((m:any,i:number)=><div key={i} className="vg-mod-row"><div style={{fontSize:13,flex:1}}>{(m.text||'Вложение').slice(0,60)}</div><span className="vg-tag">{m.rc} реакц.</span></div>)}
  </div>;
}

/* ═══════════ Модалки ═══════════ */
function ModalHost({me,theme,setTheme,wall,setWall,onOpenChat,onLogout}:any){
  const [modal,setModal]=useState<MState>({name:null});
  useEffect(()=>{_setModal=setModal;return()=>{_setModal=()=>{};};},[]);
  if(!modal.name) return null;
  const P=modal.props||{};
  return <div className="vg-backdrop" onClick={closeModal}>
    <div className="vg-modal" onClick={e=>e.stopPropagation()}>
      <button className="vg-modal-x" onClick={closeModal}>{IC.close()}</button>
      {modal.name==='newchat'&&<NewChatModal me={me} onOpenChat={onOpenChat}/>}
      {modal.name==='settings'&&<SettingsModal me={me} theme={theme} setTheme={setTheme} wall={wall} setWall={setWall} onLogout={onLogout}/>}
      {modal.name==='admin'&&<AdminModal me={me}/>}
      {modal.name==='chatinfo'&&<ChatInfoModal chatId={P.chatId} me={me}/>}
      {modal.name==='chatsettings'&&<ChatSettingsModal chatId={P.chatId} me={me}/>}
      {modal.name==='addmember'&&<AddMemberModal chatId={P.chatId} me={me}/>}
      {modal.name==='moderation'&&<ModerationModal chatId={P.chatId} me={me}/>}
      {modal.name==='botcreate'&&<BotCreateModal me={me}/>}
      {modal.name==='botedit'&&<BotEditModal bot={P.bot} me={me}/>}
      {modal.name==='forward'&&<ForwardModal msg={P.msg} me={me} onOpenChat={onOpenChat}/>}
      {modal.name==='profile'&&<ProfileModal username={P.username} me={me} onOpenChat={onOpenChat}/>}
      {modal.name==='createpoll'&&<CreatePollModal chatId={P.chatId} me={me}/>}
      {modal.name==='packmaker'&&<PackMakerModal me={me}/>}
      {modal.name==='globalsearch'&&<GlobalSearchModal me={me} onOpenChat={onOpenChat}/>}
      {modal.name==='bookmarks'&&<BookmarksModal me={me} onOpenChat={onOpenChat}/>}
      {modal.name==='stats'&&<StatsModal chatId={P.chatId} me={me}/>}
    </div>
  </div>;
}

/* ═══════════ Просмотр профиля ═══════════ */
function ProfileModal({username,me,onOpenChat}:any){
  const [u,setU]=useState<any>(null);
  const [blocked,setBlocked]=useState(false);
  useEffect(()=>{
    getDoc(doc(db,'users',username)).then(s=>{ if(s.exists()) setU(s.data()); });
    fbGetBlockedUsers(me.username).then(list=>setBlocked(list.includes(username)));
  },[username]);
  if(!u) return <div>Загрузка...</div>;
  const isMe=username===me.username;
  const online=Date.now()-(u.lastSeen||0)<120_000;
  return <div className="vg-profile">
    {u.cover&&<div className="vg-profile-cover" style={{backgroundImage:`url(${u.cover})`}}/>}
    <div className="vg-profile-head" style={u.cover?{marginTop:-46}:undefined}>
      <Avatar name={u.name} src={u.avatar} size={92}/>
      <h2 style={{margin:'10px 0 2px',display:'flex',alignItems:'center',gap:6,justifyContent:'center',color:u.nameColor||undefined}}>
        <NameBadge user={u} name={u.name}/>
      </h2>
      <div className="vg-muted">@{u.username}</div>
      <div className="vg-muted" style={{fontSize:12,marginTop:2}}>
        {u.isBot?'бот':u.privacy?.showLastSeen===false?'был(а) недавно':online?'в сети':'был(а) '+fmtDate(u.lastSeen||0).toLowerCase()+' в '+fmtTime(u.lastSeen||0)}
      </div>
    </div>
    {u.bio&&<div className="vg-profile-bio">{u.bio}</div>}
    {u.profileMusic&&<div style={{marginTop:10}}>
      <div className="vg-muted" style={{fontSize:12,marginBottom:4,display:'flex',alignItems:'center',gap:4}}>{IC.music(13)} Музыка профиля</div>
      <AudioPlayer src={u.profileMusic} name={u.profileMusicName||'Трек'}/>
    </div>}
    {!isMe&&<div style={{display:'flex',gap:8,marginTop:14,flexWrap:'wrap'}}>
      <button className="vg-btn primary" onClick={async()=>{ const id=await fbCreateDM(me.username,username); closeModal(); onOpenChat(id); }}>{IC.send(15)} Написать</button>
      <button className="vg-chip" onClick={async()=>{
        if(blocked){ await fbUnblockUser(me.username,username); setBlocked(false); toast('Разблокирован'); }
        else{ await fbBlockUser(me.username,username); setBlocked(true); toast('Заблокирован'); }
      }}>{IC.ban(13)} {blocked?'Разблокировать':'Заблокировать'}</button>
      <button className="vg-chip" onClick={async()=>{
        const reason=prompt('Причина жалобы:'); if(!reason)return;
        await fbReport(me.username,username,reason); toast('Жалоба отправлена');
      }}>{IC.shield(13)} Пожаловаться</button>
      {me.isAdmin&&!u.isAdmin&&<>
        {u.bannedGlobal
          ? <button className="vg-chip danger" onClick={async()=>{ await fbUnbanGlobal(username,me.username); toast('Разбанен'); closeModal(); }}>{IC.ban(13)} Разбанить</button>
          : <button className="vg-chip danger" onClick={async()=>{
              const reason=prompt('Причина бана:')||''; const mins=parseInt(prompt('Минут (0 = навсегда):','60')||'0');
              await fbBanGlobal(username,reason,mins,me.username); toast('Забанен'); closeModal();
            }}>{IC.ban(13)} Забанить</button>}
        {isPremium(u)
          ? <button className="vg-chip" onClick={async()=>{ await fbRemovePremium(me.username,username); toast('Premium снят'); closeModal(); }}>{IC.star(13)} Снять Premium</button>
          : <button className="vg-chip" onClick={async()=>{ const m=parseInt(prompt('Premium на сколько месяцев (0=навсегда):','1')||'0'); await fbSetPremium(me.username,username,m); toast('Premium выдан'); closeModal(); }}>{IC.star(13)} Выдать Premium</button>}
      </>}
    </div>}
  </div>;
}

/* ═══════════ Создание опроса ═══════════ */
function CreatePollModal({chatId,me}:any){
  const [q,setQ]=useState('');
  const [opts,setOpts]=useState(['','']);
  return <div>
    <h2>{IC.poll(18)} Новый опрос</h2>
    <input className="vg-input" placeholder="Вопрос" value={q} onChange={e=>setQ(e.target.value)}/>
    {opts.map((o,i)=><input key={i} className="vg-input" placeholder={`Вариант ${i+1}`} value={o} onChange={e=>{ const n=[...opts]; n[i]=e.target.value; setOpts(n); }}/>)}
    {opts.length<8&&<button className="vg-chip" onClick={()=>setOpts([...opts,''])}>{IC.plus(12)} Вариант</button>}
    <button className="vg-btn primary" style={{marginTop:10,display:'block'}} onClick={async()=>{
      const clean=opts.map(o=>o.trim()).filter(Boolean);
      if(!q.trim()||clean.length<2){toast('Вопрос и минимум 2 варианта');return;}
      const pollVotes:any={}; clean.forEach(o=>pollVotes[o]=[]);
      await addDoc(collection(db,'chats',chatId,'messages'),{
        text:'',senderId:me.username,chatId,createdAt:Date.now(),type:'poll',
        poll:{question:q.trim(),options:clean},pollVotes,reactions:{},editedAt:0,
      });
      await updateDoc(doc(db,'chats',chatId),{lastText:'Опрос: '+q.slice(0,40),lastAt:Date.now()});
      toast('Опрос создан'); closeModal();
    }}>Создать опрос</button>
  </div>;
}

/* ═══════════ Поиск пользователей (нечёткий, с кэшем) ═══════════ */
let _allUsersCache:any[]|null=null;
let _allUsersCacheAt=0;
async function searchUsersFuzzy(qStr:string, excludeUn:string):Promise<any[]>{
  if(!qStr||qStr.length<2) return [];
  if(!rl.check('search').ok) return [];
  const now=Date.now();
  if(!_allUsersCache||now-_allUsersCacheAt>60_000){
    try{
      const snap=await getDocs(query(collection(db,'users'),limit(300)));
      const arr:any[]=[]; snap.forEach(d=>arr.push(d.data()));
      _allUsersCache=arr; _allUsersCacheAt=now;
    }catch{ return []; }
  }
  return _allUsersCache
    .filter(u=>u.username!==excludeUn&&u.privacy?.searchable!==false)
    .map(u=>({...u,_score:Math.max(fuzzyScore(qStr,u.username),fuzzyScore(qStr,u.name))}))
    .filter(u=>u._score>0)
    .sort((a,b)=>b._score-a._score)
    .slice(0,15);
}

function NewChatModal({me,onOpenChat}:any){
  const [tab,setTab]=useState<'dm'|'group'|'channel'>('dm');
  const [title,setTitle]=useState('');
  const [un,setUn]=useState('');
  const [about,setAbout]=useState('');
  const [pub,setPub]=useState(true);
  const [search,setSearch]=useState('');
  const [found,setFound]=useState<any[]>([]);
  const searchTimer=useRef<any>(null);
  const doSearch=(s:string)=>{
    setSearch(s);
    clearTimeout(searchTimer.current);
    searchTimer.current=setTimeout(async()=>{ setFound(await searchUsersFuzzy(s,me.username)); },300); // дебаунс
  };
  return <div>
    <h2>Новый чат</h2>
    <div className="vg-tabs">
      {(['dm','group','channel'] as const).map(t=><button key={t} className={tab===t?'on':''} onClick={()=>setTab(t)}>{t==='dm'?'Личные':t==='group'?'Группа':'Канал'}</button>)}
    </div>
    {tab!=='dm'?<>
      <input className="vg-input" placeholder="Название" value={title} onChange={e=>setTitle(e.target.value)}/>
      <input className="vg-input" placeholder="username (опц.)" value={un} onChange={e=>setUn(e.target.value.replace(/[^a-z0-9_]/gi,''))}/>
      <textarea className="vg-input" placeholder="Описание" value={about} onChange={e=>setAbout(e.target.value)} rows={2}/>
      <label className="vg-check"><input type="checkbox" checked={pub} onChange={e=>setPub(e.target.checked)}/> Публичный</label>
      <button className="vg-btn primary" onClick={async()=>{
        if(!title.trim()){toast('Введите название');return;}
        const check=rl.check('chat');
        if(!check.ok){toast(`Лимит создания чатов. Подождите ${check.wait} сек`);return;}
        const id=await fbCreateChat(me.username,tab,title.trim(),un.trim(),pub,about);
        closeModal(); onOpenChat(id); toast('Создано');
      }}>Создать</button>
    </>:<>
      <input className="vg-input" placeholder="Поиск (имя или юзернейм, можно с опечатками)..." value={search} onChange={e=>doSearch(e.target.value)}/>
      <div style={{maxHeight:300,overflow:'auto'}}>
        {found.map(u=><div key={u.username} className="vg-botrow">
          <Avatar name={u.name} src={u.avatar} size={34}/>
          <div style={{flex:1}}><NameBadge user={u} name={u.name}/> <span className="vg-muted">@{u.username}</span></div>
          <button className="vg-chip tiny" onClick={async()=>{
            /* проверка приватности получателя */
            if(u.privacy?.dmPolicy==='nobody'&&!me.isAdmin){ toast('Пользователь закрыл личные сообщения'); return; }
            const id=await fbCreateDM(me.username,u.username);
            closeModal(); onOpenChat(id);
          }}>Написать</button>
        </div>)}
        {search.length>=2&&found.length===0&&<div className="vg-muted" style={{padding:8}}>Не найдено</div>}
      </div>
    </>}
  </div>;
}

function AddMemberModal({chatId,me}:any){
  const [search,setSearch]=useState('');
  const [found,setFound]=useState<any[]>([]);
  const [members,setMembers]=useState<string[]>([]);
  const searchTimer=useRef<any>(null);
  useEffect(()=>{getDoc(doc(db,'chats',chatId)).then(s=>{if(s.exists())setMembers(s.data().members||[]);});},[chatId]);
  const doSearch=(s:string)=>{
    setSearch(s);
    clearTimeout(searchTimer.current);
    searchTimer.current=setTimeout(async()=>{
      const res=await searchUsersFuzzy(s,me.username);
      setFound(res.filter(u=>!members.includes(u.username)));
    },300);
  };
  return <div>
    <h2>Добавить участника</h2>
    <input className="vg-input" placeholder="Поиск (можно с опечатками)..." value={search} onChange={e=>doSearch(e.target.value)}/>
    <div style={{maxHeight:300,overflow:'auto'}}>
      {found.map(u=><div key={u.username} className="vg-botrow">
        <Avatar name={u.name} src={u.avatar} size={32}/>
        <div style={{flex:1}}>{u.name} <span className="vg-muted">@{u.username}</span></div>
        <button className="vg-chip tiny" onClick={async()=>{
          await updateDoc(doc(db,'chats',chatId),{members:arrayUnion(u.username),['perms.'+u.username]:{role:'member',canText:true,canMedia:true,canLinks:true,mutedUntil:0}});
          setMembers(m=>[...m,u.username]);
          toast('Добавлен: @'+u.username);
        }}>Добавить</button>
      </div>)}
    </div>
  </div>;
}

function ModerationModal({chatId,me}:any){
  const [chat,setChat]=useState<any>(null);
  useEffect(()=>{
    const unsub=onSnapshot(doc(db,'chats',chatId),s=>{if(s.exists())setChat({...s.data(),id:s.id});});
    return unsub;
  },[chatId]);
  if(!chat) return <div>Загрузка...</div>;
  const members:string[]=chat.members||[];
  const perms=chat.perms||{};
  const setPerm=async(un:string,field:string,val:any)=>{
    await updateDoc(doc(db,'chats',chatId),{['perms.'+un+'.'+field]:val});
  };
  return <div>
    <h2>Модерация</h2>
    <div className="vg-muted" style={{fontSize:13,marginBottom:10}}>Права участников, мут и бан</div>
    <div style={{maxHeight:380,overflow:'auto'}}>
      {members.filter(un=>un!==chat.ownerId).map(un=>{
        const p=perms[un]||{};
        const muted=(p.mutedUntil||0)>Date.now();
        return <div key={un} className="vg-mod-row">
          <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:6}}>
            <Avatar name={un} size={28}/>
            <b style={{flex:1}}>@{un}</b>
            {muted&&<span className="vg-tag warn">мут до {fmtTime(p.mutedUntil)}</span>}
          </div>
          <div style={{display:'flex',gap:6,flexWrap:'wrap'}}>
            <label className="vg-check sm"><input type="checkbox" checked={p.canText!==false} onChange={e=>setPerm(un,'canText',e.target.checked)}/> Текст</label>
            <label className="vg-check sm"><input type="checkbox" checked={p.canMedia!==false} onChange={e=>setPerm(un,'canMedia',e.target.checked)}/> Медиа</label>
            <label className="vg-check sm"><input type="checkbox" checked={p.canLinks!==false} onChange={e=>setPerm(un,'canLinks',e.target.checked)}/> Ссылки</label>
            <button className="vg-chip tiny" onClick={async()=>{
              const min=parseInt(prompt('Мут на сколько минут?','30')||'0');
              if(min>0){await setPerm(un,'mutedUntil',Date.now()+min*60000);toast(`@${un} в муте на ${min} мин`);}
            }}>{IC.timer(11)} Мут</button>
            {muted&&<button className="vg-chip tiny" onClick={()=>setPerm(un,'mutedUntil',0)}>Размут</button>}
            <button className="vg-chip tiny danger" onClick={async()=>{
              if(!confirm(`Кикнуть @${un}?`))return;
              await updateDoc(doc(db,'chats',chatId),{members:arrayRemove(un),banned:arrayUnion(un)});
              toast(`@${un} забанен и кикнут`);
            }}>{IC.ban(11)} Бан</button>
          </div>
        </div>;
      })}
    </div>
    {(chat.banned||[]).length>0&&<>
      <h3 style={{marginTop:10}}>Забаненные</h3>
      {(chat.banned||[]).map((un:string)=><div key={un} style={{display:'flex',gap:8,alignItems:'center',padding:'4px 0'}}>
        @{un}
        <button className="vg-chip tiny" onClick={async()=>{
          await updateDoc(doc(db,'chats',chatId),{banned:arrayRemove(un)});
          toast('Разбанен');
        }}>Разбан</button>
      </div>)}
    </>}
  </div>;
}

function ForwardModal({msg,me,onOpenChat}:any){
  const [chats,setChats]=useState<any[]>([]);
  useEffect(()=>{
    getDocs(query(collection(db,'chats'),where('members','array-contains',me.username))).then(snap=>{
      const arr:any[]=[]; snap.forEach(d=>arr.push({...d.data(),id:d.id})); setChats(arr);
    });
  },[me.username]);
  return <div>
    <h2>Переслать</h2>
    <div style={{maxHeight:340,overflow:'auto'}}>
      {chats.map(c=>{
        let t=c.title; if(c.type==='saved')t='Избранное';
        if(c.type==='dm')t=(c.members||[]).find((m:string)=>m!==me.username)||'Диалог';
        return <div key={c.id} className="vg-botrow" onClick={async()=>{
          if(!rl.check('msg').ok){toast('Слишком быстро');return;}
          await fbSendMessage(c.id,me.username,`Пересланное от @${msg.senderId}:\n${msg.text||''}`,{fileJson:msg.fileJson||null});
          toast('Переслано'); closeModal(); onOpenChat(c.id);
        }}>
          <Avatar name={t} src={c.avatar} size={32} ch={c.type==='channel'}/>
          <div>{t}</div>
        </div>;
      })}
    </div>
  </div>;
}

const ALL_R_LIST=['👍','❤️','🔥','😂','😮','😢','👎','😡','🎉','🤔','💯','👀','🙏','😍'];
function ChatSettingsModal({chatId,me}:any){
  const [chat,setChat]=useState<any>(null);
  const [title,setTitle]=useState('');
  const [about,setAbout]=useState('');
  const [avatar,setAvatar]=useState('');
  const [autoDel,setAutoDel]=useState(0);
  const [reactMode,setReactMode]=useState<'all'|'none'|'custom'>('all');
  const [allowedR,setAllowedR]=useState<string[]>([]);
  useEffect(()=>{
    getDoc(doc(db,'chats',chatId)).then(s=>{
      if(s.exists()){const c=s.data();setChat(c);setTitle(c.title);setAbout(c.about||'');setAvatar(c.avatar||'');setAutoDel(c.autoDelete||0);
        if(c.reactMode) setReactMode(c.reactMode);
        if(c.allowedReactions&&Array.isArray(c.allowedReactions)) setAllowedR(c.allowedReactions);
      }
    });
  },[chatId]);
  if(!chat) return <div>Загрузка...</div>;
  const isOwner=chat.ownerId===me.username||me.isAdmin;
  const isChannel=chat.type==='channel';
  const link=`${location.origin}/#${chat.username||chatId}`;
  return <div>
    <h2>Настройки {isChannel?'канала':'группы'}</h2>
    {/* Ссылка для приглашения */}
    <div className="vg-link-row">
      {IC.link(14)} <span style={{flex:1,fontSize:13,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{link}</span>
      <button className="vg-chip tiny" onClick={()=>{navigator.clipboard?.writeText(link);toast('Ссылка скопирована');}}>{IC.copy(11)} Копировать</button>
    </div>
    {isOwner?<>
      <input className="vg-input" value={title} onChange={e=>setTitle(e.target.value)} placeholder="Название"/>
      <textarea className="vg-input" value={about} onChange={e=>setAbout(e.target.value)} placeholder="Описание" rows={2}/>
      <div style={{display:'flex',gap:8,alignItems:'center',marginBottom:8}}>
        <Avatar name={title} src={avatar} size={46} ch={isChannel}/>
        <button className="vg-chip" onClick={()=>{
          const i=document.createElement('input');i.type='file';i.accept='image/*';
          i.onchange=async()=>{const f=i.files?.[0];if(f&&f.size<500*1024)setAvatar(await fileToUrl(f));else toast('До 500KB');};i.click();
        }}>Сменить аватар</button>
      </div>

      {/* Реакции */}
      <h3>Реакции</h3>
      <div style={{display:'flex',gap:6,marginBottom:6}}>
        {(['all','none','custom'] as const).map(m=><button key={m} className={`vg-chip${reactMode===m?' accent':''}`} onClick={()=>setReactMode(m)}>{m==='all'?'Все':m==='none'?'Запретить':'Выбрать'}</button>)}
      </div>
      {reactMode==='custom'&&<div className="vg-react-picker">
        {ALL_R_LIST.map(e=><button key={e} className={`vg-react-pick${allowedR.includes(e)?' on':''}`} onClick={()=>setAllowedR(p=>p.includes(e)?p.filter(x=>x!==e):[...p,e])}>
          <img src={tw(e)} width={20} height={20} alt={e}/>
        </button>)}
      </div>}

      {/* Автоудаление */}
      <h3>Автоудаление сообщений</h3>
      <select className="vg-input" value={autoDel} onChange={e=>setAutoDel(parseInt(e.target.value))}>
        <option value={0}>Выключено</option>
        <option value={60}>1 минута</option>
        <option value={300}>5 минут</option>
        <option value={3600}>1 час</option>
        <option value={86400}>24 часа</option>
      </select>

      <button className="vg-btn primary" style={{marginTop:10}} onClick={async()=>{
        await updateDoc(doc(db,'chats',chatId),{title:title.slice(0,60),about:about.slice(0,300),avatar,autoDelete:autoDel,reactMode,allowedReactions:allowedR});
        toast('Сохранено'); closeModal();
      }}>Сохранить</button>
      <div style={{display:'flex',gap:8,marginTop:10,flexWrap:'wrap'}}>
        <button className="vg-chip" onClick={()=>{closeModal();openModal('addmember',{chatId,me});}}>{IC.plus(12)} Участники</button>
        <button className="vg-chip" onClick={()=>{closeModal();openModal('moderation',{chatId,me});}}>{IC.shield(12)} Модерация</button>
        <button className="vg-chip" onClick={async()=>{
          const {chat:c,messages}=await fbExportChat(chatId);
          const blob=JSON.stringify({chat:c,messages},null,2);
          const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([blob],{type:'application/json'}));a.download=`vibegram-${chatId}.json`;a.click();
        }}>{IC.download(12)} Экспорт</button>
        <button className="vg-chip" onClick={()=>{closeModal();openModal('stats',{chatId,me});}}>{IC.stats(12)} Статистика</button>
      </div>
    </>:<div className="vg-muted">Только владелец может менять настройки</div>}
  </div>;
}

function ChatInfoModal({chatId,me}:any){
  const [chat,setChat]=useState<any>(null);
  useEffect(()=>{getDoc(doc(db,'chats',chatId)).then(s=>{if(s.exists())setChat({...s.data(),id:s.id});});},[chatId]);
  if(!chat) return <div>Загрузка...</div>;
  return <div>
    <h2>Информация</h2>
    <div style={{display:'flex',gap:12,alignItems:'center',marginBottom:12}}>
      <Avatar name={chat.title||'Чат'} src={chat.avatar} size={56} ch={chat.type==='channel'}/>
      <div>
        <div style={{fontWeight:700,fontSize:17}}>{chat.title||(chat.type==='saved'?'Избранное':'Диалог')}</div>
        <div className="vg-muted">{chat.type} · {(chat.members||[]).length} участн.</div>
      </div>
    </div>
    {chat.about&&<div className="vg-muted" style={{marginBottom:10}}>{chat.about}</div>}
    <div style={{display:'flex',gap:8,flexWrap:'wrap'}}>
      <button className="vg-chip" onClick={async()=>{
        const msgs=await getDocs(query(collection(db,'chats',chatId,'messages'),orderBy('createdAt','asc')));
        const arr:any[]=[]; msgs.forEach(d=>arr.push(d.data()));
        const blob=new Blob([JSON.stringify({chat,messages:arr},null,2)],{type:'application/json'});
        const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=`vibegram-${chatId}.json`;a.click();
      }}>{IC.download(13)} Экспорт JSON</button>
      <button className="vg-chip danger" onClick={async()=>{
        if(!confirm('Покинуть чат?'))return;
        await fbLeaveChat(chatId,me.username);
        closeModal(); toast('Вы вышли');
      }}>Покинуть</button>
    </div>
  </div>;
}

/* ═══════════ Бизнес: AI-бот на свой аккаунт ═══════════ */
const AI_PROVIDERS=[
  {id:'gemini',name:'Google Gemini',models:['gemini-1.5-flash','gemini-1.5-pro','gemini-2.0-flash-exp'],note:'Работает из браузера. Ключ: aistudio.google.com'},
  {id:'openrouter',name:'OpenRouter',models:['openai/gpt-4o-mini','anthropic/claude-3.5-sonnet','google/gemini-flash-1.5','meta-llama/llama-3.1-8b-instruct'],note:'Работает из браузера. Ключ: openrouter.ai/keys'},
  {id:'openai',name:'OpenAI ChatGPT',models:['gpt-4o-mini','gpt-4o','gpt-3.5-turbo'],note:'Может блокировать CORS — лучше OpenRouter'},
  {id:'claude',name:'Anthropic Claude',models:['claude-3-5-haiku-20241022','claude-3-5-sonnet-20241022'],note:'Может блокировать CORS — лучше OpenRouter'},
];
function BusinessTab({me}:any){
  const ai=me.aiConfig||{};
  const [provider,setProvider]=useState(ai.provider||'gemini');
  const [apiKey,setApiKey]=useState(ai.apiKey||'');
  const [model,setModel]=useState(ai.model||'');
  const [prompt,setPrompt]=useState(ai.systemPrompt||'Ты — вежливый ассистент бизнеса. Отвечай кратко и по делу на русском.');
  const [enabled,setEnabled]=useState(!!ai.enabled);
  const [testing,setTesting]=useState(false);
  const prov=AI_PROVIDERS.find(p=>p.id===provider)!;
  if(!isPremium(me)) return <div style={{padding:'10px 0'}}>
    <div className="vg-prem-banner"><div className="vg-prem-title">{IC.star(16)} Бизнес — функция Premium</div>
    <div className="vg-muted" style={{fontSize:13,marginTop:4}}>AI-автоответчик на ваш аккаунт доступен с VibeGram Premium. Попросите админа активировать.</div></div>
  </div>;
  return <div>
    <h3 style={{display:'flex',alignItems:'center',gap:6}}>{IC.bot(16)} Бизнес AI-ассистент</h3>
    <div className="vg-muted" style={{fontSize:12.5,marginBottom:10}}>Подключите свой AI. Когда вам пишут в ЛС — ассистент ответит автоматически от вашего имени.</div>
    <label className="vg-lbl">Провайдер</label>
    <div style={{display:'flex',gap:6,flexWrap:'wrap',marginBottom:8}}>
      {AI_PROVIDERS.map(p=><button key={p.id} className={`vg-chip${provider===p.id?' accent':''}`} onClick={()=>{setProvider(p.id);setModel('');}}>{p.name}</button>)}
    </div>
    <div className="vg-muted" style={{fontSize:11,marginBottom:8}}>{prov.note}</div>
    <label className="vg-lbl">Модель</label>
    <select className="vg-input" value={model} onChange={e=>setModel(e.target.value)}>
      <option value="">По умолчанию ({prov.models[0]})</option>
      {prov.models.map(m=><option key={m} value={m}>{m}</option>)}
    </select>
    <label className="vg-lbl">API-ключ</label>
    <input className="vg-input" type="password" value={apiKey} onChange={e=>setApiKey(e.target.value)} placeholder="sk-... / AIza... / ваш ключ"/>
    <label className="vg-lbl">Инструкция ассистенту (роль)</label>
    <textarea className="vg-input" rows={3} value={prompt} onChange={e=>setPrompt(e.target.value)}/>
    <label className="vg-check"><input type="checkbox" checked={enabled} onChange={e=>setEnabled(e.target.checked)}/> Включить автоответчик</label>
    <div style={{display:'flex',gap:8,marginTop:8}}>
      <button className="vg-btn primary" onClick={async()=>{
        await fbSaveAIConfig(me.username,{provider,apiKey,model,systemPrompt:prompt,enabled});
        toast('Бизнес-бот сохранён');
      }}>Сохранить</button>
      <button className="vg-btn" disabled={testing||!apiKey} onClick={async()=>{
        setTesting(true);
        const r=await callAI(provider,apiKey,model,prompt,'Привет! Это тест. Ответь одним предложением.');
        setTesting(false);
        alert('Ответ AI:\n\n'+r);
      }}>{testing?'Тест...':'Проверить'}</button>
    </div>
    <div className="vg-muted" style={{fontSize:11,marginTop:8}}>Ключ хранится в вашем профиле в БД. Не делитесь аккаунтом.</div>
  </div>;
}

/* ═══════════ Настройки: профиль, приватность, удаление ═══════════ */
function SettingsModal({me,theme,setTheme,wall,setWall,onLogout}:any){
  const [tab,setTab]=useState<'profile'|'privacy'|'appearance'|'business'|'danger'>('profile');
  const [name,setName]=useState(me.name);
  const [bio,setBio]=useState(me.bio||'');
  const [avatar,setAvatar]=useState(me.avatar||'');
  const [statusEmoji,setStatusEmoji]=useState(me.statusEmoji||'');
  const [cover,setCover]=useState(me.cover||'');
  const [nameColor,setNameColor]=useState(me.nameColor||'');
  const [profileMusic,setProfileMusic]=useState(me.profileMusic||'');
  const [profileMusicName,setProfileMusicName]=useState(me.profileMusicName||'');
  const [oldPw,setOldPw]=useState('');
  const [newPw,setNewPw]=useState('');
  const priv=me.privacy||{dmPolicy:'all',showLastSeen:true,searchable:true};
  const [delPw,setDelPw]=useState('');
  const [delBusy,setDelBusy]=useState(false);
  const setPriv=async(patch:any)=>{
    await updateDoc(doc(db,'users',me.username),{privacy:{...priv,...patch}});
    toast('Сохранено');
  };
  return <div className="vg-settings">
    <h2>Настройки</h2>
    <div className="vg-tabs">
      <button className={tab==='profile'?'on':''} onClick={()=>setTab('profile')}>Профиль</button>
      <button className={tab==='privacy'?'on':''} onClick={()=>setTab('privacy')}>Конфиденциальность</button>
      <button className={tab==='appearance'?'on':''} onClick={()=>setTab('appearance')}>Вид</button>
      <button className={tab==='business'?'on':''} onClick={()=>setTab('business')}>Бизнес</button>
      <button className={tab==='danger'?'on':''} onClick={()=>setTab('danger')}>Аккаунт</button>
    </div>
    {tab==='business'&&<BusinessTab me={me}/>}

    {tab==='profile'&&<div>
      {isPremium(me)&&<div className="vg-prem-banner">
        <div className="vg-prem-title">{IC.star(16)} VibeGram Premium активен</div>
        <div className="vg-muted" style={{fontSize:12,marginTop:4}}>{me.premiumUntil?'До '+new Date(me.premiumUntil).toLocaleDateString('ru-RU'):'Навсегда'}</div>
      </div>}
      {me.isAdmin&&!isPremium(me)&&<button className="vg-chip accent" style={{marginBottom:10}} onClick={async()=>{ await fbSetPremium(me.username,me.username,0); toast('Premium активирован'); }}>{IC.star(13)} Активировать себе Premium</button>}
      <label className="vg-lbl">Имя</label>
      <input className="vg-input" value={name} onChange={e=>setName(e.target.value)}/>
      <label className="vg-lbl">Био</label>
      <input className="vg-input" value={bio} onChange={e=>setBio(e.target.value)}/>
      <label className="vg-lbl">Аватар</label>
      <div style={{display:'flex',gap:8,alignItems:'center'}}>
        <Avatar name={name} src={avatar} size={50}/>
        <button className="vg-chip" onClick={()=>{
          const i=document.createElement('input');i.type='file';i.accept='image/*';
          i.onchange=async()=>{const f=i.files?.[0];if(f&&f.size<400*1024)setAvatar(await fileToUrl(f));else toast('До 400KB');};i.click();
        }}>Загрузить</button>
        {avatar&&<button className="vg-chip" onClick={()=>setAvatar('')}>Убрать</button>}
      </div>
      <label className="vg-lbl">Эмодзи-статус</label>
      <div style={{display:'flex',gap:4,flexWrap:'wrap',marginBottom:6}}>
        <button className={`vg-react-pick${statusEmoji===''?' on':''}`} onClick={()=>setStatusEmoji('')} style={{fontSize:14}}>—</button>
        {['😀','😎','🥳','😴','🤓','🥹','🔥','💼','🎮','🎧','❤️','🌚','🚀','📚','☕'].map(e=>
          <button key={e} className={`vg-react-pick${statusEmoji===e?' on':''}`} onClick={()=>setStatusEmoji(e)} style={{fontSize:18}}>{e}</button>)}
      </div>
      <label className="vg-lbl">Музыка профиля</label>
      <div style={{display:'flex',gap:8,alignItems:'center',marginBottom:6}}>
        <button className="vg-chip" onClick={()=>{
          const i=document.createElement('input');i.type='file';i.accept='audio/*';
          i.onchange=async()=>{const f=i.files?.[0];if(!f)return;if(f.size<500*1024){setProfileMusic(await fileToUrl(f));setProfileMusicName(f.name);}else{try{const url=await fbUploadFile(f,me.username);setProfileMusic(url);setProfileMusicName(f.name);toast('Загружено');}catch{toast('Включите Storage');}}};i.click();
        }}>{IC.music(13)} Загрузить трек</button>
        {profileMusic&&<><span className="vg-muted" style={{fontSize:12}}>{profileMusicName}</span><button className="vg-chip" onClick={()=>{setProfileMusic('');setProfileMusicName('');}}>Убрать</button></>}
      </div>
      {/* Premium: обложка профиля + цвет имени */}
      <label className="vg-lbl" style={{display:'flex',alignItems:'center',gap:4}}>Обложка профиля {!isPremium(me)&&<span className="vg-prem-lock">{IC.star(11)} Premium</span>}</label>
      <div style={{display:'flex',gap:8,alignItems:'center'}}>
        {cover&&<div style={{width:80,height:36,borderRadius:8,backgroundImage:`url(${cover})`,backgroundSize:'cover'}}/>}
        <button className="vg-chip" disabled={!isPremium(me)} onClick={()=>{
          if(!isPremium(me)){toast('Обложка — Premium');return;}
          const i=document.createElement('input');i.type='file';i.accept='image/*';
          i.onchange=async()=>{const f=i.files?.[0];if(!f)return;if(f.size<500*1024)setCover(await fileToUrl(f));else{try{setCover(await fbUploadFile(f,me.username));}catch{toast('Storage');}}};i.click();
        }}>Загрузить</button>
        {cover&&<button className="vg-chip" onClick={()=>setCover('')}>Убрать</button>}
      </div>
      <label className="vg-lbl" style={{display:'flex',alignItems:'center',gap:4}}>Цвет имени {!isPremium(me)&&<span className="vg-prem-lock">{IC.star(11)} Premium</span>}</label>
      <div style={{display:'flex',gap:6,flexWrap:'wrap'}}>
        {['','#f5b50a','#a855f7','#22c55e','#ef4444','#06b6d4','#ec4899'].map(c=><button key={c} disabled={!isPremium(me)} onClick={()=>isPremium(me)&&setNameColor(c)} style={{width:24,height:24,borderRadius:6,background:c||'var(--bg3)',border:nameColor===c?'2px solid var(--accent)':'1px solid var(--border)',cursor:'pointer'}}>{c?'':'—'}</button>)}
      </div>
      <button className="vg-btn primary" style={{marginTop:10}} onClick={async()=>{
        await updateDoc(doc(db,'users',me.username),{name:name.slice(0,40),bio:bio.slice(0,200),avatar,statusEmoji,profileMusic,profileMusicName,cover,nameColor});
        toast('Сохранено');
      }}>Сохранить</button>
      <h3 style={{marginTop:16}}>Смена пароля</h3>
      <input className="vg-input" type="password" placeholder="Старый пароль" value={oldPw} onChange={e=>setOldPw(e.target.value)}/>
      <input className="vg-input" type="password" placeholder="Новый пароль (от 8 символов)" value={newPw} onChange={e=>setNewPw(e.target.value)}/>
      <button className="vg-btn" onClick={async()=>{
        if(!oldPw||!newPw)return;
        try{
          await fbChangePassword(me.username,oldPw,newPw);
          toast('Пароль изменён'); setOldPw(''); setNewPw('');
        }catch(e:any){ toast(e.message||'Ошибка'); }
      }}>Сменить пароль</button>
      <div className="vg-muted" style={{fontSize:11.5,marginTop:4}}>Пароль хранится только в Firebase Authentication.</div>
    </div>}

    {tab==='privacy'&&<div>
      <h3 style={{display:'flex',alignItems:'center',gap:6}}>{IC.lock(15)} Безопасность входа</h3>
      <div style={{marginBottom:12}}>
        <div className="vg-muted" style={{fontSize:13,marginBottom:6}}>
          Email: {me.email||'—'} {me.emailVerified||fbIsEmailVerified()?<span style={{color:'#34d399'}}>· подтверждён</span>:<span style={{color:'#fbbf24'}}>· не подтверждён</span>}
        </div>
        {!(me.emailVerified||fbIsEmailVerified())&&me.email&&<button className="vg-chip" onClick={async()=>{try{await fbResendVerification();toast('Письмо отправлено');}catch(e:any){toast(e.message);}}}>Отправить письмо для подтверждения</button>}
        {(!me.email||me.email.endsWith('@users.vibegram.app'))&&<button className="vg-chip accent" onClick={async()=>{
          const em=prompt('Ваш email:'); if(!em) return;
          const pw=prompt('Текущий пароль для подтверждения:'); if(!pw) return;
          try{ await fbAttachEmail(me.username,em,pw); toast('Email привязан! Проверьте почту для подтверждения.'); }catch(e:any){ toast(e.message); }
        }}>Привязать email к аккаунту</button>}
        <label className="vg-check" style={{marginTop:8}}><input type="checkbox" checked={priv.twoFA===true} onChange={e=>{
          if(e.target.checked&&!(me.emailVerified||fbIsEmailVerified())){toast('Сначала подтвердите email');return;}
          setPriv({twoFA:e.target.checked});
        }}/> Двухфакторная защита по email</label>
        <div className="vg-muted" style={{fontSize:11.5}}>При входе с нового устройства потребуется код из письма.</div>
      </div>
      <h3 style={{display:'flex',alignItems:'center',gap:6}}>{IC.lock(15)} Кто может писать мне в ЛС</h3>
      <div style={{display:'flex',gap:8,margin:'6px 0 14px'}}>
        <button className={`vg-chip${priv.dmPolicy==='all'?' accent':''}`} onClick={()=>setPriv({dmPolicy:'all'})}>Все</button>
        <button className={`vg-chip${priv.dmPolicy==='nobody'?' accent':''}`} onClick={()=>setPriv({dmPolicy:'nobody'})}>Никто</button>
      </div>
      <h3 style={{display:'flex',alignItems:'center',gap:6}}>{IC.eye(15)} Видимость</h3>
      <label className="vg-check"><input type="checkbox" checked={priv.showLastSeen!==false} onChange={e=>setPriv({showLastSeen:e.target.checked})}/> Показывать время последнего визита</label>
      <label className="vg-check"><input type="checkbox" checked={priv.searchable!==false} onChange={e=>setPriv({searchable:e.target.checked})}/> Показывать меня в поиске</label>
      <label className="vg-check"><input type="checkbox" disabled={!isPremium(me)} checked={priv.hideRead===true} onChange={e=>{if(!isPremium(me)){toast('Скрытие прочтения — Premium');return;}setPriv({hideRead:e.target.checked});}}/> Скрывать «прочитано» {!isPremium(me)&&<span className="vg-prem-lock">{IC.star(11)} Premium</span>}</label>
      <h3 style={{marginTop:14,display:'flex',alignItems:'center',gap:6}}>{IC.lock(15)} Безопасность</h3>
      <label className="vg-check"><input type="checkbox" checked={me.privacy?.e2e===true} onChange={async e=>{ await setPriv({e2e:e.target.checked}); toast('E2E-шифрование в ЛС '+(e.target.checked?'включено':'выключено')); }}/> Сквозное шифрование в ЛС (AES-GCM)</label>
      <div className="vg-muted" style={{fontSize:12,lineHeight:1.5,marginTop:6}}>Даже при утечке БД ваши сообщения не читаются без вашего устройства. Ключ — производный от username обоих собеседников (PBKDF2+SHA256, 10k итераций).</div>
    </div>}

    {tab==='appearance'&&<div>
      <label className="vg-lbl">Тема</label>
      <div className="vg-theme-pick">
        {[['light','Светлая'],['dark','Тёмная'],['black','Чёрная'],['blue','Синяя'],['mono','Моно'],['nord','Nord'],['rose','Rose'],['forest','Лес']].map(([k,l])=>
          <button key={k} className={`vg-tdot t-${k}${theme===k?' on':''}`} onClick={()=>setTheme(k)}>{l}</button>)}
      </div>
      <label className="vg-lbl" style={{marginTop:10}}>Акцентный цвет</label>
      <div style={{display:'flex',gap:6,flexWrap:'wrap',alignItems:'center'}}>
        {['#3b82f6','#8b5cf6','#22c55e','#f97316','#ef4444','#ec4899','#eab308','#06b6d4'].map(col=>
          <button key={col} onClick={()=>{document.documentElement.style.setProperty('--accent',col);localStorage.setItem('vg_accent',col);toast('Цвет применён');}}
            style={{width:26,height:26,borderRadius:8,background:col,border:'2px solid var(--border)',cursor:'pointer'}}/>)}
        <input type="color" defaultValue={localStorage.getItem('vg_accent')||'#3b82f6'} onChange={e=>{document.documentElement.style.setProperty('--accent',e.target.value);localStorage.setItem('vg_accent',e.target.value);}} style={{width:30,height:30,border:'none',background:'none',cursor:'pointer'}}/>
        <button className="vg-chip tiny" onClick={()=>{localStorage.removeItem('vg_accent');location.reload();}}>Сброс</button>
      </div>
      <label className="vg-lbl" style={{marginTop:10}}>Обои чата</label>
      <div style={{display:'flex',gap:8,flexWrap:'wrap'}}>
        <button className="vg-chip" onClick={()=>setWall('')}>Без обоев</button>
        <button className="vg-chip" onClick={()=>{
          const i=document.createElement('input');i.type='file';i.accept='image/*,video/*';
          i.onchange=async()=>{const f=i.files?.[0];if(f)setWall(await fileToUrl(f));};i.click();
        }}>Загрузить</button>
      </div>
    </div>}

    {tab==='danger'&&<div>
      <h3 style={{color:'#f87171'}}>Удаление аккаунта</h3>
      <div className="vg-muted" style={{fontSize:13,marginBottom:10}}>
        Безвозвратно удаляет: профиль, личные чаты с сообщениями, ваших ботов, Auth-аккаунт.
        Группы, где вы владелец, перейдут другому участнику.
      </div>
      <input className="vg-input" type="password" placeholder="Подтвердите паролем" value={delPw} onChange={e=>setDelPw(e.target.value)}/>
      <button className="vg-btn" style={{background:'#7f1d1d',border:'none',color:'#fff'}} disabled={delBusy} onClick={async()=>{
        if(!delPw){toast('Введите пароль');return;}
        if(!confirm('Точно удалить аккаунт? Это необратимо.'))return;
        setDelBusy(true);
        try{
          await fbDeleteAccount(me.username,delPw);
          localStorage.removeItem('vg_session');
          toast('Аккаунт удалён');
          setTimeout(()=>{ closeModal(); onLogout(); },800);
        }catch(e:any){ toast(e.message||'Ошибка'); }
        setDelBusy(false);
      }}>{delBusy?<span className="vg-spinner"/>:'Удалить аккаунт навсегда'}</button>
    </div>}
  </div>;
}

/* ═══════════ Stories — лента вверху списка чатов ═══════════ */
function StoriesBar({me,usersCache,onOpenStory}:any){
  const [stories,setStories]=useState<any[]>([]);
  const [viewing,setViewing]=useState<any[]|null>(null);
  useEffect(()=>{ const off=onStories(s=>setStories(s)); return off; },[]);
  const myStories=stories.filter(s=>s.owner===me.username);
  const othersStories=stories.filter(s=>s.owner!==me.username);
  const groups:Record<string,any[]>={};
  othersStories.forEach(s=>{ (groups[s.owner]=groups[s.owner]||[]).push(s); });
  const goStory=(s:any)=>{ setViewing([s]); fbViewStory(s.id,me.username); };
  const own=(own:any)=>{ fbDeleteStory(own.id).catch(()=>{}); };
  return <div className="vg-stories-bar">
    <div className="vg-story-item" onClick={()=>{
      const i=document.createElement('input');i.type='file';i.accept='image/*,video/*';
      i.onchange=async()=>{const f=i.files?.[0];if(!f)return;if(f.size>500*1024){toast('До 500KB для сторис');return;}const data=await fileToUrl(f);await fbPostStory(me.username,{type:f.type.startsWith('video')?'video':'image',data,text:''});};
      i.click();
    }}>
      <Avatar name={me.name} src={me.avatar} size={52}/>
      <div className="vg-story-add">+</div>
    </div>
    {Object.entries(groups).map(([un,list])=>{ const u=usersCache[un]; return (
      <div key={un} className="vg-story-item" onClick={()=>goStory(list[0])}>
        <div className="vg-story-ring"><Avatar name={u?.name||un} src={u?.avatar} size={48}/></div>
        <div className="vg-story-name">{u?.name||un}</div>
      </div>
    );})}
    {viewing&&<div className="vg-story-viewer" onClick={()=>setViewing(null)}>
      <div className="vg-story-progress">{Array(viewing.length).fill(0).map((_,i)=><div key={i} className="vg-story-prog-bar"/>)}</div>
      <img src={viewing[0].data} alt="" className="vg-story-img" onClick={e=>e.stopPropagation()}/>
      <div className="vg-story-viewer-text" onClick={e=>e.stopPropagation()}>{viewing[0].text}</div>
      <button className="vg-story-close" onClick={()=>setViewing(null)}>{IC.close(20)}</button>
      {viewing.length>1&&<button className="vg-story-next" onClick={(e)=>{e.stopPropagation();setViewing(viewing.slice(1));}}>Дальше →</button>}
    </div>}
  </div>;
}

/* ═══════════ Админ-панель ═══════════ */
function AdminModal({me}:any){
  const [users,setUsers]=useState<any[]>([]);
  const [tab,setTab]=useState<'users'|'bans'|'reports'>('users');
  const [banned,setBanned]=useState<any[]>([]);
  const [reports,setReports]=useState<any[]>([]);
  useEffect(()=>{
    getDocs(query(collection(db,'users'),limit(300))).then(snap=>{
      const arr:any[]=[]; snap.forEach(d=>arr.push(d.data()));
      setUsers(arr.filter(u=>!u.isBot));
    });
  },[]);
  useEffect(()=>{ if(tab==='bans') fbListBanned().then(setBanned); if(tab==='reports') fbListReports().then(setReports); },[tab]);
  if(!me.isAdmin) return <div>Нет доступа</div>;
  return <div>
    <h2 style={{display:'flex',alignItems:'center',gap:8}}>{IC.crown(18)} Админ-панель</h2>
    <div className="vg-tabs">
      <button className={tab==='users'?'on':''} onClick={()=>setTab('users')}>Пользователи</button>
      <button className={tab==='bans'?'on':''} onClick={()=>setTab('bans')}>Баны</button>
      <button className={tab==='reports'?'on':''} onClick={()=>setTab('reports')}>Жалобы</button>
    </div>
    {tab==='bans'&&<div style={{maxHeight:380,overflow:'auto'}}>
      {banned.map(u=><div key={u.username} className="vg-mod-row">
        <div style={{display:'flex',alignItems:'center',gap:8}}>
          <Avatar name={u.name} src={u.avatar} size={28}/>
          <div style={{flex:1}}>@{u.username}<div className="vg-muted" style={{fontSize:11}}>{u.banReason||'без причины'} · {u.banUntil?'до '+fmtDate(u.banUntil):'навсегда'}</div></div>
          <button className="vg-chip tiny" onClick={async()=>{ await fbUnbanGlobal(u.username,me.username); setBanned(b=>b.filter(x=>x.username!==u.username)); toast('Разбанен'); }}>Разбан</button>
        </div>
      </div>)}
      {banned.length===0&&<div className="vg-muted">Нет банов</div>}
    </div>}
    {tab==='reports'&&<div style={{maxHeight:380,overflow:'auto'}}>
      {reports.map(r=><div key={r.id} className="vg-mod-row">
        <div className="vg-muted" style={{fontSize:11}}>{r.reporter} → @{r.target}</div>
        <div style={{fontSize:13}}>{r.reason}</div>
        <div style={{display:'flex',gap:6,marginTop:4}}>
          <button className="vg-chip tiny danger" onClick={async()=>{ await fbBanGlobal(r.target,r.reason,1440,me.username); await fbResolveReport(r.id); setReports(x=>x.filter(y=>y.id!==r.id)); toast('Забанен на сутки'); }}>Бан 24ч</button>
          <button className="vg-chip tiny" onClick={async()=>{ await fbResolveReport(r.id); setReports(x=>x.filter(y=>y.id!==r.id)); }}>Отклонить</button>
        </div>
      </div>)}
      {reports.length===0&&<div className="vg-muted">Нет жалоб</div>}
    </div>}
    {tab==='users'&&<div style={{maxHeight:380,overflow:'auto'}}>
      {users.map(u=><div key={u.username} className="vg-mod-row">
        <div style={{display:'flex',alignItems:'center',gap:8}}>
          <Avatar name={u.name} src={u.avatar} size={30}/>
          <div style={{flex:1}}>
            <NameBadge user={u} name={u.name}/>
            <div className="vg-muted" style={{fontSize:11}}>@{u.username}</div>
          </div>
          <button className="vg-chip tiny danger" onClick={async()=>{
            if(!confirm(`Удалить профиль @${u.username}? (Auth-аккаунт удалится при его следующем входе)`))return;
            await deleteDoc(doc(db,'users',u.username));
            setUsers(us=>us.filter(x=>x.username!==u.username));
            toast('Профиль удалён');
           }}>{IC.trash(11)}</button>
        </div>
      </div>)}
    </div>}
    {tab==='users'&&<div style={{marginTop:10}}>
      <button className="vg-chip" onClick={async()=>{
        const text=prompt('Текст рассылки всем пользователям:');
        if(!text)return;
        for(const u of users.slice(0,100)){
          const dmId=await fbCreateDM('vibegram',u.username);
          await fbSendMessage(dmId,'vibegram',text);
        }
        toast('Рассылка отправлена');
      }}>Рассылка через бота</button>
    </div>}
    <div style={{marginTop:14,paddingTop:14,borderTop:'1px solid var(--border)'}}>
      <button className="vg-chip danger" onClick={async()=>{
        if(!confirm('ВНИМАНИЕ: Это удалит ВСЕ данные БД — чаты, пользователей, ботов. Твой профиль сохранится. Продолжить?')) return;
        if(!confirm('Точно? Отменить будет нельзя.')) return;
        const res=await fbWipeAll(me.username);
        toast(res);
        setTimeout(()=>location.reload(), 1500);
      }}>{IC.trash(13)} Очистить всю БД</button>
      <div className="vg-muted" style={{fontSize:11,marginTop:6}}>Удаляет всё, кроме твоего профиля. Созданные в БД токены админа тоже сохраняются.</div>
    </div>
  </div>;
}

/* ═══════════ Конструктор ботов ═══════════ */
function BotCreateModal({me}:any){
  const [un,setUn]=useState('');
  const [name,setName]=useState('');
  return <div>
    <h2>Создать бота</h2>
    <input className="vg-input" placeholder="Имя бота" value={name} onChange={e=>setName(e.target.value)}/>
    <input className="vg-input" placeholder="username_bot" value={un} onChange={e=>setUn(e.target.value.replace(/[^a-z0-9_]/gi,'').toLowerCase())}/>
    <button className="vg-btn primary" onClick={async()=>{
      if(!un||!name){toast('Заполните поля');return;}
      const check=rl.check('chat');
      if(!check.ok){toast(`Подождите ${check.wait} сек`);return;}
      const exists=await getDoc(doc(db,'users',un));
      if(exists.exists()){toast('Юзернейм занят');return;}
      await setDoc(doc(db,'users',un),{username:un,name:name.slice(0,40),bio:'Бот',avatar:'',isBot:true,isAdmin:false,privacy:{dmPolicy:'all',showLastSeen:false,searchable:true},folders:[],createdAt:Date.now(),lastSeen:Date.now()});
      await setDoc(doc(db,'bots',un),{ownerUn:me.username,name,rules:[],createdAt:Date.now()});
      toast('Бот создан! Добавьте правила.');
      closeModal();
      setTimeout(()=>openModal('botedit',{bot:{username:un,name,ownerUn:me.username,rules:[]},me}),100);
    }}>Создать</button>
    <div className="vg-muted" style={{fontSize:12,marginTop:8}}>Настройте правила «триггер → ответ» и добавьте бота в группу — он будет отвечать автоматически.</div>
  </div>;
}

function BotEditModal({bot,me}:any){
  const [rules,setRules]=useState<any[]>(bot.rules||[]);
  const [trigger,setTrigger]=useState('');
  const [reply,setReply]=useState('');
  return <div>
    <h2>Правила бота @{bot.username}</h2>
    <div className="vg-muted" style={{fontSize:13,marginBottom:10}}>Если в чате пишут слово-триггер — бот отвечает.</div>
    <div style={{display:'grid',gap:6,marginBottom:10}}>
      {rules.map((r,i)=><div key={i} className="vg-rule-row">
        <span className="vg-tag">{r.trigger}</span>
        <span style={{flex:1,fontSize:13}}>{r.reply}</span>
        <button className="vg-ibtn" onClick={async()=>{
          const next=rules.filter((_,x)=>x!==i);
          setRules(next);
          await updateDoc(doc(db,'bots',bot.username),{rules:next});
        }}>{IC.trash(13)}</button>
      </div>)}
      {rules.length===0&&<div className="vg-muted" style={{fontSize:13}}>Нет правил</div>}
    </div>
    <div style={{display:'flex',gap:6}}>
      <input className="vg-input" placeholder="Триггер" value={trigger} onChange={e=>setTrigger(e.target.value)} style={{flex:1}}/>
      <input className="vg-input" placeholder="Ответ" value={reply} onChange={e=>setReply(e.target.value)} style={{flex:2}}/>
    </div>
    <button className="vg-btn primary" onClick={async()=>{
      if(!trigger.trim()||!reply.trim()){toast('Заполните триггер и ответ');return;}
      if(rules.length>=30){toast('Максимум 30 правил');return;}
      const next=[...rules,{trigger:trigger.trim().slice(0,50),reply:reply.trim().slice(0,500)}];
      setRules(next);
      await updateDoc(doc(db,'bots',bot.username),{rules:next});
      setTrigger('');setReply('');
      toast('Правило добавлено');
    }}>{IC.plus(14)} Создать правило</button>
  </div>;
}

/* ═══════════ CSS ═══════════ */
const CSS=`
:root{--bg:#0a0a0a;--bg2:#111;--bg3:#1a1a1a;--text:#ededed;--muted:#666;--accent:#3b82f6;--msg-bg:#181818;--msg-mine:#1e3a5f;--border:#222;--radius:10px}
.theme-light{--bg:#f5f7f9;--bg2:#fff;--bg3:#eef1f5;--text:#1c1e21;--muted:#636c76;--accent:#2563eb;--msg-bg:#fff;--msg-mine:#dbeafe;--border:#d8dee4}
.theme-graphite{--bg:#0c0c0d;--bg2:#141416;--bg3:#1d1d1f;--text:#e6e6e7;--muted:#5a5a5e;--accent:#fafafa;--msg-bg:#181819;--msg-mine:#2a2a2c;--border:#26262a;--radius:8px}
.theme-graphite .vg-msg{border-color:transparent}
.theme-graphite .vg-mwrap.mine .vg-msg{background:#262628}
.theme-graphite .vg-btn.primary{background:#fafafa;color:#0a0a0a}
.theme-graphite .vg-iconbtn{color:#888}
.theme-light .vg-mwrap.mine .vg-msg{color:#1c1e21}
.theme-black{--bg:#000;--bg2:#0a0a0a;--bg3:#141414;--text:#e4e4e4;--muted:#777;--accent:#3b82f6;--msg-bg:#111;--msg-mine:#1e3a5f;--border:#1a1a1a}
.theme-blue{--bg:#0b1628;--bg2:#111d32;--bg3:#182743;--text:#dce7f5;--muted:#7d95b5;--accent:#4a9eff;--msg-bg:#182743;--msg-mine:#1d4199;--border:#1e3050}
.theme-mono{--bg:#0c0c0c;--bg2:#151515;--bg3:#1e1e1e;--text:#e8e8e8;--muted:#888;--accent:#e8e8e8;--msg-bg:#191919;--msg-mine:#2a2a2a;--border:#242424}
.theme-mono .vg-mwrap.mine .vg-msg{color:#fff}
.theme-nord{--bg:#2e3440;--bg2:#3b4252;--bg3:#434c5e;--text:#eceff4;--muted:#9aa5b8;--accent:#88c0d0;--msg-bg:#3b4252;--msg-mine:#5e81ac;--border:#434c5e}
.theme-rose{--bg:#fdf2f6;--bg2:#fff;--bg3:#fce7ef;--text:#3b2730;--muted:#9c7a86;--accent:#e84d8a;--msg-bg:#fff;--msg-mine:#ffd9e7;--border:#f3d4e0}
.theme-rose .vg-mwrap.mine .vg-msg{color:#3b2730}
.theme-forest{--bg:#0f1a13;--bg2:#16241b;--bg3:#1d2f24;--text:#dceadf;--muted:#7fa088;--accent:#46b06a;--msg-bg:#1d2f24;--msg-mine:#2e6b41;--border:#244030}
*{box-sizing:border-box;margin:0}body{margin:0;background:var(--bg);font-family:Inter,ui-sans-serif,system-ui,-apple-system,"Segoe UI",Roboto,sans-serif}
.hidden{display:none}
.vg-app{color:var(--text);min-height:100vh}
.vg-muted{color:var(--muted)}
.auth-root{min-height:100vh;display:grid;place-items:center;position:relative;overflow:hidden}
.auth-bg{position:absolute;inset:0;background:radial-gradient(800px 400px at 60% -5%,rgba(59,130,246,.12),transparent),radial-gradient(600px 400px at -5% 100%,rgba(99,102,241,.08),transparent),var(--bg)}
.auth-card{position:relative;z-index:1;width:380px;max-width:92vw;background:var(--bg2);border:1px solid var(--border);border-radius:20px;padding:32px 28px;box-shadow:0 20px 60px rgba(0,0,0,.4)}
.auth-logo{width:52px;height:52px;border-radius:14px;display:grid;place-items:center;background:linear-gradient(135deg,var(--accent),var(--accent2));font-weight:800;color:#fff;font-size:18px;margin-bottom:10px}
.auth-title{font-size:24px;font-weight:700;margin-bottom:4px}
.auth-sub{color:var(--muted);font-size:14px;margin-bottom:16px}
.auth-form{display:grid;gap:10px}
.auth-err{color:#f87171;font-size:13px}
.auth-ok{color:#34d399;font-size:13px;line-height:1.5}
.auth-forgot{margin-top:10px;text-align:center}
.auth-forgot button{background:none;border:none;color:var(--muted);cursor:pointer;font-size:13px;text-decoration:underline}
.auth-forgot button:hover{color:var(--accent)}
.auth-switch{margin-top:12px;color:var(--muted);font-size:13px}
.auth-switch button{background:none;border:none;color:var(--accent);cursor:pointer}
.auth-submit{height:44px;display:grid;place-items:center}
.vg-spinner{width:20px;height:20px;border:2.5px solid rgba(255,255,255,.3);border-top-color:#fff;border-radius:50%;animation:spin .7s linear infinite;display:inline-block}
@keyframes spin{to{transform:rotate(360deg)}}
.vg-fadein{animation:fadeIn .2s ease}
@keyframes fadeIn{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:none}}
.vg-loader{font-size:22px;font-weight:700;color:var(--accent);animation:pulse 1.2s ease infinite}
.vg-loader-mini{width:18px;height:18px;border:2px solid #333;border-top-color:#888;border-radius:50%;animation:spin .7s linear infinite}
@keyframes pulse{0%,100%{opacity:.4}50%{opacity:1}}
.vg-layout{display:grid;grid-template-columns:360px 1fr;height:100vh}
.vg-side{background:var(--bg2);border-right:1px solid var(--border);display:flex;flex-direction:column;min-width:0}
.vg-side-top{padding:12px}
.vg-side-search{display:flex;align-items:center;gap:8px;background:var(--bg3);border:1px solid var(--border);border-radius:12px;padding:0 12px;color:var(--muted)}
.vg-side-search input{flex:1;background:none;border:none;color:var(--text);padding:10px 0;outline:none;font-size:14px}
.vg-folders{display:flex;gap:4px;padding:0 10px 8px;flex-wrap:wrap;align-items:center}
.vg-folders button{background:none;border:none;color:var(--muted);font-size:12.5px;padding:5px 10px;border-radius:999px;cursor:pointer;transition:.12s}
.vg-folders button.on{background:var(--bg3);color:var(--text)}
.vg-folders button:hover{color:var(--text)}
.vg-folder-add{display:grid;place-items:center;padding:5px!important}
.vg-chatlist{flex:1;overflow:auto;padding:4px 6px}
.vg-chatrow{display:grid;grid-template-columns:46px 1fr auto;gap:10px;padding:8px 10px;border-radius:12px;cursor:pointer;position:relative;transition:.1s}
.vg-chatrow:hover{background:rgba(255,255,255,.03)}
.theme-light .vg-chatrow:hover{background:rgba(0,0,0,.03)}
.vg-chatrow.on{background:rgba(59,130,246,.12)}
.vg-chatrow-mid{min-width:0}
.vg-chatrow-title{font-weight:600;font-size:14.5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.vg-chatrow-sub{color:var(--muted);font-size:12.5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.vg-chatrow-r{text-align:right}
.vg-chatrow-time{font-size:11.5px;color:var(--muted)}
.vg-chatrow-cnt{font-size:10.5px;color:var(--accent);display:block}
.vg-un{color:var(--muted);font-weight:500;font-size:12px}
.vg-empty{color:var(--muted);text-align:center;padding:20px}
.vg-side-foot{padding:10px 12px;border-top:1px solid var(--border)}
.vg-userline{display:flex;gap:10px;align-items:center;margin-bottom:8px}
.vg-userline-n{font-weight:650;font-size:14px}
.vg-side-actions{display:flex;gap:6px;flex-wrap:wrap}
.vg-main{position:relative;background:var(--bg);display:flex;flex-direction:column;min-width:0}
.vg-main-empty{display:flex;flex-direction:column;align-items:center;justify-content:center;height:100%;color:var(--muted);gap:12px;opacity:.5}
.vg-wall{position:absolute;inset:0;pointer-events:none;opacity:.15}
div.vg-wall{background-size:cover;background-position:center}
video.vg-wall{width:100%;height:100%;object-fit:cover;opacity:.2}
.vg-chatwrap{display:flex;flex-direction:column;height:100vh;position:relative;z-index:1}
.vg-ch-head{height:56px;display:flex;align-items:center;gap:10px;padding:0 12px;border-bottom:1px solid var(--border);background:rgba(0,0,0,.04);backdrop-filter:blur(8px);flex-shrink:0}
.theme-light .vg-ch-head{background:rgba(255,255,255,.7)}
.vg-ch-info{flex:1;min-width:0}
.vg-ch-title{font-weight:700;font-size:15px}
.vg-ch-sub{color:var(--muted);font-size:12px}
.vg-ch-actions{display:flex;gap:4px;align-items:center}
.vg-call-btn{color:var(--accent)}
.vg-call-btn:hover{background:rgba(59,130,246,.12)}
.vg-members{background:var(--bg2);border-bottom:1px solid var(--border);padding:8px 12px;max-height:240px;overflow:auto}
.vg-members-h{font-weight:650;margin-bottom:6px;font-size:14px;display:flex;align-items:center}
.vg-mem-row{display:flex;gap:8px;align-items:center;padding:4px 0}
.vg-zego-wrap{position:absolute;inset:0;z-index:30;background:var(--bg);display:flex;flex-direction:column}
.vg-zego-head{display:flex;justify-content:space-between;align-items:center;padding:10px 14px;border-bottom:1px solid var(--border);font-weight:600}
.vg-zego-container{flex:1;min-height:0}
.vg-msgs{flex:1;overflow:auto;padding:16px 14px}
.vg-date-sep{text-align:center;color:var(--muted);font-size:12px;margin:12px 0}
.vg-mwrap{display:flex;margin:4px 0;animation:msgIn .14s ease}
.vg-mwrap.mine{justify-content:flex-end}
@keyframes msgIn{from{opacity:0;transform:translateY(3px)}to{opacity:1;transform:none}}
.vg-msg{max-width:580px;background:var(--msg-bg);border:1px solid var(--border);padding:8px 12px 6px;border-radius:14px;position:relative;box-shadow:0 1px 0 rgba(0,0,0,.08)}
.vg-mwrap.mine .vg-msg{background:var(--msg-mine);border-color:transparent;color:#e8f0ff}
.vg-msg-author{font-size:12px;font-weight:700;color:var(--accent);margin-bottom:2px}
.vg-msg-text{font-size:14.5px;line-height:1.45;word-wrap:break-word}
.vg-msg-text code{background:rgba(0,0,0,.2);padding:1px 5px;border-radius:5px;font-family:ui-monospace,monospace;font-size:13px}
.vg-code{background:rgba(0,0,0,.22);border-radius:8px;padding:8px;overflow:auto;font-family:ui-monospace,monospace;font-size:13px}
.vg-spoiler{background:var(--bg3);color:transparent;border-radius:4px;cursor:pointer;transition:.12s}
.vg-spoiler.open{color:inherit;background:rgba(255,255,255,.06)}
.vg-msg-reply{font-size:12px;color:var(--muted);border-left:2px solid var(--accent);padding-left:8px;margin-bottom:4px;display:flex;gap:4px;align-items:center}
.vg-msg-meta{font-size:11px;color:rgba(255,255,255,.5);text-align:right;margin-top:3px}
.vg-mwrap:not(.mine) .vg-msg-meta{color:var(--muted)}
.vg-msg-text a{color:#60a5fa}
.vg-msg-text mark{background:#fbbf24;color:#000;padding:1px 2px;border-radius:3px}
.vg-reactions{display:flex;gap:5px;margin-top:5px;flex-wrap:wrap}
.vg-rpill{display:inline-flex;align-items:center;gap:4px;background:rgba(255,255,255,.05);border:1px solid var(--border);border-radius:999px;padding:2px 7px;font-size:12px;cursor:pointer;transition:.12s;animation:pop .15s ease}
.vg-rpill:hover{background:rgba(59,130,246,.15)}
.vg-rpill.mine{background:rgba(59,130,246,.2);border-color:rgba(59,130,246,.4)}
@keyframes pop{from{transform:scale(.8);opacity:0}to{transform:scale(1);opacity:1}}
.vg-ctx{position:fixed;z-index:100;background:var(--bg2);border:1px solid var(--border);border-radius:14px;padding:6px;min-width:210px;box-shadow:0 16px 48px rgba(0,0,0,.5);animation:pop .12s ease}
.vg-ctx-item{display:flex;align-items:center;gap:8px;width:100%;background:none;border:none;color:var(--text);padding:8px 10px;border-radius:9px;cursor:pointer;font-size:13.5px;text-align:left;transition:.1s}
.vg-ctx-item:hover{background:var(--bg3)}
.vg-ctx-item.danger{color:#f87171}
.vg-ctx-divider{height:1px;background:var(--border);margin:5px 4px}
.vg-ctx-reactions{display:flex;gap:2px;padding:4px;background:var(--bg3);border-radius:999px;margin-bottom:4px}
.vg-ctx-react{background:none;border:none;cursor:pointer;padding:4px;border-radius:8px;display:grid;place-items:center;transition:.12s}
.vg-ctx-react:hover{background:var(--bg);transform:scale(1.25)}
.vg-ctx-react.plus{color:var(--muted)}
.vg-ctx-reactions-all{display:grid;grid-template-columns:repeat(6,1fr);gap:2px;padding:6px;background:var(--bg3);border-radius:12px;margin-bottom:4px;animation:pop .12s ease}
.vg-ctx-sub{border-bottom:1px solid var(--border);margin-bottom:4px;padding-bottom:4px}
.vg-composer{display:flex;align-items:center;gap:6px;padding:8px 10px;border-top:1px solid var(--border);background:var(--bg2);flex-shrink:0}
.vg-composer-in-wrap{flex:1;min-width:60px;display:flex}
.vg-composer-in{flex:1;background:var(--bg3);border:1px solid var(--border);color:var(--text);border-radius:12px;padding:10px 12px;outline:none;font-size:14px;min-width:60px;max-height:120px;overflow-y:auto;line-height:1.4;white-space:pre-wrap;word-break:break-word}
.vg-composer-in:empty:before{content:attr(data-ph);color:var(--muted);pointer-events:none}
.vg-ae-in{width:20px;height:20px;vertical-align:-4px;display:inline-block}
.vg-composer-in:focus{border-color:var(--accent)}
.vg-sendbtn{background:var(--accent);color:#fff;border:none;border-radius:12px;padding:10px 14px;cursor:pointer;display:grid;place-items:center}
.vg-sendbtn:hover{filter:brightness(1.1)}
.vg-replybar{display:flex;justify-content:space-between;align-items:center;padding:6px 12px;border-top:1px solid var(--border);background:var(--bg2);font-size:13px;color:var(--muted)}
.vg-replybar span{display:flex;align-items:center;gap:5px}
.vg-attach-pill{background:var(--bg3);border:1px solid var(--border);padding:4px 10px;border-radius:999px;font-size:12px;display:flex;gap:4px;align-items:center;max-width:140px;overflow:hidden}
.vg-imgprev{max-width:340px;max-height:340px;border-radius:10px;display:block}
.vg-vidprev{max-width:380px;max-height:280px;border-radius:10px;display:block}
.vg-filebox{background:rgba(0,0,0,.12);border:1px solid var(--border);border-radius:10px;padding:10px;font-size:13px;display:flex;gap:6px;align-items:center;flex-wrap:wrap}
.vg-filebox a{color:var(--accent)}
.vg-docbox{background:rgba(0,0,0,.12);border:1px solid var(--border);border-radius:12px;padding:10px;font-size:13px;max-width:440px}
.vg-docbox.office{display:flex;gap:12px;align-items:center}
.vg-docbox-head{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-bottom:4px}
.vg-office-icon{width:46px;height:46px;border-radius:10px;background:var(--bg3);display:grid;place-items:center;color:var(--accent);flex-shrink:0}
.vg-pdfframe{width:100%;height:380px;border:none;border-radius:8px;background:#fff;margin-top:6px}
.vg-textprev{max-height:200px;overflow:auto;font-size:12px;white-space:pre-wrap;font-family:ui-monospace,monospace;background:rgba(0,0,0,.15);border-radius:8px;padding:8px;margin:4px 0}
.vg-csv-wrap{overflow:auto;max-height:220px;margin-top:4px}
.vg-csv{border-collapse:collapse;font-size:12px;width:100%}
.vg-csv th,.vg-csv td{border:1px solid var(--border);padding:4px 8px;text-align:left;white-space:nowrap}
.vg-csv th{background:var(--bg3);font-weight:600}
/* TG-стиль: синий (исходящее) / тёмно-синий (свои) пузырь голосового */
.vg-tg-voice{display:flex;align-items:center;gap:8px;background:var(--accent);color:#fff;border-radius:18px;padding:6px 10px;min-width:240px;max-width:340px}
.theme-light .vg-mwrap.mine .vg-tg-voice{background:var(--accent);color:#fff}
.vg-mwrap:not(.mine) .vg-tg-voice{background:#2a2f3a;color:#fff}
.vg-tg-voice-play{width:38px;height:38px;border-radius:50%;background:rgba(255,255,255,.2);border:none;display:grid;place-items:center;cursor:pointer;color:#fff;flex-shrink:0}
.vg-tg-voice-mid{flex:1;min-width:0}
.vg-tg-voice-wave{display:flex;align-items:center;gap:1.5px;height:28px;cursor:pointer;margin-bottom:2px}
.vg-tg-voice-bar{flex:1;min-width:2px;border-radius:1px;transition:background .1s}
.vg-tg-voice-meta{display:flex;gap:10px;font-size:11px;opacity:.85;align-items:center;line-height:1}
.vg-tg-voice-name{font-size:12px;opacity:.95}
.vg-tg-voice-time{opacity:.7;font-variant-numeric:tabular-nums}
.vg-tg-voice-dl{background:none;border:none;color:#fff;cursor:pointer;padding:6px;border-radius:8px;opacity:.7;align-self:center}
.vg-tg-voice-dl:hover{background:rgba(255,255,255,.15);opacity:1}
/* старый стиль оставим для аудио-файлов (музыка) */
.vg-audio-player{display:flex;align-items:center;gap:8px;background:rgba(0,0,0,.12);border:1px solid var(--border);border-radius:12px;padding:8px 12px;min-width:230px}
.vg-ap-btn{background:none;border:none;color:var(--text);cursor:pointer;padding:2px;display:grid;place-items:center}
.vg-ap-track{flex:1;height:4px;background:var(--bg3);border-radius:99px;cursor:pointer}
.vg-ap-fill{height:100%;background:var(--accent);border-radius:99px;transition:width .1s}
.vg-ap-time{font-size:11px;color:var(--muted);white-space:nowrap}
.vg-ap-name{font-size:11px;color:var(--muted)}
.vg-gif-picker{background:var(--bg2);border:1px solid var(--border);border-radius:14px;position:absolute;bottom:64px;left:10px;right:10px;max-height:320px;overflow:auto;z-index:10;box-shadow:0 8px 32px rgba(0,0,0,.4)}
.vg-gif-head{display:flex;gap:6px;padding:8px;position:sticky;top:0;background:var(--bg2);z-index:1}
.vg-gif-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(110px,1fr));gap:4px;padding:0 8px 8px}
.vg-gif-grid img{width:100%;height:86px;object-fit:cover;border-radius:8px;cursor:pointer;transition:.1s}
.vg-gif-grid img:hover{opacity:.8;transform:scale(1.03)}
.vg-tag{display:inline-flex;align-items:center;gap:4px;background:var(--bg);border:1px solid var(--border);color:var(--muted);border-radius:999px;padding:3px 9px;font-size:11.5px}
.vg-tag.warn{color:#fbbf24;border-color:rgba(251,191,36,.3)}
.vg-mod-row{padding:8px;background:var(--bg3);border:1px solid var(--border);border-radius:12px;margin-bottom:6px}
.vg-rule-row{display:flex;align-items:center;gap:8px;padding:6px 8px;background:var(--bg3);border:1px solid var(--border);border-radius:10px}
.vg-input{width:100%;background:var(--bg3);border:1px solid var(--border);color:var(--text);border-radius:12px;padding:10px 12px;outline:none;font-size:14px;margin-bottom:6px}
.vg-input:focus{border-color:var(--accent)}
.vg-input.sm{padding:7px 10px;font-size:13px;margin-bottom:0}
.vg-ch-search{width:120px}
.vg-lbl{display:block;color:var(--muted);font-size:13px;margin:6px 0 3px}
.vg-btn{background:var(--bg3);border:1px solid var(--border);color:var(--text);border-radius:12px;padding:10px 14px;cursor:pointer;font-weight:600;transition:.12s;font-size:14px}
.vg-btn.primary{background:linear-gradient(135deg,var(--accent),var(--accent2));border:none;color:#fff}
.vg-btn:hover{filter:brightness(1.06)}
.vg-btn:disabled{opacity:.7;cursor:not-allowed}
.vg-chip{background:var(--bg3);border:1px solid var(--border);color:var(--muted);border-radius:999px;padding:6px 11px;font-size:12px;cursor:pointer;display:inline-flex;gap:4px;align-items:center;transition:.1s}
.vg-chip:hover{color:var(--text);border-color:var(--accent)}
.vg-chip.tiny{padding:3px 7px;font-size:11px}
.vg-chip.danger{color:#f87171}
.vg-chip.accent{color:var(--accent);border-color:rgba(59,130,246,.4)}
.vg-ibtn{background:none;border:none;color:var(--muted);cursor:pointer;padding:6px;border-radius:8px;display:grid;place-items:center;transition:.1s}
.vg-ibtn:hover{background:var(--bg3);color:var(--text)}
.vg-check{display:flex;gap:8px;align-items:center;color:var(--muted);margin:6px 0;font-size:14px}
.vg-check.sm{font-size:12px;margin:2px 0}
.vg-backdrop{position:fixed;inset:0;background:rgba(0,0,0,.5);display:grid;place-items:center;z-index:80}
.vg-modal{background:var(--bg2);border:1px solid var(--border);border-radius:18px;padding:20px;width:720px;max-width:94vw;max-height:85vh;overflow:auto;position:relative;box-shadow:0 24px 80px rgba(0,0,0,.5);animation:pop .14s ease}
.vg-modal-x{position:absolute;right:10px;top:8px;background:none;border:none;color:var(--muted);cursor:pointer;padding:4px}
.vg-modal h2{margin:0 0 12px;font-size:20px;font-weight:700}
.vg-modal h3{margin:6px 0;font-size:15px;font-weight:600}
.vg-tabs{display:flex;gap:6px;margin-bottom:10px;flex-wrap:wrap}
.vg-tabs button{border:none;background:var(--bg3);color:var(--muted);padding:6px 12px;border-radius:999px;cursor:pointer;font-size:13px}
.vg-tabs button.on{color:var(--text);outline:2px solid rgba(59,130,246,.35)}
.vg-theme-pick{display:flex;gap:6px;flex-wrap:wrap}
.vg-tdot{border:1px solid var(--border);background:var(--bg3);color:var(--text);padding:6px 10px;border-radius:999px;cursor:pointer;font-size:12.5px}
.vg-tdot.on{outline:2px solid var(--accent)}
.vg-tdot.t-light{background:#f5f7f9;color:#1c1e21;border-color:#d8dee4}
.vg-tdot.t-dark{background:#161b22;color:#e6e8eb}
.vg-tdot.t-black{background:#000;color:#e4e4e4}
.vg-tdot.t-blue{background:#111d32;color:#dce7f5}
.vg-botrow{display:flex;gap:10px;align-items:center;padding:6px;border-radius:10px;cursor:pointer}
.vg-botrow:hover{background:rgba(255,255,255,.03)}
.vg-toast{position:fixed;left:50%;transform:translateX(-50%);bottom:20px;background:var(--bg3);color:var(--text);border:1px solid var(--border);padding:10px 16px;border-radius:12px;opacity:0;transition:.18s;z-index:120;font-size:14px;pointer-events:none}
.vg-toast.show{opacity:1;bottom:28px}
/* typing */
.vg-typing{color:var(--accent);display:inline-flex;align-items:center;gap:4px}
.vg-typing-dots{display:inline-flex;gap:2px;margin-left:2px}
.vg-typing-dots i{width:3px;height:3px;border-radius:50%;background:var(--accent);animation:typeb 1s infinite}
.vg-typing-dots i:nth-child(2){animation-delay:.2s}
.vg-typing-dots i:nth-child(3){animation-delay:.4s}
@keyframes typeb{0%,60%,100%{opacity:.3;transform:translateY(0)}30%{opacity:1;transform:translateY(-2px)}}
/* type badge */
.vg-type-badge{font-size:9px;font-weight:700;letter-spacing:.5px;color:var(--accent);background:rgba(59,130,246,.12);padding:1px 5px;border-radius:5px;margin-right:4px;vertical-align:middle}
/* pinned bar */
.vg-pinned-bar{display:flex;align-items:center;gap:8px;padding:6px 12px;background:var(--bg2);border-bottom:1px solid var(--border);color:var(--accent)}
.vg-pinned-list{flex:1;min-width:0;border-left:2px solid var(--accent);padding-left:8px}
.vg-pinned-item{cursor:pointer;min-width:0}
.vg-pinned-count{font-size:11px;background:var(--bg3);border-radius:99px;padding:1px 7px;color:var(--muted)}
/* checks */
.vg-checks{display:inline-flex;align-items:center;color:#4ea3ff;margin-left:3px;vertical-align:middle}
/* mention */
.vg-mention{color:var(--accent);font-weight:600;cursor:pointer}
/* sticker */
.vg-sticker-panel{position:absolute;bottom:64px;left:10px;right:10px;background:var(--bg2);border:1px solid var(--border);border-radius:14px;padding:10px;display:flex;flex-wrap:wrap;gap:4px;z-index:10;max-height:220px;overflow:auto;box-shadow:0 8px 32px rgba(0,0,0,.4)}
.vg-sticker-btn{font-size:28px;background:none;border:none;cursor:pointer;padding:4px;border-radius:8px;transition:.1s}
.vg-sticker-btn:hover{background:var(--bg3);transform:scale(1.2)}
.vg-sticker-msg{display:flex;flex-direction:column}
.vg-sticker-big{font-size:64px;line-height:1}
.vg-sticker-img{width:128px;height:128px;object-fit:contain}
.vg-mic-btn:hover{color:var(--accent)}
/* unread / draft / pin */
.vg-unread{background:var(--accent);color:#fff;border-radius:999px;min-width:18px;height:18px;padding:0 5px;font-size:11px;font-weight:700;display:inline-flex;align-items:center;justify-content:center}
.vg-draft{color:#f87171;font-style:italic}
.vg-pin-ic{display:inline-flex;color:var(--muted);margin-right:3px;vertical-align:middle}
/* emoji picker */
.vg-emoji-pop{position:absolute;bottom:64px;left:10px;z-index:20;box-shadow:0 8px 32px rgba(0,0,0,.4);border-radius:12px;overflow:hidden}
.vg-emoji-close{position:absolute;top:6px;right:6px;z-index:21;background:var(--bg2)}
/* media gallery */
.vg-media-pane{background:var(--bg2);border-bottom:1px solid var(--border);max-height:300px;overflow:auto;padding:8px}
.vg-media-head{display:flex;gap:6px;align-items:center;margin-bottom:8px}
.vg-media-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(90px,1fr));gap:4px}
.vg-media-thumb{width:100%;height:90px;object-fit:cover;border-radius:8px;cursor:pointer}
.vg-media-files{display:flex;flex-direction:column;gap:6px}
.vg-media-file{display:flex;align-items:center;gap:8px;padding:6px;border:1px solid var(--border);border-radius:8px}
/* catalog */
.vg-cat-row{display:flex;gap:10px;align-items:center;padding:8px;border-radius:12px}
.vg-cat-row:hover{background:rgba(255,255,255,.03)}
/* stats */
.vg-stat-card{flex:1;background:var(--bg3);border:1px solid var(--border);border-radius:12px;padding:14px;text-align:center}
.vg-stat-num{font-size:26px;font-weight:700;color:var(--accent)}
/* extra theme dots */
.vg-tdot.t-mono{background:#151515;color:#e8e8e8}
.vg-tdot.t-nord{background:#3b4252;color:#eceff4}
.vg-tdot.t-rose{background:#fce7ef;color:#3b2730;border-color:#f3d4e0}
.vg-tdot.t-forest{background:#16241b;color:#dceadf}
/* emoji-mart in dark */
em-emoji-picker{--rgb-background:transparent;height:340px}
/* scroll down button */
.vg-scroll-down{position:absolute;right:18px;bottom:80px;width:42px;height:42px;border-radius:50%;background:var(--bg2);border:1px solid var(--border);color:var(--muted);cursor:pointer;display:grid;place-items:center;transform:rotate(-90deg);box-shadow:0 4px 16px rgba(0,0,0,.3);z-index:5;transition:.15s}
.vg-scroll-down:hover{color:var(--accent);transform:rotate(-90deg) scale(1.08)}
.vg-prem-star{display:inline-flex;filter:drop-shadow(0 0 3px rgba(245,181,10,.5))}
.vg-transcript{margin-top:4px;padding:8px 10px;background:rgba(0,0,0,.12);border-left:2px solid var(--accent);border-radius:8px;font-size:13px;line-height:1.45;font-style:italic}
.vg-prem-banner{background:linear-gradient(135deg,rgba(245,181,10,.15),rgba(168,85,247,.15));border:1px solid rgba(245,181,10,.4);border-radius:14px;padding:14px;margin-bottom:10px}
.vg-prem-title{font-weight:700;display:flex;align-items:center;gap:6px;color:#f5b50a}
/* apple emoji в тексте */
.vg-ae{width:1.25em;height:1.25em;vertical-align:-0.25em;display:inline-block;margin:0 .5px}
/* свой эмодзи-пикер */
.vg-emoji-pop2{position:absolute;bottom:64px;left:10px;width:340px;max-width:92vw;background:var(--bg2);border:1px solid var(--border);border-radius:14px;z-index:20;box-shadow:0 8px 32px rgba(0,0,0,.4);overflow:hidden}
.vg-emoji-tabs{display:flex;gap:2px;padding:6px;border-bottom:1px solid var(--border);align-items:center}
.vg-emoji-tabs button{background:none;border:none;cursor:pointer;padding:5px;border-radius:8px;display:grid;place-items:center;opacity:.55;transition:.1s}
.vg-emoji-tabs button.on{opacity:1;background:var(--bg3)}
.vg-emoji-tabs button:hover{opacity:1}
.vg-emoji-x{margin-left:auto;color:var(--muted)}
.vg-emoji-grid{display:grid;grid-template-columns:repeat(8,1fr);gap:2px;padding:8px;max-height:240px;overflow:auto}
.vg-emoji-cell{background:none;border:none;cursor:pointer;padding:4px;border-radius:8px;display:grid;place-items:center;transition:.1s}
.vg-emoji-cell:hover{background:var(--bg3);transform:scale(1.2)}
.vg-emoji-cat-name{padding:4px 10px 8px;font-size:11px;color:var(--muted)}
.vg-prem-react-row{width:100%;font-size:10px;color:#f5b50a;display:flex;align-items:center;gap:3px;padding:4px 2px 2px;grid-column:1/-1}
.vg-ctx-react.locked{opacity:.45}
.vg-ctx-react.locked:hover{opacity:.7}
.vg-profile-cover{height:100px;background-size:cover;background-position:center;border-radius:14px 14px 0 0;margin:-20px -20px 0}
.vg-prem-lock{font-size:10px;color:#f5b50a;display:inline-flex;align-items:center;gap:2px}
.vg-btn:disabled,.vg-chip:disabled{opacity:.5;cursor:not-allowed}
/* Stories */
.vg-stories-bar{display:flex;gap:10px;padding:8px 6px 4px;overflow-x:auto;border-bottom:1px solid var(--border);margin:0 -6px 6px;scrollbar-width:none}
.vg-stories-bar::-webkit-scrollbar{display:none}
.vg-story-item{flex-shrink:0;display:flex;flex-direction:column;align-items:center;gap:4px;width:62px;cursor:pointer}
.vg-story-item .vg-avatar{cursor:pointer}
.vg-story-add{position:absolute;margin-top:38px;margin-left:38px;width:18px;height:18px;border-radius:50%;background:var(--accent);color:#fff;display:grid;place-items:center;font-size:13px;font-weight:700;border:2px solid var(--bg2);box-sizing:content-box}
.vg-story-item{position:relative}
.vg-story-ring{padding:2px;border-radius:50%;background:linear-gradient(135deg,var(--accent),#a855f7);display:grid;place-items:center}
.vg-story-ring .vg-avatar{border:2px solid var(--bg2)}
.vg-story-name{font-size:11px;text-align:center;max-width:62px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.vg-story-viewer{position:fixed;inset:0;background:rgba(0,0,0,.92);z-index:200;display:flex;align-items:center;justify-content:center}
.vg-story-img{max-width:90vw;max-height:80vh;border-radius:12px;box-shadow:0 10px 60px rgba(0,0,0,.6)}
.vg-story-progress{position:absolute;top:14px;left:14px;right:14px;display:flex;gap:4px}
.vg-story-prog-bar{flex:1;height:3px;background:rgba(255,255,255,.3);border-radius:2px}
.vg-story-prog-bar{animation:storyProg 5s linear forwards}
@keyframes storyProg{from{background:var(--accent)}to{background:rgba(255,255,255,.2)}}
.vg-story-viewer-text{position:absolute;bottom:80px;left:30px;right:30px;color:#fff;font-size:16px;text-align:center}
.vg-story-close,.vg-story-next{position:absolute;background:rgba(255,255,255,.15);color:#fff;border:none;padding:8px 14px;border-radius:99px;cursor:pointer;backdrop-filter:blur(8px)}
.vg-story-close{top:50px;right:20px;font-size:18px}
.vg-story-next{bottom:30px;left:50%;transform:translateX(-50%)}
/* plus menu */
.vg-plus-menu{position:absolute;bottom:64px;left:10px;background:var(--bg2);border:1px solid var(--border);border-radius:14px;padding:6px;z-index:10;box-shadow:0 8px 32px rgba(0,0,0,.4);min-width:200px}
.vg-plus-menu button{display:flex;align-items:center;gap:10px;width:100%;background:none;border:none;color:var(--text);padding:9px 10px;border-radius:9px;cursor:pointer;font-size:14px;text-align:left}
.vg-plus-menu button:hover{background:var(--bg3)}
/* voice recorder */
.vg-voicerec{display:flex;align-items:center;gap:10px;padding:8px 12px;border-top:1px solid var(--border);background:var(--bg2)}
.vg-voicerec-mid{flex:1;display:flex;align-items:center;gap:8px;color:var(--text);font-size:14px}
.vg-rec-dot{width:10px;height:10px;border-radius:50%;background:#ef4444;animation:pulse 1s infinite}
.vg-ibtn.danger{color:#f87171}
/* vcircle */
.vg-vcircle{width:200px;height:200px;border-radius:50%;object-fit:cover;background:#000}
/* poll */
.vg-poll{min-width:240px}
.vg-poll-q{font-weight:600;font-size:14px;margin-bottom:8px;display:flex;align-items:center;gap:6px}
.vg-poll-opt{position:relative;padding:8px 10px;border:1px solid var(--border);border-radius:10px;margin-bottom:5px;cursor:pointer;overflow:hidden;display:flex;align-items:center;font-size:13px}
.vg-poll-opt:hover{border-color:var(--accent)}
.vg-poll-opt.voted{border-color:var(--accent)}
.vg-poll-bar{position:absolute;left:0;top:0;bottom:0;background:rgba(59,130,246,.18);z-index:0;transition:width .3s}
.vg-poll-label{position:relative;z-index:1;flex:1}
.vg-poll-pct{position:relative;z-index:1;font-weight:600;color:var(--accent)}
/* react picker / link / profile */
.vg-react-picker{display:flex;flex-wrap:wrap;gap:4px;margin-bottom:8px}
.vg-react-pick{background:var(--bg3);border:1px solid var(--border);border-radius:8px;padding:5px;cursor:pointer;display:grid;place-items:center}
.vg-react-pick.on{outline:2px solid var(--accent);background:rgba(59,130,246,.15)}
.vg-link-row{display:flex;align-items:center;gap:8px;background:var(--bg3);border:1px solid var(--border);border-radius:10px;padding:8px 10px;margin-bottom:10px;color:var(--accent)}
.vg-profile{text-align:center}
.vg-profile-head{display:flex;flex-direction:column;align-items:center;padding:10px 0}
.vg-profile-bio{background:var(--bg3);border:1px solid var(--border);border-radius:12px;padding:12px;margin-top:10px;text-align:left;font-size:14px}
.mobile-show{display:none!important}
@media(max-width:768px){
  .vg-layout{grid-template-columns:1fr}
  .vg-side.mobile-hide{display:none}
  .vg-main.mobile-hide{display:none}
  .mobile-show{display:grid!important}
  .vg-msg{max-width:85vw}
  .vg-ch-search{display:none}
}
`;

if(typeof document!=='undefined'&&!document.getElementById('vg-css')){
  const s=document.createElement('style');s.id='vg-css';s.textContent=CSS;
  document.head.appendChild(s);
  document.title='VibeGram Messenger';
  const acc=localStorage.getItem('vg_accent'); if(acc) document.documentElement.style.setProperty('--accent',acc);
}
