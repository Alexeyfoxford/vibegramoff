/* @ts-nocheck */
/**
 * VibeGram — Firebase backend
 * ───────────────────────────
 * Безопасность:
 *  • Пароли ТОЛЬКО в Firebase Auth (Email/Password). В коде и Firestore их нет.
 *  • isAdmin/isOwner код никогда не выдаёт — только вручную в консоли.
 *  • Удаление аккаунта — с реаутентификацией.
 *  • Экономика/подарки удалены полностью.
 *  • Одноразовые токены админа в Firestore admin_tokens/{token}
 *    (создаются вручную в консоли, живут 24ч, удаляются после использования)
 */
import { initializeApp } from 'firebase/app';
import {
  getFirestore, collection, addDoc, setDoc, getDoc, getDocs, onSnapshot,
  query, orderBy, where, doc, updateDoc, deleteDoc, serverTimestamp,
  arrayUnion, arrayRemove, increment, limit,
} from 'firebase/firestore';
import {
  getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword,
  updatePassword, reauthenticateWithCredential, EmailAuthProvider,
  onAuthStateChanged, signOut, deleteUser,
  sendPasswordResetEmail, sendEmailVerification, updateEmail, verifyBeforeUpdateEmail,
} from 'firebase/auth';
import { getStorage, ref as sRef, uploadBytes, getDownloadURL } from 'firebase/storage';

const firebaseConfig = {
  apiKey: 'AIzaSyD54L7jmjcXhBWeeNWkZI2mTSQrwap6IG8',
  authDomain: 'vibegram-51062.firebaseapp.com',
  projectId: 'vibegram-51062',
  storageBucket: 'vibegram-51062.firebasestorage.app',
  messagingSenderId: '985853655083',
  appId: '1:985853655083:web:ca7e5b8407a857f051926e',
};

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
export const auth = getAuth(app);
export const storage = getStorage(app);

/* ═══════ Загрузка файла в Firebase Storage (без лимита 1MB) ═══════
   Требует включить Storage в Firebase Console → Storage → Get started. */
export async function fbUploadFile(file: File, username: string, onProgress?: (p: number) => void): Promise<string> {
  const path = `uploads/${username}/${Date.now()}_${file.name.replace(/[^\w.\-]/g, '_')}`;
  const ref = sRef(storage, path);
  onProgress?.(30);
  await uploadBytes(ref, file);
  onProgress?.(80);
  const url = await getDownloadURL(ref);
  onProgress?.(100);
  return url;
}

export {
  collection, addDoc, setDoc, getDoc, getDocs, onSnapshot, query, orderBy,
  where, doc, updateDoc, deleteDoc, serverTimestamp, arrayUnion, arrayRemove,
  increment, limit, onAuthStateChanged, signOut,
};

const unToEmail = (un: string) => `${un.toLowerCase().trim()}@users.vibegram.app`;

/* По username находим реальный email (для входа и сброса пароля) */
async function resolveEmail(username: string): Promise<string> {
  const snap = await getDoc(doc(db, 'users', username));
  const real = snap.exists() ? snap.data().email : null;
  return real || unToEmail(username); // legacy-аккаунты без email
}

/* ═══════ Регистрация (с реальным email) ═══════ */
export async function fbRegister(username: string, name: string, password: string, email?: string) {
  username = username.toLowerCase().trim();
  if (!/^[a-z0-9_]{3,20}$/.test(username)) throw new Error('Юзернейм: 3-20 символов, a-z 0-9 _');
  if (password.length < 8) throw new Error('Пароль: минимум 8 символов');
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new Error('Введите корректный email');
  email = email.toLowerCase().trim();

  const ref = doc(db, 'users', username);
  const snap = await getDoc(ref);
  if (snap.exists()) throw new Error('Юзернейм занят');

  let cred;
  try {
    cred = await createUserWithEmailAndPassword(auth, email, password);
  } catch (e: any) {
    if (e.code === 'auth/email-already-in-use') throw new Error('Этот email уже используется');
    if (e.code === 'auth/weak-password') throw new Error('Слишком простой пароль');
    if (e.code === 'auth/invalid-email') throw new Error('Некорректный email');
    if (e.code === 'auth/configuration-not-found' || e.code === 'auth/operation-not-allowed')
      throw new Error('В Firebase Console: Authentication → Get started → Email/Password → Enable');
    throw new Error('Ошибка регистрации: ' + (e.code || e.message));
  }

  // отправляем письмо для верификации (Firebase шлёт сам, без своего SMTP)
  try { await sendEmailVerification(cred.user); } catch {}

  const user = {
    username, name: (name || username).slice(0, 40), bio: '', avatar: '',
    uid: cred.user.uid, email,
    isBot: false, isAdmin: false, isOwner: false, emailVerified: false,
    privacy: { dmPolicy: 'all', showLastSeen: true, searchable: true, twoFA: false },
    folders: [], createdAt: Date.now(), lastSeen: Date.now(),
  };
  await setDoc(ref, user);

  await setDoc(doc(db, 'chats', 'saved_' + username), {
    id: 'saved_' + username, type: 'saved', title: 'Избранное', username: '',
    about: '', avatar: '', isPublic: false, ownerId: username,
    members: [username], perms: {}, banned: [], lastText: '', lastAt: Date.now(), createdAt: Date.now(),
  });

  await ensureSystemBot();
  const dmId = await fbCreateDM(username, 'vibegram');
  await fbSendMessage(dmId, 'vibegram', `Привет, ${user.name}! Добро пожаловать в VibeGram.\n\nЭто официальный бот — здесь будут системные уведомления.\n\nСоветы:\n• Настройки → Конфиденциальность — кто может вам писать\n• ПКМ по сообщению — реакции и действия\n• Папки — кнопка «+» рядом с вкладками`);
  return user;
}

/* ═══════ Вход (по username, email берётся из профиля) ═══════ */
export async function fbLogin(username: string, password: string) {
  username = username.toLowerCase().trim();
  const email = await resolveEmail(username);
  try {
    await signInWithEmailAndPassword(auth, email, password);
  } catch (e: any) {
    if (e.code === 'auth/configuration-not-found' || e.code === 'auth/operation-not-allowed')
      throw new Error('В Firebase Console: Authentication → Get started → Email/Password → Enable');
    return null;
  }
  const snap = await getDoc(doc(db, 'users', username));
  if (!snap.exists()) {
    const u = {
      username, name: username, bio: '', avatar: '', uid: auth.currentUser?.uid || '',
      isBot: false, isAdmin: false, isOwner: false,
      privacy: { dmPolicy: 'all', showLastSeen: true, searchable: true },
      folders: [], createdAt: Date.now(), lastSeen: Date.now(),
    };
    await setDoc(doc(db, 'users', username), u);
    return u;
  }
  const u = snap.data();
  if (u.bannedGlobal && (!u.banUntil || u.banUntil > Date.now())) {
    const until = u.banUntil ? ' до ' + new Date(u.banUntil).toLocaleString('ru-RU') : ' навсегда';
    throw new Error('Аккаунт заблокирован' + until + (u.banReason ? '. Причина: ' + u.banReason : ''));
  }
  // синхронизируем статус верификации email
  try { if (auth.currentUser?.emailVerified && !u.emailVerified) { await updateDoc(doc(db, 'users', username), { emailVerified: true }); u.emailVerified = true; } } catch {}
  await updateDoc(doc(db, 'users', username), { lastSeen: Date.now() }).catch(() => {});
  return u;
}

/* ═══════ Забыли пароль — Firebase сам шлёт письмо ═══════ */
export async function fbResetPassword(usernameOrEmail: string) {
  let email = usernameOrEmail.trim().toLowerCase();
  if (!email.includes('@')) {
    email = await resolveEmail(email);
    if (email.endsWith('@users.vibegram.app')) throw new Error('У этого аккаунта нет реального email');
  }
  try {
    await sendPasswordResetEmail(auth, email);
  } catch (e: any) {
    if (e.code === 'auth/user-not-found') throw new Error('Аккаунт с таким email не найден');
    throw new Error('Ошибка: ' + (e.code || e.message));
  }
}

/* ═══════ Повторно отправить письмо верификации ═══════ */
export async function fbResendVerification() {
  if (!auth.currentUser) throw new Error('Войдите заново');
  await sendEmailVerification(auth.currentUser);
}

/* ═══════ Привязка email к старому аккаунту (кто регался до email-функции) ═══════ */
export async function fbAttachEmail(username: string, newEmail: string, currentPassword: string) {
  const u = auth.currentUser;
  if (!u) throw new Error('Войдите заново');
  newEmail = newEmail.trim().toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(newEmail)) throw new Error('Некорректный email');
  // реаутентификация текущим логином
  const profileSnap = await getDoc(doc(db, 'users', username));
  const oldEmail = profileSnap.data()?.email || unToEmail(username);
  try {
    const cred = EmailAuthProvider.credential(oldEmail, currentPassword);
    await reauthenticateWithCredential(u, cred);
  } catch {
    throw new Error('Неверный пароль');
  }
  // меняем email в Auth (с подтверждением через письмо)
  try {
    await verifyBeforeUpdateEmail(u, newEmail);
  } catch (e: any) {
    if (e.code === 'auth/email-already-in-use') throw new Error('Email уже занят');
    if (e.code === 'auth/operation-not-allowed') {
      // запасной путь: прямая смена (требует свежей сессии)
      try { await updateEmail(u, newEmail); } catch { throw new Error('Ошибка смены email'); }
    } else throw new Error('Ошибка: ' + (e.code || e.message));
  }
  await updateDoc(doc(db, 'users', username), { email: newEmail, emailVerified: false });
  try { await sendEmailVerification(auth.currentUser!); } catch {}
}
export function fbIsEmailVerified() { return !!auth.currentUser?.emailVerified; }

/* ═══════ Проверка: забанен ли пользователь прямо сейчас ═══════ */
export function isUserBanned(u: any): boolean {
  if (!u) return false;
  if (!u.bannedGlobal) return false;
  if (u.banUntil && u.banUntil <= Date.now()) return false; // срок истёк
  return true;
}

/* ═══════ Система бана (глобальная, админская) ═══════ */
export async function fbBanGlobal(targetUn: string, reason: string, minutes: number, adminUn: string) {
  const adminSnap = await getDoc(doc(db, 'users', adminUn));
  if (!adminSnap.exists() || !adminSnap.data().isAdmin) throw new Error('Только админ');
  const until = minutes > 0 ? Date.now() + minutes * 60000 : 0;
  await updateDoc(doc(db, 'users', targetUn), {
    bannedGlobal: true, banUntil: until, banReason: reason || '', bannedBy: adminUn, bannedAt: Date.now(),
    lastSeen: -1, // -1 = "был(а) давно" (заблокирован)
  });
  // уведомление забаненному от бота
  try {
    const dmId = 'dm_' + ['vibegram', targetUn].sort().join('__');
    const dmRef = doc(db, 'chats', dmId);
    const dmSnap = await getDoc(dmRef);
    if (!dmSnap.exists()) {
      await setDoc(dmRef, { id: dmId, type: 'dm', title: '', members: ['vibegram', targetUn], perms: {}, banned: [], lastText: '', lastAt: Date.now(), createdAt: Date.now() });
    }
    const txt = minutes > 0
      ? `Вы заблокированы на ${minutes} мин. Причина: ${reason || 'нарушение правил'}.`
      : `Вы заблокированы навсегда. Причина: ${reason || 'нарушение правил'}.`;
    await fbSendMessage(dmId, 'vibegram', txt);
  } catch {}
}
export async function fbUnbanGlobal(targetUn: string, adminUn: string) {
  const adminSnap = await getDoc(doc(db, 'users', adminUn));
  if (!adminSnap.exists() || !adminSnap.data().isAdmin) throw new Error('Только админ');
  await updateDoc(doc(db, 'users', targetUn), { bannedGlobal: false, banUntil: 0, banReason: '' });
}
export async function fbListBanned() {
  const snap = await getDocs(query(collection(db, 'users'), where('bannedGlobal', '==', true)));
  const arr: any[] = []; snap.forEach(d => arr.push(d.data())); return arr;
}
/* Жалобы */
export async function fbReport(reporterUn: string, targetUn: string, reason: string, chatId?: string) {
  await addDoc(collection(db, 'reports'), {
    reporter: reporterUn, target: targetUn, reason: reason || '', chatId: chatId || '',
    status: 'open', createdAt: Date.now(),
  });
}
export async function fbListReports() {
  const snap = await getDocs(query(collection(db, 'reports'), orderBy('createdAt', 'desc'), limit(100)));
  const arr: any[] = []; snap.forEach(d => arr.push({ ...d.data(), id: d.id })); return arr;
}
export async function fbResolveReport(id: string) {
  await updateDoc(doc(db, 'reports', id), { status: 'resolved' });
}

/* ═══════ Авто-модерация: счётчик жалоб → авто-бан + сигнал админам ═══════ */
const BAD_WORDS = [/\bнаркотик/i, /\bпорно/i, /детск\w*\s*порн/i, /\bубью\b/i, /\bтеррор/i];
/* ═══════ End-to-end шифрование (AES-GCM, ключ на обоих собеседников) ═══════
   Текст шифруется на клиенте, в Firestore лежит шифр. Ключ — на устройствах. */
const enc=new TextEncoder(); const dec=new TextDecoder();
async function deriveKey(a:string,b:string){
  const pair=[a,b].sort().join('|');
  const base=await crypto.subtle.importKey('raw',enc.encode('vg:'+pair),{name:'PBKDF2'},false,['deriveKey']);
  return crypto.subtle.deriveKey({name:'PBKDF2',salt:enc.encode('vgsalt2026'),iterations:10000,hash:'SHA-256'},base,{name:'AES-GCM',length:256},false,['encrypt','decrypt']);
}
export async function encText(text:string,userA:string,userB:string):Promise<string>{
  try{
    const key=await deriveKey(userA,userB);
    const iv=crypto.getRandomValues(new Uint8Array(12));
    const ct=await crypto.subtle.encrypt({name:'AES-GCM',iv},key,enc.encode(text));
    const u=new Uint8Array(ct);
    return 'vge:'+btoa(String.fromCharCode(...iv,...u));
  }catch{ return text; }
}
export async function decText(payload:string,userA:string,userB:string):Promise<string>{
  try{
    if(!payload.startsWith('vge:')) return payload;
    const key=await deriveKey(userA,userB);
    const bin=atob(payload.slice(4)); const arr=Uint8Array.from(bin,c=>c.charCodeAt(0));
    const iv=arr.slice(0,12); const ct=arr.slice(12);
    const pt=await crypto.subtle.decrypt({name:'AES-GCM',iv},key,ct);
    return dec.decode(pt);
  }catch{ return '🔒 [зашифровано]'; }
}

/* ═══════ Stories (Истории) ═══════ */
export async function fbPostStory(username: string, payload: any) {
  await setDoc(doc(db, 'stories', `${username}_${Date.now()}_${Math.random().toString(36).slice(2,6)}`), {
    owner: username, ...payload, createdAt: Date.now(), expiresAt: Date.now() + 24*3600000,
    views: {}, reactions: {},
  });
}
export function onStories(cb: (stories: any[]) => void, username?: string) {
  const qy = username
    ? query(collection(db, 'stories'), where('owner', '==', username))
    : query(collection(db, 'stories'), where('expiresAt', '>', Date.now()));
  return onSnapshot(qy, snap => {
    const arr: any[] = []; snap.forEach(d => arr.push({ ...d.data(), id: d.id }));
    if (!username) {
      // только не просроченные, отсортированные
      const fresh = arr.filter(s => s.expiresAt > Date.now()).sort((a,b) => b.createdAt - a.createdAt);
      cb(fresh);
    } else cb(arr);
  });
}
export async function fbViewStory(storyId: string, username: string) {
  await updateDoc(doc(db, 'stories', storyId), { ['views.'+username]: Date.now() });
}
export async function fbReactStory(storyId: string, emoji: string, username: string) {
  await updateDoc(doc(db, 'stories', storyId), { ['reactions.'+emoji]: arrayUnion(username) });
}
export async function fbDeleteStory(storyId: string) {
  await deleteDoc(doc(db, 'stories', storyId));
}

/* ═══════ Глобальный поиск по сообщениям (если уже есть) — добавлю пересылку в несколько чатов ═══════ */
export async function fbForwardMessage(originalMsg: any, targetChatIds: string[], senderId: string) {
  const baseExtra:any = { replyTo: originalMsg.replyTo || null, fileJson: originalMsg.fileJson || null };
  await Promise.all(targetChatIds.map(async(cid)=>{
    await fbSendMessage(cid, senderId, originalMsg.text || '', baseExtra);
  }));
}

export async function fbAutoModerate(senderUn: string, text: string) {
  // 1) запрещённые слова → авто-предупреждение
  const hit = BAD_WORDS.some(re => re.test(text));
  if (hit) {
    const uSnap = await getDoc(doc(db, 'users', senderUn));
    const warns = (uSnap.data()?.warns || 0) + 1;
    await updateDoc(doc(db, 'users', senderUn), { warns });
    // 3 предупреждения → авто-бан + сигнал всем админам
    if (warns >= 3) {
      await updateDoc(doc(db, 'users', senderUn), { bannedGlobal: true, banUntil: Date.now() + 24 * 3600000, banReason: 'Авто-бан: запрещённый контент', lastSeen: 0 });
      await notifyAdmins(`СИЛЬНЫЙ НАРУШИТЕЛЬ: @${senderUn} авто-забанен на 24ч за запрещённый контент (${warns} нарушения).`);
    } else {
      await notifyAdmins(`Нарушение от @${senderUn} (предупреждение ${warns}/3): запрещённые слова.`);
    }
    return true;
  }
  return false;
}
export async function notifyAdmins(text: string) {
  try {
    const admins = await getDocs(query(collection(db, 'users'), where('isAdmin', '==', true)));
    for (const a of admins.docs) {
      const un = a.id;
      const dmId = 'dm_' + ['vibegram', un].sort().join('__');
      const dmRef = doc(db, 'chats', dmId);
      if (!(await getDoc(dmRef)).exists()) {
        await setDoc(dmRef, { id: dmId, type: 'dm', title: '', members: ['vibegram', un], perms: {}, banned: [], lastText: '', lastAt: Date.now(), createdAt: Date.now() });
      }
      await fbSendMessage(dmId, 'vibegram', 'МОДЕРАЦИЯ: ' + text);
    }
  } catch {}
}

/* ═══════ Стикерпаки / GIF-паки (пользовательские наборы) ═══════ */
export async function fbCreatePack(ownerUn: string, name: string, type: 'sticker' | 'gif', items: string[]) {
  const id = type + '_' + Math.random().toString(36).slice(2, 9);
  await setDoc(doc(db, 'packs', id), {
    id, ownerUn, name: name.slice(0, 40), type, items: items.slice(0, 50), createdAt: Date.now(), installs: 0,
  });
  return id;
}
export async function fbGetPack(id: string) {
  const snap = await getDoc(doc(db, 'packs', id));
  return snap.exists() ? snap.data() : null;
}
export async function fbAddItemToPack(id: string, url: string) {
  const snap = await getDoc(doc(db, 'packs', id));
  if (!snap.exists()) return;
  const items = snap.data().items || [];
  if (items.length >= 50) throw new Error('Максимум 50 в наборе');
  items.push(url);
  await updateDoc(doc(db, 'packs', id), { items });
}
export async function fbMyPacks(ownerUn: string) {
  const snap = await getDocs(query(collection(db, 'packs'), where('ownerUn', '==', ownerUn)));
  const arr: any[] = []; snap.forEach(d => arr.push(d.data())); return arr;
}
export async function fbInstallPack(username: string, packId: string) {
  await updateDoc(doc(db, 'users', username), { installedPacks: arrayUnion(packId) });
  const snap = await getDoc(doc(db, 'packs', packId));
  if (snap.exists()) await updateDoc(doc(db, 'packs', packId), { installs: (snap.data().installs || 0) + 1 });
}
export async function fbGetInstalledPacks(username: string) {
  const snap = await getDoc(doc(db, 'users', username));
  const ids: string[] = snap.exists() ? (snap.data().installedPacks || []) : [];
  const packs: any[] = [];
  for (const id of ids) { const p = await fbGetPack(id); if (p) packs.push(p); }
  return packs;
}

/* ═══════ Публичный каталог групп/каналов ═══════ */
export async function fbGetCatalog() {
  const snap = await getDocs(query(collection(db, 'chats'), where('isPublic', '==', true), limit(200)));
  const arr: any[] = [];
  snap.forEach(d => { const c = d.data(); if (c.type === 'group' || c.type === 'channel') arr.push({ ...c, id: d.id }); });
  return arr.sort((a, b) => (b.members?.length || 0) - (a.members?.length || 0));
}
export async function fbJoinChat(chatId: string, username: string) {
  await updateDoc(doc(db, 'chats', chatId), { members: arrayUnion(username) });
}

/* ═══════ Глобальный поиск по сообщениям ═══════ */
export async function fbSearchInChat(chatId: string, q: string) {
  // Firestore range-поиск по префиксу
  const snap = await getDocs(query(
    collection(db, 'chats', chatId, 'messages'),
    where('text', '>=', q), where('text', '<=', q + '\uf8ff'), limit(5)
  ));
  const arr: any[] = [];
  snap.forEach(d => arr.push({ ...d.data(), id: d.id }));
  return arr;
}

/* ═══════ Смена пароля ═══════ */
export async function fbChangePassword(username: string, oldPw: string, newPw: string) {
  const u = auth.currentUser;
  if (!u) throw new Error('Сессия истекла — войдите заново');
  if (newPw.length < 8) throw new Error('Новый пароль: минимум 8 символов');
  try {
    const cred = EmailAuthProvider.credential(unToEmail(username), oldPw);
    await reauthenticateWithCredential(u, cred);
  } catch {
    throw new Error('Неверный старый пароль');
  }
  await updatePassword(u, newPw);
}

/* ═══════ Удаление аккаунта (с реаутентификацией) ═══════ */
export async function fbDeleteAccount(username: string, password: string) {
  const u = auth.currentUser;
  if (!u) throw new Error('Сессия истекла — войдите заново');
  try {
    const cred = EmailAuthProvider.credential(unToEmail(username), password);
    await reauthenticateWithCredential(u, cred);
  } catch {
    throw new Error('Неверный пароль');
  }
  // выйти из всех чатов / удалить личные
  try {
    const qs = await getDocs(query(collection(db, 'chats'), where('members', 'array-contains', username)));
    for (const d of qs.docs) {
      const c = d.data();
      if (c.type === 'saved' || c.type === 'dm') {
        try {
          const msgs = await getDocs(collection(db, 'chats', d.id, 'messages'));
          await Promise.all(msgs.docs.map(m => deleteDoc(m.ref)));
        } catch {}
        await deleteDoc(d.ref);
      } else if (c.ownerId === username) {
        await updateDoc(d.ref, { members: arrayRemove(username), ownerId: (c.members || []).find((m: string) => m !== username) || '' });
      } else {
        await updateDoc(d.ref, { members: arrayRemove(username) });
      }
    }
  } catch {}
  // удалить ботов пользователя
  try {
    const bots = await getDocs(query(collection(db, 'bots'), where('ownerUn', '==', username)));
    for (const b of bots.docs) {
      await deleteDoc(doc(db, 'users', b.id));
      await deleteDoc(b.ref);
    }
  } catch {}
  await deleteDoc(doc(db, 'users', username));
  await deleteUser(u); // удаляет Auth-аккаунт
}

/* ═══════ Системный бот ═══════ */
export async function ensureSystemBot() {
  const ref = doc(db, 'users', 'vibegram');
  const snap = await getDoc(ref);
  if (!snap.exists()) {
    await setDoc(ref, {
      username: 'vibegram', name: 'VibeGram', bio: 'Официальный бот', avatar: '',
      isBot: true, isAdmin: false, isOwner: false,
      privacy: { dmPolicy: 'all', showLastSeen: false, searchable: true },
      folders: [], createdAt: Date.now(), lastSeen: Date.now(),
    });
  }
}

/* ═══════ Чаты ═══════ */
export async function fbCreateChat(ownerUn: string, type: string, title: string, username: string, isPublic: boolean, about: string) {
  const ref = await addDoc(collection(db, 'chats'), {
    type, title: title.slice(0, 60), username: username || '', about: (about || '').slice(0, 300), avatar: '',
    isPublic, ownerId: ownerUn, members: [ownerUn],
    perms: { [ownerUn]: { role: 'owner', canText: true, canMedia: true, canLinks: true, mutedUntil: 0 } },
    banned: [], allowedReactions: '', commentMode: 'on',
    pinned: [], pinnedMsgs: [], autoDelete: 0,
    wallpaper: '', accentColor: '', mutedUntil: 0,
    lastText: '', lastAt: Date.now(), createdAt: Date.now(),
  });
  await updateDoc(ref, { id: ref.id });
  return ref.id;
}

export async function fbCreateDM(a: string, b: string) {
  const id = 'dm_' + [a, b].sort().join('__');
  const ref = doc(db, 'chats', id);
  const snap = await getDoc(ref);
  if (!snap.exists()) {
    await setDoc(ref, {
      id, type: 'dm', title: '', username: '', about: '', avatar: '', isPublic: false,
      ownerId: '', members: [a, b], perms: {}, banned: [],
      lastText: '', lastAt: Date.now(), createdAt: Date.now(),
    });
  }
  return id;
}

export async function fbDeleteChat(chatId: string) {
  try {
    const msgs = await getDocs(collection(db, 'chats', chatId, 'messages'));
    await Promise.all(msgs.docs.map(d => deleteDoc(d.ref)));
  } catch {}
  await deleteDoc(doc(db, 'chats', chatId));
}

export async function fbLeaveChat(chatId: string, un: string) {
  await updateDoc(doc(db, 'chats', chatId), { members: arrayRemove(un) });
}

/* ═══════ Сообщения (с лимитами) ═══════ */
export async function fbSendMessage(chatId: string, senderId: string, text: string, extra: any = {}) {
  text = (text || '').slice(0, 8192); // снят лимит длины (вместо 4096)
  const msg = {
    text, senderId, chatId, timestamp: serverTimestamp(), createdAt: Date.now(),
    replyTo: extra.replyTo || null, fileJson: extra.fileJson || null,
    type: extra.type || 'text',
    reactions: {}, editedAt: 0,
  };
  const ref = await addDoc(collection(db, 'chats', chatId, 'messages'), msg);
  await updateDoc(doc(db, 'chats', chatId), {
    lastText: (text || 'Файл').slice(0, 60),
    lastAt: Date.now(),
  });
  return ref.id;
}

export async function fbToggleReaction(chatId: string, msgId: string, emoji: string, un: string, current: any) {
  const ref = doc(db, 'chats', chatId, 'messages', msgId);
  const arr: string[] = (current?.[emoji]) || [];
  if (arr.includes(un)) {
    await updateDoc(ref, { ['reactions.' + emoji]: arrayRemove(un) });
  } else {
    await updateDoc(ref, { ['reactions.' + emoji]: arrayUnion(un) });
  }
}

/* ═══════ Одноразовый токен админа ═══════
   Владелец создаёт в Firestore документ admin_tokens/{token} 
   с полем value (= сам токен) и expiresAt. Клиент проверяет токен — 
   если совпал и не истёк, выдаёт isAdmin/isOwner пользователю и 
   СРАЗУ УДАЛЯЕТ токен (одноразовый).
   Токена нет в коде — его знает только владелец консоли.
   Срок жизни по умолчанию: 24 часа. */
export async function checkAdminToken(username: string, token: string): Promise<{ok:boolean;msg:string}> {
  if (!token || token.length < 4) return {ok:false, msg:'Токен слишком короткий'};
  try {
    const ref = doc(db, 'admin_tokens', token);
    const snap = await getDoc(ref);
    if (!snap.exists()) return {ok:false, msg:'Токен не найден'};
    const data = snap.data();
    if (data.expiresAt && data.expiresAt < Date.now()) {
      await deleteDoc(ref);
      return {ok:false, msg:'Токен истёк'};
    }
    if (String(data.value) !== String(token)) return {ok:false, msg:'Токен не совпадает'};
    await updateDoc(doc(db, 'users', username), { isAdmin: true, isOwner: true });
    await deleteDoc(ref);
    return {ok:true, msg:'Права администратора выданы'};
  } catch (e: any) {
    return {ok:false, msg:'Ошибка: ' + (e.message||e)};
  }
}

/* ═══════ Закреплённые сообщения ═══════ */
export async function fbPinMessage(chatId: string, msgId: string, text: string, sender: string) {
  const chatRef = doc(db, 'chats', chatId);
  const snap = await getDoc(chatRef);
  if (!snap.exists()) return;
  const data = snap.data();
  const pinned = data.pinnedMsgs || [];
  // Максимум 5 закреплённых
  if (pinned.length >= 5) {
    pinned.shift(); // удаляем самое старое
  }
  pinned.push({ msgId, text: text.slice(0, 100), sender, pinnedAt: Date.now() });
  await updateDoc(chatRef, { pinnedMsgs: pinned });
}

export async function fbUnpinMessage(chatId: string, msgId: string) {
  const chatRef = doc(db, 'chats', chatId);
  const snap = await getDoc(chatRef);
  if (!snap.exists()) return;
  const data = snap.data();
  const pinned = (data.pinnedMsgs || []).filter((p: any) => p.msgId !== msgId);
  await updateDoc(chatRef, { pinnedMsgs: pinned });
}

/* ═══════ Архив и закрепление чатов ═══════ */
export async function fbToggleArchive(username: string, chatId: string, archived: boolean) {
  const userRef = doc(db, 'users', username);
  const snap = await getDoc(userRef);
  if (!snap.exists()) return;
  const data = snap.data();
  const archivedList = data.archivedChats || [];
  if (archived) {
    if (!archivedList.includes(chatId)) {
      await updateDoc(userRef, { archivedChats: arrayUnion(chatId) });
    }
  } else {
    await updateDoc(userRef, { archivedChats: arrayRemove(chatId) });
  }
}

export async function fbTogglePinChat(username: string, chatId: string, pinned: boolean) {
  const userRef = doc(db, 'users', username);
  const snap = await getDoc(userRef);
  if (!snap.exists()) return;
  const data = snap.data();
  const pinnedList = data.pinnedChats || [];
  if (pinned) {
    if (!pinnedList.includes(chatId)) {
      await updateDoc(userRef, { pinnedChats: arrayUnion(chatId) });
    }
  } else {
    await updateDoc(userRef, { pinnedChats: arrayRemove(chatId) });
  }
}

/* ═══════ Индикатор «печатает…» ═══════ */
export async function fbSetTyping(chatId: string, username: string, isTyping: boolean) {
  const typingRef = doc(db, 'typing', `${chatId}_${username}`);
  if (isTyping) {
    await setDoc(typingRef, { chatId, username, isTyping: true, updatedAt: Date.now() }, { merge: true });
  } else {
    await deleteDoc(typingRef);
  }
}

/* ═══════ Галочки прочтения ═══════ */
export async function fbMarkAsRead(chatId: string, msgId: string, username: string) {
  const msgRef = doc(db, 'chats', chatId, 'messages', msgId);
  await updateDoc(msgRef, { readBy: arrayUnion(username) });
}

export async function fbGetReadStatus(chatId: string, msgId: string): Promise<string[]> {
  const msgRef = doc(db, 'chats', chatId, 'messages', msgId);
  const snap = await getDoc(msgRef);
  if (!snap.exists()) return [];
  return snap.data().readBy || [];
}

/* ═══════ Блокировка пользователей ═══════ */
export async function fbBlockUser(username: string, blockedUsername: string) {
  const userRef = doc(db, 'users', username);
  await updateDoc(userRef, { blockedUsers: arrayUnion(blockedUsername) });
}

export async function fbUnblockUser(username: string, blockedUsername: string) {
  const userRef = doc(db, 'users', username);
  await updateDoc(userRef, { blockedUsers: arrayRemove(blockedUsername) });
}

export async function fbGetBlockedUsers(username: string): Promise<string[]> {
  const userRef = doc(db, 'users', username);
  const snap = await getDoc(userRef);
  if (!snap.exists()) return [];
  return snap.data().blockedUsers || [];
}

/* ═══════ VibeGram Premium (выдаёт только админ; админ может себе) ═══════ */
export async function fbSetPremium(adminUn: string, targetUn: string, months: number) {
  const adminSnap = await getDoc(doc(db, 'users', adminUn));
  if (!adminSnap.exists() || !adminSnap.data().isAdmin) throw new Error('Только админ может выдавать Premium');
  const until = months > 0 ? Date.now() + months * 30 * 24 * 3600000 : 0;
  await updateDoc(doc(db, 'users', targetUn), { premium: true, premiumUntil: until });
  // уведомление
  try {
    const dmId = 'dm_' + ['vibegram', targetUn].sort().join('__');
    if (!(await getDoc(doc(db, 'chats', dmId))).exists()) {
      await setDoc(doc(db, 'chats', dmId), { id: dmId, type: 'dm', title: '', members: ['vibegram', targetUn], perms: {}, banned: [], lastText: '', lastAt: Date.now(), createdAt: Date.now() });
    }
    await fbSendMessage(dmId, 'vibegram', `Поздравляем! Вам активирован VibeGram Premium${months > 0 ? ' на ' + months + ' мес.' : ' навсегда'}.\n\nТеперь доступно: золотой значок, увеличенные лимиты, эксклюзивные реакции, скрытие «был в сети» точечно, и многое другое.`);
  } catch {}
}
export async function fbRemovePremium(adminUn: string, targetUn: string) {
  const adminSnap = await getDoc(doc(db, 'users', adminUn));
  if (!adminSnap.exists() || !adminSnap.data().isAdmin) throw new Error('Только админ');
  await updateDoc(doc(db, 'users', targetUn), { premium: false, premiumUntil: 0 });
}
/* ═══════ Свои функции v2 ═══════ */

/* 1. Закреп сообщений (до 5 на чат) */
export async function fbPinMsg(chatId: string, msgId: string, text: string, sender: string) {
  const ref = doc(db, 'chats', chatId);
  const snap = await getDoc(ref);
  if (!snap.exists()) return;
  const data = snap.data();
  const pinned = (data.pinnedMsgs || []).slice();
  if (pinned.find((p: any) => p.msgId === msgId)) return;
  if (pinned.length >= 5) pinned.shift();
  pinned.push({ msgId, text: text.slice(0, 200), sender, pinnedAt: Date.now() });
  await updateDoc(ref, { pinnedMsgs: pinned });
}
export async function fbUnpinMsg(chatId: string, msgId: string) {
  const ref = doc(db, 'chats', chatId);
  const snap = await getDoc(ref);
  if (!snap.exists()) return;
  const data = snap.data();
  const pinned = (data.pinnedMsgs || []).filter((p: any) => p.msgId !== msgId);
  await updateDoc(ref, { pinnedMsgs: pinned });
}

/* 2. Закладки сообщений */
export async function fbAddBookmark(username: string, bm: any) {
  await updateDoc(doc(db, 'users', username), { bookmarks: arrayUnion(bm) });
}
export async function fbRemoveBookmark(username: string, bm: any) {
  await updateDoc(doc(db, 'users', username), { bookmarks: arrayRemove(bm) });
}

/* 3. Заметки (Pin-сообщения пользователя) */
export async function fbSaveNote(username: string, note: { id: string; title: string; text: string; ts: number }) {
  const ref = doc(db, 'users', username);
  const snap = await getDoc(ref);
  const list = (snap.data()?.notes || []);
  const idx = list.findIndex((n: any) => n.id === note.id);
  if (idx >= 0) list[idx] = note; else list.push(note);
  await updateDoc(ref, { notes: list });
}
export async function fbDeleteNote(username: string, id: string) {
  const ref = doc(db, 'users', username);
  const snap = await getDoc(ref);
  const list = (snap.data()?.notes || []).filter((n: any) => n.id !== id);
  await updateDoc(ref, { notes: list });
}

/* 4. Напоминания */
export async function fbCreateReminder(username: string, r: { id: string; text: string; fireAt: number; chatId?: string }) {
  const ref = doc(db, 'reminders', r.id);
  await setDoc(ref, { ...r, owner: username, done: false });
}
export async function fbDoneReminder(id: string) {
  await updateDoc(doc(db, 'reminders', id), { done: true });
}
export function onReminders(username: string, cb: (list: any[]) => void) {
  return onSnapshot(query(collection(db, 'reminders')), (snap) => {
    const arr: any[] = [] as any;
    snap.forEach(d => { const r = d.data(); if (r.owner === username) arr.push({ ...r, id: d.id }); });
    cb((arr as any).filter((r: any) => !r.done).sort((a: any, b: any) => a.fireAt - b.fireAt));
  });
}

/* 5. Задачи (личный task-лист в чате с ботом-задачей) */
export async function fbAddTask(chatId: string, task: { id: string; text: string; done: boolean; who: string; ts: number }) {
  const ref = doc(db, 'chats', chatId);
  const snap = await getDoc(ref);
  const list = (snap.data()?.tasks || []);
  const idx = list.findIndex((t: any) => t.id === task.id);
  if (idx >= 0) list[idx] = task; else list.push(task);
  await updateDoc(ref, { tasks: list });
}
export async function fbDeleteTask(chatId: string, taskId: string) {
  const ref = doc(db, 'chats', chatId);
  const snap = await getDoc(ref);
  const list = (snap.data()?.tasks || []).filter((t: any) => t.id !== taskId);
  await updateDoc(ref, { tasks: list });
}

/* 6. Звонки-комнаты (комнаты для созвонов) */
export async function fbCreateRoom(creator: string, name: string, isPublic: boolean) {
  const id = 'room_' + Math.random().toString(36).slice(2, 9);
  await setDoc(doc(db, 'rooms', id), {
    id, name: name.slice(0, 50), creator, isPublic,
    members: [creator], speakers: [creator], listeners: [],
    createdAt: Date.now(),
  });
  return id;
}
export function onRooms(cb: (rooms: any[]) => void, username?: string) {
  return onSnapshot(query(collection(db, 'rooms')), (snap: any) => {
    const arr: any[] = [];
    snap.forEach((d: any) => {
      const r = d.data();
      if (!username) arr.push(Object.assign({}, r, { id: d.id }));
      else if (r.members && r.members.indexOf(username) >= 0) arr.push(Object.assign({}, r, { id: d.id }));
      else if (r.isPublic) arr.push(Object.assign({}, r, { id: d.id }));
    });
    cb(arr);
  });
}
export async function fbJoinRoom(roomId: string, username: string) {
  await updateDoc(doc(db, 'rooms', roomId), { members: arrayUnion(username) });
}
export async function fbLeaveRoom(roomId: string, username: string) {
  await updateDoc(doc(db, 'rooms', roomId), { members: arrayRemove(username) });
}

/* 7. Реакции (полноценные) — на 1 функции уже есть выше */
export async function fbSetReactionsBatch(chatId: string, msgId: string, reactions: Record<string, string[]>) {
  await updateDoc(doc(db, 'chats', chatId, 'messages', msgId), { reactions });
}

/* 8. Сохранение черновика (на сервере) */
export async function fbSaveDraft(username: string, chatId: string, text: string) {
  await setDoc(doc(db, 'drafts', `${username}_${chatId}`), { username, chatId, text, ts: Date.now() }, { merge: true });
}
export async function fbGetDraft(username: string, chatId: string): Promise<string> {
  const snap = await getDoc(doc(db, 'drafts', `${username}_${chatId}`));
  return snap.exists() ? (snap.data().text || '') : '';
}

/* 9. Дайджест: уведомления о пропущенных сообщениях */
export async function fbMarkReadDigest(username: string, lastTs: number) {
  await setDoc(doc(db, 'users', username), { lastDigestTs: lastTs }, { merge: true });
}

export function isPremium(u: any): boolean {
  if (!u?.premium) return false;
  if (u.premiumUntil && u.premiumUntil <= Date.now()) return false;
  return true;
}

/* 10. Premium: создание кастомных наборов стикеров (URL → набор) */
export async function fbCreateStickerPack(owner: string, name: string, items: string[]) {
  const id = 'sp_' + Math.random().toString(36).slice(2, 9);
  await setDoc(doc(db, 'stickerpacks', id), {
    id, owner, name: name.slice(0, 30), items, createdAt: Date.now(), uses: 0,
  });
  return id;
}
export function onStickerPacks(owner: string, cb: (packs: any[]) => void) {
  return onSnapshot(query(collection(db, 'stickerpacks')), snap => {
    const arr: any[] = []; snap.forEach(d => { const p = d.data(); if (p.owner === owner) arr.push({ ...p, id: d.id }); });
    cb(arr);
  });
}

/* ═══════ Свои функции (партия 3) ═══════ */

/* Анонимный фидбек группе/каналу */
export async function fbFeedback(chatId: string, from: string, text: string) {
  await addDoc(collection(db, 'feedback'), { chatId, from, text, ts: Date.now() });
}

/* Цитата-ответ: связать в цепочку */
export async function fbLinkReplies(chatId: string, parentMsgId: string, replyMsgId: string) {
  await updateDoc(doc(db, 'chats', chatId, 'messages', replyMsgId), { threadId: parentMsgId });
  await updateDoc(doc(db, 'chats', chatId, 'messages', parentMsgId), { threadCount: (Math.random() | 0) });
}

/* Подписки на чат: кто следит за уведомлениями */
export async function fbSubscribeChat(chatId: string, username: string) {
  await updateDoc(doc(db, 'chats', chatId), { subscribers: arrayUnion(username) });
}
export async function fbUnsubscribeChat(chatId: string, username: string) {
  await updateDoc(doc(db, 'chats', chatId), { subscribers: arrayRemove(username) });
}

/* Список задач (kanban) пользователя — глобально */
export async function fbSaveKanban(username: string, board: { id: string; title: string; status: 'todo'|'doing'|'done'; order: number }[]) {
  await setDoc(doc(db, 'kanban', username), { board, ts: Date.now() });
}
export async function fbGetKanban(username: string): Promise<any[]> {
  const snap = await getDoc(doc(db, 'kanban', username));
  return snap.exists() ? (snap.data().board || []) : [];
}

/* Лог активности (свои действия) */
export async function fbLogActivity(username: string, action: string, detail?: any) {
  await addDoc(collection(db, 'activity', `${username}_${Date.now()}_${Math.random().toString(36).slice(2,6)}`), {
    owner: username, action, detail: detail || null, ts: Date.now(),
  });
}
export function onActivity(username: string, cb: (list: any[]) => void) {
  return onSnapshot(query(collection(db, 'activity')), (snap: any) => {
    const arr: any[] = []; snap.forEach((d: any) => { const a = d.data(); if (a.owner === username) arr.push(Object.assign({}, a, { id: d.id })); });
    cb(arr.sort((x: any, y: any) => y.ts - x.ts).slice(0, 100));
  });
}

/* Избранное: список ID чатов в профиле */
export async function fbToggleFavoriteChat(username: string, chatId: string) {
  const ref = doc(db, 'users', username);
  const snap = await getDoc(ref);
  const fav: string[] = snap.data()?.favoriteChats || [];
  if (fav.includes(chatId)) await updateDoc(ref, { favoriteChats: arrayRemove(chatId) });
  else await updateDoc(ref, { favoriteChats: arrayUnion(chatId) });
}

/* Snooze-чат: скрыть уведомления на время */
export async function fbSnoozeChat(chatId: string, until: number) {
  await updateDoc(doc(db, 'chats', chatId), { snoozedUntil: until });
}

/* Saved search (поисковые запросы пользователя) */
export async function fbSaveSearch(username: string, query: string) {
  const ref = doc(db, 'users', username);
  const snap = await getDoc(ref);
  const list = (snap.data()?.savedSearches || []).slice(0, 9);
  if (!list.includes(query)) list.unshift(query);
  await updateDoc(ref, { savedSearches: list });
}

/* Mentions: непрочитанные упоминания */
export async function fbMarkMentionRead(username: string, chatId: string, msgId: string) {
  await updateDoc(doc(db, 'users', username), { [`mentions.${chatId}.${msgId}`]: Date.now() });
}

/* Расширенные статусы (текст/фото/музыка) */
export async function fbSetStatus(username: string, status: { text: string; emoji: string; bg?: string; until?: number }) {
  await updateDoc(doc(db, 'users', username), { status });
}

/* Лимит загрузок: счётчик за день */
export async function fbCheckUploadLimit(username: string, fileSize: number): Promise<{ok: boolean; left: number}> {
  const ref = doc(db, 'users', username);
  const snap = await getDoc(ref);
  const today = new Date().toDateString();
  const stats = snap.data()?.uploads || { date: today, bytes: 0, count: 0 };
  if (stats.date !== today) { stats.date = today; stats.bytes = 0; stats.count = 0; }
  const limit = isPremium(snap.data()) ? 2 * 1024 * 1024 * 1024 : 100 * 1024 * 1024; // Premium 2GB, обычный 100MB
  if (stats.bytes + fileSize > limit) return { ok: false, left: limit - stats.bytes };
  stats.bytes += fileSize; stats.count += 1;
  await updateDoc(ref, { uploads: stats });
  return { ok: true, left: limit - stats.bytes };
}

/* Автоудаление аккаунта (GDPR-style): помечает аккаунт как удалённый, очищает сообщения */
export async function fbSoftDeleteUser(username: string) {
  const userRef = doc(db, 'users', username);
  await updateDoc(userRef, { deleted: true, deletedAt: Date.now() });
  // удаляем его сообщения из всех чатов
  const chats = await getDocs(query(collection(db, 'chats'), where('members', 'array-contains', username)));
  for (const ch of chats.docs) {
    const msgs = await getDocs(query(collection(db, 'chats', ch.id, 'messages'), where('senderId', '==', username)));
    for (const m of msgs.docs) await deleteDoc(m.ref);
  }
  await deleteDoc(userRef);
}

/* Local encryption helper: encrypt file data with key derived from chat+user (AES-GCM) */
async function deriveFileKey(username: string, chatId: string) {
  const enc = new TextEncoder();
  const base = await crypto.subtle.importKey('raw', enc.encode('vgf:' + username + ':' + chatId), { name: 'PBKDF2' }, false, ['deriveKey']);
  return crypto.subtle.deriveKey({ name: 'PBKDF2', salt: enc.encode('vgfsalt2026'), iterations: 10000, hash: 'SHA-256' }, base, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
}
export async function encryptFile(blob: Blob, username: string, chatId: string): Promise<{ enc: Blob; iv: Uint8Array }> {
  const key = await deriveFileKey(username, chatId);
  const iv = new Uint8Array(12);
  crypto.getRandomValues(iv);
  const buf = await blob.arrayBuffer();
  const enc = await crypto.subtle.encrypt({ name: 'AES-GCM', iv: iv as BufferSource }, key, buf);
  return { enc: new Blob([enc]), iv };
}
export async function decryptFile(enc: Blob, iv: Uint8Array, username: string, chatId: string): Promise<Blob> {
  const key = await deriveFileKey(username, chatId);
  const buf = await enc.arrayBuffer();
  const dec = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: iv as BufferSource }, key, buf);
  return new Blob([dec]);
}

/* Статистика для админа: всего юзеров, чатов, сообщений (агрегаты) */
export async function fbGetGlobalStats() {
  const [users, chats] = await Promise.all([
    getDocs(collection(db, 'users')),
    getDocs(collection(db, 'chats')),
  ]);
  return { users: users.size, chats: chats.size };
}

/* Live typing в комнатах */
export function onTypingInRoom(roomId: string, cb: (users: string[]) => void) {
  return onSnapshot(query(collection(db, 'rooms', roomId, 'typing')), (snap: any) => {
    const arr: string[] = []; snap.forEach((d: any) => arr.push(d.id));
    cb(arr);
  });
}
export async function fbSetTypingRoom(roomId: string, username: string) {
  await setDoc(doc(db, 'rooms', roomId, 'typing', username), { ts: Date.now() });
}
export async function fbStopTypingRoom(roomId: string, username: string) {
  await deleteDoc(doc(db, 'rooms', roomId, 'typing', username));
}

/* Массовое удаление сообщений (для админа) */
export async function fbBulkDelete(chatId: string, predicate: (msg: any) => boolean) {
  const snap = await getDocs(query(collection(db, 'chats', chatId, 'messages')));
  for (const m of snap.docs) if (predicate(m.data())) await deleteDoc(m.ref);
}

/* Поиск по всем чатам пользователя (full-text через массив слов — упрощённо) */
export async function fbFullTextSearch(username: string, q: string): Promise<{ chatId: string; chatTitle: string; msg: any }[]> {
  const chats = await getDocs(query(collection(db, 'chats'), where('members', 'array-contains', username)));
  const results: any[] = [];
  for (const ch of chats.docs) {
    const cdata = ch.data();
    const msgs = await getDocs(query(collection(db, 'chats', ch.id, 'messages'), where('text', '>=', q), where('text', '<=', q + '\uf8ff'), limit(10)));
    msgs.forEach(m => {
      const md = m.data();
      if (md.text && md.text.toLowerCase().includes(q.toLowerCase())) {
        results.push({ chatId: ch.id, chatTitle: cdata.title || cdata.type, msg: Object.assign({}, md, { id: m.id }) });
      }
    });
  }
  return results;
}

/* ═══════ Бизнес AI-бот: конфиг на аккаунте ═══════ */
export async function fbSaveAIConfig(username: string, cfg: any) {
  await updateDoc(doc(db, 'users', username), { aiConfig: cfg });
}

/* Вызов AI у выбранного провайдера (из браузера). 
   Gemini и OpenRouter работают из браузера. OpenAI/Claude часто блокируют CORS — для них нужен прокси. */
export async function callAI(provider: string, apiKey: string, model: string, system: string, userText: string): Promise<string> {
  try {
    if (provider === 'gemini') {
      const m = model || 'gemini-1.5-flash';
      const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${m}:generateContent?key=${apiKey}`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          system_instruction: system ? { parts: [{ text: system }] } : undefined,
          contents: [{ role: 'user', parts: [{ text: userText }] }],
        }),
      });
      const d = await r.json();
      return d?.candidates?.[0]?.content?.parts?.[0]?.text || (d?.error?.message ? '[Ошибка AI: ' + d.error.message + ']' : '[Пустой ответ]');
    }
    if (provider === 'openrouter') {
      const r = await fetch('https://openrouter.ai/api/v1/chat/completions', {
        method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + apiKey },
        body: JSON.stringify({
          model: model || 'openai/gpt-4o-mini',
          messages: [...(system ? [{ role: 'system', content: system }] : []), { role: 'user', content: userText }],
        }),
      });
      const d = await r.json();
      return d?.choices?.[0]?.message?.content || (d?.error?.message ? '[Ошибка: ' + d.error.message + ']' : '[Пусто]');
    }
    if (provider === 'openai') {
      const r = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + apiKey },
        body: JSON.stringify({
          model: model || 'gpt-4o-mini',
          messages: [...(system ? [{ role: 'system', content: system }] : []), { role: 'user', content: userText }],
        }),
      });
      const d = await r.json();
      return d?.choices?.[0]?.message?.content || '[Ошибка OpenAI — возможно CORS, используйте OpenRouter]';
    }
    if (provider === 'claude') {
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST', headers: { 'Content-Type': 'application/json', 'x-api-key': apiKey, 'anthropic-version': '2023-06-01', 'anthropic-dangerous-direct-browser-access': 'true' },
        body: JSON.stringify({
          model: model || 'claude-3-5-haiku-20241022', max_tokens: 1024,
          system: system || undefined,
          messages: [{ role: 'user', content: userText }],
        }),
      });
      const d = await r.json();
      return d?.content?.[0]?.text || (d?.error?.message ? '[Ошибка: ' + d.error.message + ']' : '[Пусто]');
    }
    return '[Неизвестный провайдер]';
  } catch (e: any) {
    return '[Ошибка соединения с AI: ' + (e.message || e) + ']';
  }
}

/* ═══════ Мьют чата ═══════ */
export async function fbMuteChat(chatId: string, mutedUntil: number) {
  const chatRef = doc(db, 'chats', chatId);
  await updateDoc(chatRef, { mutedUntil });
}

/* ═══════ Обои и цвет чата ═══════ */
export async function fbSetChatAppearance(chatId: string, wallpaper: string, accentColor: string) {
  const chatRef = doc(db, 'chats', chatId);
  const updates: any = {};
  if (wallpaper !== undefined) updates.wallpaper = wallpaper;
  if (accentColor !== undefined) updates.accentColor = accentColor;
  await updateDoc(chatRef, updates);
}

/* ═══════ Автоудаление сообщений (TTL) ═══════ */
export async function fbSetAutoDelete(chatId: string, seconds: number) {
  const chatRef = doc(db, 'chats', chatId);
  await updateDoc(chatRef, { autoDelete: seconds });
}

/* ═══════ Экспорт чата ═══════ */
export async function fbExportChat(chatId: string): Promise<{chat: any, messages: any[]}> {
  const chatRef = doc(db, 'chats', chatId);
  const chatSnap = await getDoc(chatRef);
  const chat = chatSnap.exists() ? chatSnap.data() : null;
  
  const msgsSnap = await getDocs(query(collection(db, 'chats', chatId, 'messages'), orderBy('createdAt', 'asc')));
  const messages: any[] = [];
  msgsSnap.forEach(d => messages.push({...d.data(), id: d.id}));
  
  return {chat, messages};
}

/* ═══════ Полная очистка БД (только для админа) ═══════
   Удаляет все чаты и их сообщения, всех пользователей (кроме админа),
   ботов, розыгрыши. Админский профиль и его Избранное остаются. */
export async function fbWipeAll(adminUsername: string): Promise<string> {
  const adminSnap = await getDoc(doc(db, 'users', adminUsername));
  if (!adminSnap.exists() || !adminSnap.data().isAdmin) {
    return 'Только админ может очистить БД';
  }
  let deleted = 0;
  try {
    const chats = await getDocs(collection(db, 'chats'));
    for (const ch of chats.docs) {
      try {
        const msgs = await getDocs(collection(db, 'chats', ch.id, 'messages'));
        for (const m of msgs.docs) { await deleteDoc(m.ref); deleted++; }
        await deleteDoc(ch.ref); deleted++;
      } catch {}
    }
  } catch {}
  try {
    const users = await getDocs(collection(db, 'users'));
    for (const u of users.docs) {
      if (u.id !== adminUsername && !u.data().isAdmin) { await deleteDoc(u.ref); deleted++; }
    }
  } catch {}
  try {
    const bots = await getDocs(collection(db, 'bots'));
    for (const b of bots.docs) { await deleteDoc(b.ref); deleted++; }
  } catch {}
  try {
    const gws = await getDocs(collection(db, 'giveaways'));
    for (const g of gws.docs) { await deleteDoc(g.ref); deleted++; }
  } catch {}
  // Восстановить Избранное для админа
  await setDoc(doc(db, 'chats', 'saved_' + adminUsername), {
    id: 'saved_' + adminUsername, type: 'saved', title: 'Избранное', username: '',
    about: '', avatar: '', isPublic: false, ownerId: adminUsername,
    members: [adminUsername], perms: {}, banned: [],
    lastText: '', lastAt: Date.now(), createdAt: Date.now(),
  });
  return `Удалено записей: ~${deleted}. Чистый лист.`;
}
